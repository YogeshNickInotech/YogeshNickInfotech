export const BACKGROUND_IMAGES: Theme[] = [
  { value: 'BG1', label: 'Image 1' },
  { value: 'BG2', label: 'Image 2' },
  { value: 'BG3', label: 'Image 3' },
  { value: 'BG4', label: 'Image 4' },
  { value: 'BG5', label: 'Image 5' }
];

export const BACKGROUND_IMAGES2: Theme[] = [
  { value: 'BG1', label: 'Image 1' },
  { value: 'BG2', label: 'Image 2' },
  { value: 'BG3', label: 'Image 3' },
  { value: 'BG4', label: 'Image 4' },
  { value: 'BG5', label: 'Image 5' }
];

export const BACKGROUND_IMAGES3: Theme[] = [
  { value: 'BG1', label: 'Image 1' },
  { value: 'BG2', label: 'Image 2' },
  { value: 'BG3', label: 'Image 3' },
  { value: 'BG4', label: 'Image 4' },
  { value: 'BG5', label: 'Image 5' }
];

export class Theme {
  public value: string;
  public label: string;
}
