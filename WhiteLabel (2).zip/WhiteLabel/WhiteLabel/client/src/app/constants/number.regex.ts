export const NUMBER_REGEX = /(?=.*[0-9])/;
