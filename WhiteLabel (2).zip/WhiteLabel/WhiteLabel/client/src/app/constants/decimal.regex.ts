export const DECIMAL_REGEX = /^[+-]?((\d+(\.\d*)?)|(\.\d+))$/;
export const INTEGER_REGEX = /^\d+$/;
