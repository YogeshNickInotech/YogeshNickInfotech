export const UPPER_CASE_REGEX = /(?=.*[A-Z])/;
