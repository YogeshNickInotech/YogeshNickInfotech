export const SPECIAL_CHARACTER_REGEX = /(?=.[@%/'"!#,~&;`_<>\:\.\^\$\*\+\-\?\(\)\[\]\{\}\\\|])/;
