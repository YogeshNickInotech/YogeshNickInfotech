export const LOWER_CASE_REGEX = /(?=.*[a-z])/;
