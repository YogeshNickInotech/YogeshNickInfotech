import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { LeathermanUikitMdcModule } from './mdc.module';
import {
  LeathermanModule,
  MockErrorDialogService,
  MockConfirmDialogService,
  ErrorDialogComponent,
  ConfirmDialogComponent
} from 'leatherman';
import { appConfig } from './config/app.config';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { AngularModule } from './angular.module';
import { ServiceWorkerModule } from '@angular/service-worker';
import { EditAdminUserDialogComponent } from './dialogs/user/edit-admin-user-dialog/edit-admin-user-dialog.component';
import { PluralizePipe } from './pipes/pluralize.pipe';
import { DatePipe, DecimalPipe } from '@angular/common';
import { Login2Component } from './pages/_common/login/login.component';
import { InfoDialogComponent } from './dialogs/info/info-dialog/info-dialog.component';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { PhonePipe } from './pipes/phone.pipe';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { EditSitePropertiesDialogComponent } from './dialogs/site/edit-site-properties-dialog/edit-site-properties-dialog.component';
import { EditSitePricingDialogComponent } from './dialogs/site/edit-site-pricing-dialog/edit-site-pricing-dialog.component';
import { UploadSiteLogoDialogComponent } from './dialogs/site/upload-site-logo-dialog/upload-site-logo-dialog.component';
import { EditOrderDialogComponent } from './dialogs/order/edit-order-dialog/edit-order-dialog.component';
import { EditCustomerDialogComponent } from './dialogs/customer/edit-customer-dialog/edit-customer-dialog.component';
import { EditUserNameDialogComponent } from './dialogs/user/edit-user-name-dialog/edit-user-name-dialog.component';
// tslint:disable-next-line: max-line-length
import { EditSiteBillingAddressDialogComponent } from './dialogs/site/edit-site-billing-address-dialog/edit-site-billing-address-dialog.component';
import { EditSiteCreditCardDialogComponent } from './dialogs/site/edit-site-credit-card-dialog/edit-site-credit-card-dialog.component';
import { CmsLayoutComponent } from './layouts/cms/cms-layout.component';
import { AdminLayoutComponent } from './layouts/admin/admin-layout.component';
// tslint:disable-next-line: max-line-length
import { EditSiteMailingAddressDialogComponent } from './dialogs/site/edit-site-mailing-address-dialog/edit-site-mailing-address-dialog.component';
import { EditFaqDialogComponent } from './dialogs/faq/edit-faq-dialog/edit-faq-dialog.component';
import { EditSiteHeadingDialogComponent } from './dialogs/site/edit-site-heading-dialog/edit-site-heading-dialog.component';
import { EditSitePolicyDialogComponent } from './dialogs/site/edit-site-policy-dialog/edit-site-policy-dialog.component';
// tslint:disable-next-line: max-line-length
import { EditCustomerBillingAddressDialogComponent } from './dialogs/customer/edit-customer-billing-address-dialog/edit-customer-billing-address-dialog.component';
// tslint:disable-next-line: max-line-length
import { UploadOrderBatchFileDialogComponent } from './dialogs/order/upload-order-batch-file-dialog/upload-order-batch-file-dialog.component';
import { SharedModule } from './shared.module';
import { PublicLayoutComponent } from './layouts/public/public-layout.component';
import { EditSiteContactDialogComponent } from './dialogs/site/edit-site-contact-dialog/edit-site-contact-dialog.component';
import { EditPasswordDialogComponent } from './dialogs/user/edit-password-dialog/edit-password-dialog.component';
import { EditPolicySectionDialogComponent } from './dialogs/policy-section/edit-policy-section-dialog/edit-policy-section-dialog.component';
import { EditCmsUserDialogComponent } from './dialogs/user/edit-cms-user-dialog/edit-cms-user-dialog.component';
import { NewCmsUserDialogComponent } from './dialogs/user/new-cms-user-dialog/new-cms-user-dialog.component';
import { EditSiteFeesDialogComponent } from './dialogs/site/edit-site-fees-dialog/edit-site-fees-dialog.component';
import { NewAdminUserDialogComponent } from './dialogs/user/new-admin-user-dialog/new-admin-user-dialog.component';
// tslint:disable-next-line: max-line-length
import { EditSiteDnsVerificationCodeDialogComponent } from './dialogs/site/edit-site-dns-verification-code-dialog/edit-site-dns-verification-code-dialog.component';
import { RequestPasswordReset2Component } from './pages/_common/request-password-reset/request-password-reset.component';
import { ResetPassword2Component } from './pages/_common/reset-password/reset-password.component';
import { VerifyEmailComponent } from './pages/_common/verify-email/verify-email.component';
import { AdminEditPasswordDialogComponent } from './dialogs/user/admin-edit-password-dialog/admin-edit-password-dialog.component';
import { EditSiteChatDialogComponent } from './dialogs/site/edit-site-chat-dialog/edit-site-chat-dialog.component';
// tslint:disable-next-line: max-line-length
import { UploadBackgroundImageDialogComponent } from './dialogs/site/upload-background-image-dialog/upload-background-image-dialog.component';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './util/auth-interceptor/auth-interceptor.util';
// tslint:disable-next-line: max-line-length
import { EditSiteGoogleAnalyticsDialogComponent } from './dialogs/site/edit-site-google-analytics-dialog/edit-site-google-analytics-dialog.component';
// tslint:disable-next-line: max-line-length
import { EditSiteFirstPromoterDialogComponent } from './dialogs/site/edit-site-first-promoter-dialog/edit-site-first-promoter-dialog.component';

@NgModule({
  declarations: [
    AppComponent,
    PublicLayoutComponent,
    CmsLayoutComponent,
    AdminLayoutComponent,
    NewAdminUserDialogComponent,
    EditAdminUserDialogComponent,
    PluralizePipe,
    PhonePipe,
    Login2Component,
    RequestPasswordReset2Component,
    InfoDialogComponent,
    EditSitePropertiesDialogComponent,
    EditSitePricingDialogComponent,
    UploadSiteLogoDialogComponent,
    EditOrderDialogComponent,
    EditCustomerDialogComponent,
    EditUserNameDialogComponent,
    EditSiteBillingAddressDialogComponent,
    EditSiteCreditCardDialogComponent,
    EditSiteContactDialogComponent,
    EditSiteMailingAddressDialogComponent,
    EditFaqDialogComponent,
    EditSiteHeadingDialogComponent,
    EditSitePolicyDialogComponent,
    EditCustomerBillingAddressDialogComponent,
    UploadOrderBatchFileDialogComponent,
    EditPasswordDialogComponent,
    EditPolicySectionDialogComponent,
    EditCmsUserDialogComponent,
    NewCmsUserDialogComponent,
    EditSiteFeesDialogComponent,
    EditSiteDnsVerificationCodeDialogComponent,
    AdminEditPasswordDialogComponent,
    ResetPassword2Component,
    VerifyEmailComponent,
    EditSiteChatDialogComponent,
    UploadBackgroundImageDialogComponent,
    EditSiteGoogleAnalyticsDialogComponent,
    EditSiteFirstPromoterDialogComponent
  ],
  imports: [
    // BrowserModule,
    AngularModule,
    SharedModule,
    AngularFontAwesomeModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatSortModule,
    MatProgressSpinnerModule,
    LeathermanUikitMdcModule,
    LeathermanModule.forRoot(
      appConfig,
      MockErrorDialogService,
      MockConfirmDialogService
    ),
    AppRoutingModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: true })
  ],
  providers: [PluralizePipe, PhonePipe, DatePipe, DecimalPipe, {
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent],
  entryComponents: [
    ErrorDialogComponent,
    ConfirmDialogComponent,
    NewAdminUserDialogComponent,
    EditAdminUserDialogComponent,
    InfoDialogComponent,
    EditSitePropertiesDialogComponent,
    EditSitePricingDialogComponent,
    UploadSiteLogoDialogComponent,
    EditOrderDialogComponent,
    EditCustomerDialogComponent,
    EditUserNameDialogComponent,
    EditSiteBillingAddressDialogComponent,
    EditSiteCreditCardDialogComponent,
    EditSiteContactDialogComponent,
    EditSiteMailingAddressDialogComponent,
    EditFaqDialogComponent,
    EditSiteHeadingDialogComponent,
    EditSitePolicyDialogComponent,
    EditCustomerBillingAddressDialogComponent,
    UploadOrderBatchFileDialogComponent,
    EditPasswordDialogComponent,
    EditPolicySectionDialogComponent,
    EditCmsUserDialogComponent,
    NewCmsUserDialogComponent,
    EditSiteFeesDialogComponent,
    EditSiteDnsVerificationCodeDialogComponent,
    AdminEditPasswordDialogComponent,
    EditSiteChatDialogComponent,
    UploadBackgroundImageDialogComponent,
    EditSiteGoogleAnalyticsDialogComponent,
    EditSiteFirstPromoterDialogComponent
  ]
})
export class AppModule { }
