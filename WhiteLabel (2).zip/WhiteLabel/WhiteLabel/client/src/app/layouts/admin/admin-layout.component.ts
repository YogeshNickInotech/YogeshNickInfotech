import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { MdcTabBar, MdcSnackbar } from '@angular-mdc/web';
import {
  NavigationStateTab,
  NavigationState
} from '../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../services/navigation/navigation.service';
import { NotificationService } from '../../services/notification/notification.service';
import { SnackbarData } from '../../services/notification/snackbar-data.model';
import { UserService } from '../../services/user/user.service';
import { DOCUMENT } from '@angular/common';
import { Site } from '../../models/site/site.model';
import { SiteService } from '../../services/site/site.service';

@Component({
  selector: 'app-mdc-topnav-layout-container',
  templateUrl: './admin-layout.component.html',
  styleUrls: ['./admin-layout.component.scss']
})
export class AdminLayoutComponent implements OnInit {
  public userId: string;
  public userName: string;
  public userRole: string;
  public initialized = false;
  public title = 'White Label Admin';
  public tabs: NavigationStateTab[] = [];
  public showTabs = true;
  public activeTabIndex = 1;
  public anchorMargin = { top: 30 };
  // public siteId: string;
  // public site: Site;

  // @ViewChild('demoScrollingTabBar') tabBarReference: MdcTabBar;

  // constructor
  constructor(
    private userService: UserService,
    private siteService: SiteService,
    private router: Router,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private snackbar: MdcSnackbar,
    @Inject(DOCUMENT) private document: Document
  ) {
    this.title = ' White Label Admin | ' + this.navigationService.navigationState.title;
    this.tabs = this.navigationService.navigationState.tabs;
    this.navigationService.navigationState$.subscribe(value => {
      this.updateTabs(value);
    });
  }

  // ngOnInit
  public async ngOnInit() {
    this.notificationService.snackbarSubject$.subscribe(this.onShowSnackbar);
    this.userService.loginSubject$.subscribe(this.onLoginEvent);
    this.userService.userNameSubject$.subscribe(this.onLoginEvent);
    this.userRole = this.userService._getPrimaryUserRole();
    const user = await this.userService._getCurrentUser();
    if (user) {
      this.userName = `${user.firstName} ${user.lastName}`;
      // this.siteId = await this.userService.getUserSiteId();
      // this.site = await this.siteService.getSite(this.siteId);

      this.title = 'White Label Admin | ' + this.navigationService.navigationState.title;
    }
  }

  public async onAccount() {
    this.router.navigate(['admin/account']);
  }

  public onLoginEvent = async () => {
    const user = await this.userService.getCurrentUser();
    if (!user) {
      return;
    }
    this.userId = user._id;
    this.userRole = this.userService._getPrimaryUserRole();
    this.userName = `${user.firstName} ${user.lastName}`;
  }

  public async onLogout() {
    await this.userService.logoutUser('/');
  }

  public onLogoutEvent() { }

  public async onSettings() {
    this.router.navigate(['admin/settings']);
  }

  public onShowSnackbar = async (snackbarData: SnackbarData) => {
    if (snackbarData.action) {
      const snackbarRef = this.snackbar.open(
        snackbarData.message,
        snackbarData.action,
        {
          dismiss: true
        }
      );
      snackbarRef.afterDismiss().subscribe(reason => {
        if (reason === 'action') {
          switch (snackbarData.type) {
            case 'order-created':
            case 'order-file-import-complete':
              this.router.navigate(['orders', snackbarData.data.orderId]);
              break;
          }
        }
      });
    } else {
      const snackbarRef2 = this.snackbar.open(snackbarData.message, ' ', {
        dismiss: true
      });
      snackbarRef2.afterDismiss().subscribe(reason => { });
    }
  }

  public updateTabs(navigationState: NavigationState) {
    this.activeTabIndex = navigationState.selectedTabIndex;
    this.title = 'White Label Admin | ' + navigationState.title;
    this.showTabs = navigationState.tabs.length > 0 ? true : false;
    this.tabs = navigationState.tabs;
  }

  public tabClicked(route: string) {
    this.router.navigate([route]);
  }
}
