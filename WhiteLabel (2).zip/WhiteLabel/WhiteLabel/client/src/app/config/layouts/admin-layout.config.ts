import { SidenavLayoutConfig, HeaderConfig, SidenavConfig } from 'leatherman';

// Create the config object
const layoutConfig = new SidenavLayoutConfig();

// Configure header
const header = new HeaderConfig();
header.title = 'Administration Portal';
header.logoutRoute = '/admin/login';
layoutConfig.header = header;

// Configure sidenav
const sidenav = new SidenavConfig();
sidenav.addMenuItem('Keys', '/admin/keys');
// sidenav.addMenuItem('User Assessments', '/admin/user-assessments');
sidenav.addMenuItem('Users', '/admin/users');
sidenav.addMenuItem('Admin Users', '/admin/admin-users');
sidenav.addDivider();
sidenav.addMenuItem('Questions', '/admin/questions');
sidenav.addMenuItem('Assessments', '/admin/assessments');
sidenav.addMenuItem('Tokens', '/admin/tokens');
sidenav.addMenuItem('Templates', '/admin/templates');
sidenav.addDivider();
sidenav.addMenuItem('Test', '/admin/test');
layoutConfig.sidenav = sidenav;

// Export the config
export const adminLayoutConfig = layoutConfig;
