import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { Site } from 'src/app/models/site/site.model';
import { DECIMAL_REGEX } from 'src/app/constants/decimal.regex';
import { SiteFees } from 'src/app/models/site/_submodels/site-fees.model';

@Component({
  selector: 'app-edit-site-fees-dialog',
  templateUrl: './edit-site-fees-dialog.component.html',
  styleUrls: ['./edit-site-fees-dialog.component.scss']
})
export class EditSiteFeesDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit Fees';
  public createButtonLabel = 'Update';
  public siteForm: FormGroup;
  constructor(
    public dialogRef: MdcDialogRef<EditSiteFeesDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public site: Site
  ) {
    if (!site.fees) {
      site.fees = new SiteFees();
    }
  }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.siteForm.invalid) {
      return;
    }

    const site = ObjectCopyUtil.deepCopy(this.site);
    site.fees.monthly = parseFloat(this.siteForm.get('monthly').value);
    site.fees.transaction = parseFloat(this.siteForm.get('transaction').value);

    const dialogResult = new DialogResult(DialogButton.OK, site);

    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    this.siteForm = new FormGroup({
      monthly: new FormControl(this.site.fees.monthly, [Validators.required, Validators.pattern(DECIMAL_REGEX)]),
      transaction: new FormControl(this.site.fees.transaction, [Validators.required, Validators.pattern(DECIMAL_REGEX)]),
    });
  }
}
