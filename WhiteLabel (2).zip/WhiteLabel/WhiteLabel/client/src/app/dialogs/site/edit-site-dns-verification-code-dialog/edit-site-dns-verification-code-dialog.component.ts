import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { Site } from 'src/app/models/site/site.model';
import { DECIMAL_REGEX } from 'src/app/constants/decimal.regex';
import { SiteFees } from 'src/app/models/site/_submodels/site-fees.model';

@Component({
  selector: 'app-edit-site-dns-verification-code-dialog',
  templateUrl: './edit-site-dns-verification-code-dialog.component.html',
  styleUrls: ['./edit-site-dns-verification-code-dialog.component.scss']
})
export class EditSiteDnsVerificationCodeDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit DNS Verification Code';
  public createButtonLabel = 'Update';
  public siteForm: FormGroup;
  constructor(
    public dialogRef: MdcDialogRef<EditSiteDnsVerificationCodeDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public site: Site
  ) {
    if (!site.fees) {
      site.fees = new SiteFees();
    }
  }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.siteForm.invalid) {
      return;
    }

    const site = ObjectCopyUtil.deepCopy(this.site);
    site.dnsVerificationCode = this.siteForm.get('dnsVerificationCode').value;
    site.firstDnsHost = this.siteForm.get('firstDnsHost').value;
    site.secondDnsHost = this.siteForm.get('secondDnsHost').value;

    const dialogResult = new DialogResult(DialogButton.OK, site);

    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    if (!this.site.firstDnsHost) {
      this.site.firstDnsHost = '@';
    }
    if (!this.site.secondDnsHost) {
      this.site.secondDnsHost = 'app';
    }
    this.siteForm = new FormGroup({
      dnsVerificationCode: new FormControl(this.site.dnsVerificationCode, [Validators.required]),
      firstDnsHost: new FormControl(this.site.firstDnsHost, [Validators.required]),
      secondDnsHost: new FormControl(this.site.secondDnsHost, [Validators.required]),
    });
  }
}
