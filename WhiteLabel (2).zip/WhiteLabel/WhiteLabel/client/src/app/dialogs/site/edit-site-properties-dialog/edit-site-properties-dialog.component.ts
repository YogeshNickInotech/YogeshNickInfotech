import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { Site } from 'src/app/models/site/site.model';
import { THEMES } from 'src/app/constants/themes.const';
import { BACKGROUND_IMAGES, BACKGROUND_IMAGES2, BACKGROUND_IMAGES3 } from 'src/app/constants/background-images.const';

@Component({
  selector: 'app-edit-site-properties-dialog',
  templateUrl: './edit-site-properties-dialog.component.html',
  styleUrls: ['./edit-site-properties-dialog.component.scss']
})
export class EditSitePropertiesDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit Site Properties';
  public createButtonLabel = 'Update';
  public siteForm: FormGroup;
  public themes = THEMES;
  // public backgroundImages = BACKGROUND_IMAGES;
  // public backgroundImages2 = BACKGROUND_IMAGES2;
  // public backgroundImages3 = BACKGROUND_IMAGES3;

  constructor(
    public dialogRef: MdcDialogRef<EditSitePropertiesDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public site: Site
  ) {
    if (!this.site) {
      this.dialogTitle = 'New';
      this.dialogTitle = 'New Site';
      this.site = new Site();
    }
  }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.siteForm.invalid) {
      return;
    }

    const site = ObjectCopyUtil.deepCopy(this.site);
    site.name = this.siteForm.get('name').value;
    site.displayName = this.siteForm.get('displayName').value;
    site.url = this.siteForm.get('url').value;
    site.appUrl = this.siteForm.get('appUrl').value;
    site.theme = this.siteForm.get('theme').value;
    site.hideDisplayName =  this.siteForm.get('hideDisplayName').value;
    // site.backgroundImage = this.siteForm.get('backgroundImage').value;
    // site.backgroundImage2 = this.siteForm.get('backgroundImage2').value;
    // site.backgroundImage3 = this.siteForm.get('backgroundImage3').value;

    site.url = site.url.trim().replace(/^https?:\/\//g, '');
    site.url = site.url.trim().replace(/www\./g, '');

    const dialogResult = new DialogResult(DialogButton.OK, site);

    this.dialogRef.close(dialogResult);
  }

  public urlChanged() {
    console.log('URL changed');
  }

  private initForm() {
    if (!this.site.theme) {
      this.site.theme = 'Default';
    }

    if (!this.site.appUrl && this.site.url) {
      this.site.appUrl = 'app.' + this.site.url;
    }

    if (!this.site.backgroundImage2) {
      this.site.backgroundImage2 = 'BG1';
    }

    if (!this.site.backgroundImage3) {
      this.site.backgroundImage3 = 'BG1';
    }

    this.siteForm = new FormGroup({
      name: new FormControl(this.site.name, Validators.required),
      displayName: new FormControl(this.site.displayName, Validators.required),
      url: new FormControl(this.site.url, Validators.required),
      appUrl: new FormControl(this.site.appUrl, Validators.required),
      theme: new FormControl(this.site.theme, Validators.required),
      hideDisplayName: new FormControl(this.site.hideDisplayName),
      // backgroundImage: new FormControl(this.site.backgroundImage, Validators.required),
      // backgroundImage2: new FormControl(this.site.backgroundImage2, Validators.required),
      // backgroundImage3: new FormControl(this.site.backgroundImage3, Validators.required)
    });
  }
}
