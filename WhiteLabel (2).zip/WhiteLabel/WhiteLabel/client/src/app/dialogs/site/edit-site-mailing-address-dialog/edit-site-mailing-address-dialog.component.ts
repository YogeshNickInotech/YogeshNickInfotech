import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { Site } from 'src/app/models/site/site.model';
import { SiteContact } from 'src/app/models/site/_submodels/site-contact.model';
import { SiteContactAddress } from 'src/app/models/site/_submodels/site-contact-address.model';

@Component({
  selector: 'app-edit-site-mailing-address-dialog',
  templateUrl: './edit-site-mailing-address-dialog.component.html',
  styleUrls: ['./edit-site-mailing-address-dialog.component.scss']
})
export class EditSiteMailingAddressDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit Mailing Address';
  public createButtonLabel = 'Update';
  public siteForm: FormGroup;
  constructor(
    public dialogRef: MdcDialogRef<EditSiteMailingAddressDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public site: Site
  ) {
    if (!this.site.contact) {
      this.site.contact = new SiteContact();
    }
    if (!this.site.contact.mailingAddress) {
      this.site.contact.mailingAddress = new SiteContactAddress();
    }
  }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.siteForm.invalid) {
      return;
    }

    const site = ObjectCopyUtil.deepCopy(this.site);
    site.contact.mailingAddress.address = this.siteForm.get('address').value;
    site.contact.mailingAddress.city = this.siteForm.get('city').value;
    site.contact.mailingAddress.state = this.siteForm.get('state').value;
    site.contact.mailingAddress.zip = this.siteForm.get('zip').value;

    const dialogResult = new DialogResult(DialogButton.OK, site);

    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    this.siteForm = new FormGroup({
      address: new FormControl(this.site.contact.mailingAddress.address),
      city: new FormControl(this.site.contact.mailingAddress.city),
      state: new FormControl(this.site.contact.mailingAddress.state),
      zip: new FormControl(this.site.contact.mailingAddress.zip)
    });
  }
}
