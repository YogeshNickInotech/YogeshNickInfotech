import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Site } from 'src/app/models/site/site.model';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';

@Component({
  selector: 'app-edit-site-first-promoter-dialog',
  templateUrl: './edit-site-first-promoter-dialog.component.html',
  styleUrls: ['./edit-site-first-promoter-dialog.component.scss']
})
export class EditSiteFirstPromoterDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit FirstPromoter Settings';
  public createButtonLabel = 'Update';
  public firstPromoterSettingsForm: FormGroup;

  constructor(
    public dialogRef: MdcDialogRef<EditSiteFirstPromoterDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public site: Site
  ) { }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    this.validateForm();
    if (this.firstPromoterSettingsForm.invalid) {
      return;
    }

    const site = ObjectCopyUtil.deepCopy(this.site);
    site.firstPromoterEnabled = this.toTrueFalse(this.firstPromoterSettingsForm.get('firstPromoterEnabled').value);
    site.firstPromoterKey = this.firstPromoterSettingsForm.get('firstPromoterKey').value;
    site.firstPromoterWid = this.firstPromoterSettingsForm.get('firstPromoterWid').value;
    const dialogResult = new DialogResult(DialogButton.OK, site);

    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    this.firstPromoterSettingsForm = new FormGroup({
      firstPromoterEnabled: new FormControl(this.toYesNo(this.site.firstPromoterEnabled)),
      firstPromoterKey: new FormControl(this.site.firstPromoterKey, [this.validateFirstPromoterDetail]),
      firstPromoterWid: new FormControl(this.site.firstPromoterWid, [this.validateFirstPromoterDetail])

    });
  }

  private toTrueFalse(value: string): boolean {
    if (value.toLowerCase() === 'yes') {
      return true;
    }
    return false;
  }

  private toYesNo(value: boolean): string {
    if (value === true) {
      return 'Yes';
    }
    return 'No';
  }

  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        control.updateValueAndValidity();
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  private validateFirstPromoterDetail = (control: FormControl) => {
    try {
      let value: string = control.value;
      value = value.trim();

      const firstPromoterEnabled = this.toTrueFalse(this.firstPromoterSettingsForm.get('firstPromoterEnabled').value);

      if (firstPromoterEnabled === false) {
        return {};
      }

      if (value.length === 0) {
        return {
          required: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidFirstPromoterDetails: {
          invalid: true
        }
      };
    }
  }

  private validateForm(): boolean {
    this.validateAllFormFields(this.firstPromoterSettingsForm);
    this.firstPromoterSettingsForm.markAsDirty();

    return true;
  }
}
