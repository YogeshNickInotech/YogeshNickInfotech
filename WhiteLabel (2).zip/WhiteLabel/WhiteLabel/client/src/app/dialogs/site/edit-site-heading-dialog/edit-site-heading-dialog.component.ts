import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { Site } from 'src/app/models/site/site.model';
import { THEMES } from 'src/app/constants/themes.const';

@Component({
  selector: 'app-edit-site-heading-dialog',
  templateUrl: './edit-site-heading-dialog.component.html',
  styleUrls: ['./edit-site-heading-dialog.component.scss']
})
export class EditSiteHeadingDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit Heading';
  public createButtonLabel = 'Update';
  public siteForm: FormGroup;
  public themes = THEMES;

  constructor(
    public dialogRef: MdcDialogRef<EditSiteHeadingDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public heading: string
  ) { }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.siteForm.invalid) {
      return;
    }

    const heading = this.siteForm.get('heading').value;

    const dialogResult = new DialogResult(DialogButton.OK, heading);

    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    this.siteForm = new FormGroup({
      heading: new FormControl(this.heading, Validators.required)
    });
  }
}
