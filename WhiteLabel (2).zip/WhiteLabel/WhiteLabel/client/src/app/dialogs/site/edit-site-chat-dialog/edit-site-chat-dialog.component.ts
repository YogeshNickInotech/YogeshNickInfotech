import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Site } from 'src/app/models/site/site.model';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';

@Component({
  selector: 'app-edit-site-chat-dialog',
  templateUrl: './edit-site-chat-dialog.component.html',
  styleUrls: ['./edit-site-chat-dialog.component.scss']
})
export class EditSiteChatDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit Chat Settings';
  public createButtonLabel = 'Update';
  public chatSettingsForm: FormGroup;

  constructor(
    public dialogRef: MdcDialogRef<EditSiteChatDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public site: Site
  ) { }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    this.validateForm();
    if (this.chatSettingsForm.invalid) {
      return;
    }

    const site = ObjectCopyUtil.deepCopy(this.site);
    site.chatEnabled = this.toTrueFalse(this.chatSettingsForm.get('chatEnabled').value);
    site.chatraId = this.chatSettingsForm.get('chatraId').value;

    const dialogResult = new DialogResult(DialogButton.OK, site);

    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    this.chatSettingsForm = new FormGroup({
      chatEnabled: new FormControl(this.toYesNo(this.site.chatEnabled)),
      chatraId: new FormControl(this.site.chatraId, [this.validateChatraId])
    });
  }

  private toTrueFalse(value: string): boolean {
    if (value.toLowerCase() === 'yes') {
      return true;
    }
    return false;
  }

  private toYesNo(value: boolean): string {
    if (value === true) {
      return 'Yes';
    }
    return 'No';
  }

  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        control.updateValueAndValidity();
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  private validateChatraId = (control: FormControl) => {
    try {
      let value: string = control.value;
      value = value.trim();

      const chatEnabled = this.toTrueFalse(this.chatSettingsForm.get('chatEnabled').value);

      if (chatEnabled === false) {
        return {};
      }

      if (value.length === 0) {
        return {
          required: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidChatraId: {
          invalid: true
        }
      };
    }
  }

  private validateForm(): boolean {
    this.validateAllFormFields(this.chatSettingsForm);
    this.chatSettingsForm.markAsDirty();

    return true;
  }
}
