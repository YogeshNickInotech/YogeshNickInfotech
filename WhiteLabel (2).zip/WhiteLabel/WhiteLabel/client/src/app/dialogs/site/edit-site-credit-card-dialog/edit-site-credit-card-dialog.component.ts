import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { Site } from 'src/app/models/site/site.model';

@Component({
  selector: 'app-edit-site-credit-card-dialog',
  templateUrl: './edit-site-credit-card-dialog.component.html',
  styleUrls: ['./edit-site-credit-card-dialog.component.scss']
})
export class EditSiteCreditCardDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit Credit Card';
  public createButtonLabel = 'Update';
  public siteForm: FormGroup;
  constructor(
    public dialogRef: MdcDialogRef<EditSiteCreditCardDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public site: Site
  ) { }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    // this.validateForm();
    if (this.siteForm.invalid) {
      return;
    }

    const site = ObjectCopyUtil.deepCopy(this.site);
    let creditCardNumber: string = this.siteForm.get(
      'creditCardNumber'
    ).value;
    creditCardNumber = creditCardNumber.replace(/[\s-]+/g, '').trim();
    site.billing.creditCard.creditCardNumber = creditCardNumber;
    site.billing.creditCard.nameOnCard = this.siteForm.get('nameOnCard').value;
    site.billing.creditCard.expirationMonth = parseInt(this.siteForm.get(
      'expirationMonth'
    ).value, 10);
    site.billing.creditCard.expirationYear = parseInt(this.siteForm.get(
      'expirationYear'
    ).value, 10);
    site.billing.creditCard.cvv = this.siteForm.get('cvv').value;

    const dialogResult = new DialogResult(DialogButton.OK, site);

    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    let creditCardNumber = this.site.billing.creditCard.creditCardNumber.trim();
    if (creditCardNumber) {
      creditCardNumber = creditCardNumber.substr(0, 4) + '-' + creditCardNumber.substr(4, 4) + '-'
        + creditCardNumber.substr(8, 4) + '-' + creditCardNumber.substr(12, 4);
    }
    this.siteForm = new FormGroup({
      creditCardNumber: new FormControl(
        creditCardNumber, [Validators.required,
        Validators.pattern(/^\d{4}[\s-]*\d{4}[\s-]*\d{4}[\s-]*\d{4}$/)]
      ),
      nameOnCard: new FormControl(this.site.billing.creditCard.nameOnCard, [Validators.required]),
      expirationMonth: new FormControl(
        this.site.billing.creditCard.expirationMonth.toString(), [Validators.required]
      ),
      expirationYear: new FormControl(
        this.site.billing.creditCard.expirationYear.toString(), [Validators.required]
      ),
      cvv: new FormControl(this.site.billing.creditCard.cvv, [Validators.required,
      Validators.pattern(/^\d{3}$/)])
    });
  }

  private validateForm(): boolean {
    // if (!this.siteForm.valid) {
    this.validateAllFormFields(this.siteForm);
    this.siteForm.markAsDirty();
    //   return false;
    // }

    return true;
  }

  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
