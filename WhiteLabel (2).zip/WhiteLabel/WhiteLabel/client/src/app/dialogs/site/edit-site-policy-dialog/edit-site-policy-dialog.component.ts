import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { Site } from 'src/app/models/site/site.model';
import { THEMES } from 'src/app/constants/themes.const';

@Component({
  selector: 'app-edit-site-policy-dialog',
  templateUrl: './edit-site-policy-dialog.component.html',
  styleUrls: ['./edit-site-policy-dialog.component.scss']
})
export class EditSitePolicyDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit Site Policy';
  public createButtonLabel = 'Update';
  public siteForm: FormGroup;
  public themes = THEMES;

  constructor(
    public dialogRef: MdcDialogRef<EditSitePolicyDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public policy: string
  ) { }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.siteForm.invalid) {
      return;
    }

    const policy = this.siteForm.get('policy').value;

    const dialogResult = new DialogResult(DialogButton.OK, policy);

    this.dialogRef.close(dialogResult);
  }
  

  private initForm() {
    this.siteForm = new FormGroup({
      policy: new FormControl(this.policy, Validators.required)
    });
  }
}
