import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { Site } from 'src/app/models/site/site.model';
import { THEMES } from 'src/app/constants/themes.const';
import { SiteContact } from 'src/app/models/site/_submodels/site-contact.model';

@Component({
  selector: 'app-edit-site-contact-dialog',
  templateUrl: './edit-site-contact-dialog.component.html',
  styleUrls: ['./edit-site-contact-dialog.component.scss']
})
export class EditSiteContactDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit Site Contact';
  public createButtonLabel = 'Update';
  public siteForm: FormGroup;
  public themes = THEMES;

  constructor(
    public dialogRef: MdcDialogRef<EditSiteContactDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public site: Site
  ) {
    if (!this.site.contact) {
      this.site.contact = new SiteContact();
    }
  }

  // ngOnInitc
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.siteForm.invalid) {
      return;
    }

    const site = ObjectCopyUtil.deepCopy(this.site);
    site.contact.email = this.siteForm.get('email').value;
    site.contact.phone = this.siteForm.get('phone').value;

    const dialogResult = new DialogResult(DialogButton.OK, site);

    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    if (!this.site.theme) {
      this.site.theme = 'Default';
    }

    this.siteForm = new FormGroup({
      email: new FormControl(this.site.contact.email, Validators.required),
      phone: new FormControl(this.site.contact.phone, Validators.required)
    });
  }
}
