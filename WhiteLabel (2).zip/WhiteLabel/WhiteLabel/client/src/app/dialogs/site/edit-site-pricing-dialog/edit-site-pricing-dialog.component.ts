import { Component, Inject, OnInit } from "@angular/core";
import { MdcDialogRef, MDC_DIALOG_DATA } from "@angular-mdc/web";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { DialogResult, DialogButton, ObjectCopyUtil } from "leatherman";
import { Site } from "src/app/models/site/site.model";
import { DECIMAL_REGEX, INTEGER_REGEX } from "src/app/constants/decimal.regex";
import { SitePricingTier } from "src/app/models/site/_submodels/site-pricing-tier.model";
import { SitePricing } from "src/app/models/site/_submodels/site-pricing.model";

@Component({
  selector: "app-edit-site-pricing-dialog",
  templateUrl: "./edit-site-pricing-dialog.component.html",
  styleUrls: ["./edit-site-pricing-dialog.component.scss"]
})
export class EditSitePricingDialogComponent implements OnInit {
  sitePricingTiers: number[] = [];
  public dialogMode = "Edit";
  public dialogTitle = "Edit Pricing";
  public createButtonLabel = "Update";
  public defaultPriceControlName = "defaultPrice";
  public quantityControlName = "pricingTierQuantity";
  public priceControlName = "pricingTierPrice";
  public siteForm: FormGroup;
  constructor(
    public dialogRef: MdcDialogRef<EditSitePricingDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public site: Site
  ) {}

  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.siteForm.invalid) {
      return;
    }

    const site = ObjectCopyUtil.deepCopy(this.site);
    site.pricing = new SitePricing();
    site.pricing.defaultPrice = parseFloat(
      this.siteForm.get(this.defaultPriceControlName).value
    );
    site.pricing.sitePricingTiers = [];
    for (let i = 0; i < this.sitePricingTiers.length; i++) {
      let pricingTierIndex = this.sitePricingTiers[i];
      let pricingTier = new SitePricingTier();
      pricingTier.quantity = parseInt(
        this.siteForm.get(this.quantityControlName + pricingTierIndex).value
      );
      pricingTier.unitPrice = parseFloat(
        this.siteForm.get(this.priceControlName + pricingTierIndex).value
      );
      site.pricing.sitePricingTiers.push(pricingTier);
    }
    const dialogResult = new DialogResult(DialogButton.OK, site);
    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    const { defaultPrice, sitePricingTiers } = this.site.pricing;
    this.siteForm = new FormGroup({
      defaultPrice: new FormControl(defaultPrice, [
        Validators.required,
        Validators.pattern(DECIMAL_REGEX),
        Validators.min(0.5)
      ])
    });

    if (sitePricingTiers) {
      for (let i = 0; i < sitePricingTiers.length; i++) {
        const pricingTier = sitePricingTiers[i];
        this.siteForm.addControl(
          this.quantityControlName + i,
          new FormControl(pricingTier.quantity, [
            Validators.required,
            Validators.pattern(INTEGER_REGEX)
          ])
        );
        this.siteForm.addControl(
          this.priceControlName + i,
          new FormControl(pricingTier.unitPrice, [
            Validators.required,
            Validators.pattern(DECIMAL_REGEX)
          ])
        );
        this.sitePricingTiers.push(i);
      }
    }
  }

  addPriceTier() {
    let pricingTierIndex = this.sitePricingTiers[this.sitePricingTiers.length - 1] + 1 || 0;
    this.siteForm.addControl(
      this.quantityControlName + pricingTierIndex,
      new FormControl("", [
        Validators.required,
        Validators.pattern(INTEGER_REGEX)
      ])
    );
    this.siteForm.addControl(
      this.priceControlName + pricingTierIndex,
      new FormControl("", [
        Validators.required,
        Validators.pattern(DECIMAL_REGEX)
      ])
    );
    this.sitePricingTiers.push(pricingTierIndex);
  }

  removePriceTier(removeIndex) {
    const splicePriceTierIndex = this.sitePricingTiers.splice(removeIndex, 1);
    const pricingTierIndex = splicePriceTierIndex[0];
    this.siteForm.removeControl(this.quantityControlName + pricingTierIndex);
    this.siteForm.removeControl(this.priceControlName + pricingTierIndex);
  }
}
