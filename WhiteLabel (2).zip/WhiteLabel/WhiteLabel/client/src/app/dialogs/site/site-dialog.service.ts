import { Injectable } from '@angular/core';
import { DialogResult } from 'leatherman';
import { MdcDialog } from '@angular-mdc/web';
import { User } from '../../models/user/user.model';
import { EditSitePropertiesDialogComponent } from './edit-site-properties-dialog/edit-site-properties-dialog.component';
import { Site } from 'src/app/models/site/site.model';
import { EditSitePricingDialogComponent } from './edit-site-pricing-dialog/edit-site-pricing-dialog.component';
import { Asset } from 'src/app/models/asset/asset.model';
import { UploadSiteLogoDialogComponent } from './upload-site-logo-dialog/upload-site-logo-dialog.component';
import { EditSiteBillingAddressDialogComponent } from './edit-site-billing-address-dialog/edit-site-billing-address-dialog.component';
import { EditSiteCreditCardDialogComponent } from './edit-site-credit-card-dialog/edit-site-credit-card-dialog.component';
import { EditSiteContactDialogComponent } from './edit-site-contact-dialog/edit-site-contact-dialog.component';
import { EditSiteMailingAddressDialogComponent } from './edit-site-mailing-address-dialog/edit-site-mailing-address-dialog.component';
import { EditSiteHeadingDialogComponent } from './edit-site-heading-dialog/edit-site-heading-dialog.component';
import { EditSitePolicyDialogComponent } from './edit-site-policy-dialog/edit-site-policy-dialog.component';
import { EditSiteFeesDialogComponent } from './edit-site-fees-dialog/edit-site-fees-dialog.component';
// tslint:disable-next-line: max-line-length
import { EditSiteDnsVerificationCodeDialogComponent } from './edit-site-dns-verification-code-dialog/edit-site-dns-verification-code-dialog.component';
import { EditSiteChatDialogComponent } from './edit-site-chat-dialog/edit-site-chat-dialog.component';
import { UploadBackgroundImageDialogComponent } from './upload-background-image-dialog/upload-background-image-dialog.component';
import { EditSiteGoogleAnalyticsDialogComponent } from './edit-site-google-analytics-dialog/edit-site-google-analytics-dialog.component';
import { EditSiteFirstPromoterDialogComponent } from './edit-site-first-promoter-dialog/edit-site-first-promoter-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class SiteDialogService {
  constructor(public dialog: MdcDialog) { }

  public async openEditSiteBillingAddressDialog(
    site: Site
  ): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSiteBillingAddressDialogComponent, {
      clickOutsideToClose: false,
      data: site
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditSiteChatraSettingsDialog(
    site: Site
  ): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSiteChatDialogComponent, {
      clickOutsideToClose: false,
      data: site
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditGoogleAnalyticsSettingsDialog(
    site: Site
  ): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSiteGoogleAnalyticsDialogComponent, {
      clickOutsideToClose: false,
      data: site
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditSiteFirstPromoterSettingsDialog(
    site: Site
  ): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSiteFirstPromoterDialogComponent, {
      clickOutsideToClose: false,
      data: site
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditSiteDnsVerificationCodeDialog(
    site: Site
  ): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSiteDnsVerificationCodeDialogComponent, {
      clickOutsideToClose: false,
      data: site
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditSiteContactDialog(
    site: Site
  ): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSiteContactDialogComponent, {
      clickOutsideToClose: false,
      data: site
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditSiteCreditCardDialog(
    site: Site
  ): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSiteCreditCardDialogComponent, {
      clickOutsideToClose: false,
      data: site
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditSiteFeesDialog(
    site: Site
  ): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSiteFeesDialogComponent, {
      clickOutsideToClose: false,
      data: site
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditSiteHeadingDialog(
    heading: string
  ): Promise<DialogResult<string>> {
    const dialogRef = this.dialog.open(EditSiteHeadingDialogComponent, {
      clickOutsideToClose: false,
      data: heading
    });

    const result: DialogResult<string> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditSiteMailingAddressDialog(
    site: Site
  ): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSiteMailingAddressDialogComponent, {
      clickOutsideToClose: false,
      data: site
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditSitePolicyDialog(
    policy: string
  ): Promise<DialogResult<string>> {
    const dialogRef = this.dialog.open(EditSitePolicyDialogComponent, {
      clickOutsideToClose: false,
      data: policy
    });

    const result: DialogResult<string> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditSitePropertiesDialog(
    site: Site
  ): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSitePropertiesDialogComponent, {
      clickOutsideToClose: false,
      data: site
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditSitePricingDialog(
    site: Site
  ): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSitePricingDialogComponent, {
      clickOutsideToClose: false,
      data: site
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openNewSitePropertiesDialog(): Promise<DialogResult<Site>> {
    const dialogRef = this.dialog.open(EditSitePropertiesDialogComponent, {
      clickOutsideToClose: false,
    });

    const result: DialogResult<Site> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openUploadBackgroundImageDialog(
    siteId: string,
    token: string,
    position: string
  ): Promise<DialogResult<Asset>> {
    const dialogRef = this.dialog.open(UploadBackgroundImageDialogComponent, {
      clickOutsideToClose: false,
      data: { siteId, token, position }
    });

    const result: DialogResult<Asset> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openUploadSiteLogoDialog(
    siteId: string
  ): Promise<DialogResult<Asset>> {
    const dialogRef = this.dialog.open(UploadSiteLogoDialogComponent, {
      clickOutsideToClose: false,
      data: siteId
    });

    const result: DialogResult<Asset> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }
}
