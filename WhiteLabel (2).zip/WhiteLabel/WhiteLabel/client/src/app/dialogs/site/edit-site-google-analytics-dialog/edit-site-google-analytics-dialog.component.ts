import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Site } from 'src/app/models/site/site.model';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';

@Component({
  selector: 'app-edit-site-google-analytics-dialog',
  templateUrl: './edit-site-google-analytics-dialog.component.html',
  styleUrls: ['./edit-site-google-analytics-dialog.component.scss']
})
export class EditSiteGoogleAnalyticsDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit Google Analytics Settings';
  public createButtonLabel = 'Update';
  public googleAnalyticsSettingsForm: FormGroup;

  constructor(
    public dialogRef: MdcDialogRef<EditSiteGoogleAnalyticsDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public site: Site
  ) { }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    this.validateForm();
    if (this.googleAnalyticsSettingsForm.invalid) {
      return;
    }

    const site = ObjectCopyUtil.deepCopy(this.site);
    site.googleAnalyticsEnabled = this.toTrueFalse(this.googleAnalyticsSettingsForm.get('googleAnalyticsEnabled').value);
    site.googleAnalyticsId = this.googleAnalyticsSettingsForm.get('googleAnalyticsId').value;

    const dialogResult = new DialogResult(DialogButton.OK, site);

    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    this.googleAnalyticsSettingsForm = new FormGroup({
      googleAnalyticsEnabled: new FormControl(this.toYesNo(this.site.googleAnalyticsEnabled)),
      googleAnalyticsId: new FormControl(this.site.googleAnalyticsId, [this.validateGoogleAnalyticsId])
    });
  }

  private toTrueFalse(value: string): boolean {
    if (value.toLowerCase() === 'yes') {
      return true;
    }
    return false;
  }

  private toYesNo(value: boolean): string {
    if (value === true) {
      return 'Yes';
    }
    return 'No';
  }

  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        control.updateValueAndValidity();
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  private validateGoogleAnalyticsId = (control: FormControl) => {
    try {
      let value: string = control.value;
      value = value.trim();

      const chatEnabled = this.toTrueFalse(this.googleAnalyticsSettingsForm.get('googleAnalyticsEnabled').value);

      if (chatEnabled === false) {
        return {};
      }

      if (value.length === 0) {
        return {
          required: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidChatraId: {
          invalid: true
        }
      };
    }
  }

  private validateForm(): boolean {
    this.validateAllFormFields(this.googleAnalyticsSettingsForm);
    this.googleAnalyticsSettingsForm.markAsDirty();

    return true;
  }
}
