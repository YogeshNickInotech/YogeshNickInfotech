import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { DialogResult, DialogButton } from 'leatherman';
import { FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { SiteDataService } from 'src/app/services/site/site-data.service';

export class ColumnHeader {
  public index: number;
  public name: string;
}

@Component({
  selector: 'app-upload-site-logo-dialog',
  templateUrl: './upload-site-logo-dialog.component.html',
  styleUrls: ['./upload-site-logo-dialog.component.scss']
})
export class UploadSiteLogoDialogComponent implements OnInit {
  public dialogMode = 'standard';
  public file: File = null;

  public mapForm: FormGroup;
  public dialogTitle = 'Select Logo File';
  public uploadProgress: Observable<number>;
  public currentPage = 'page1';
  public submitButtonLabel = 'Next';
  public fileTypeError = false;
  public uploadComplete = false;
  public uploadStarted = false;
  public fileAdded = false;

  public columns: ColumnHeader[] = [];

  constructor(
    public siteDataService: SiteDataService,
    public dialogRef: MdcDialogRef<UploadSiteLogoDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public siteId: string
  ) { }

  // ngOnInit
  public ngOnInit() {

  }

  public getProgressValue(progress: number): number {
    const progressPercent = progress / 100;
    return progressPercent;
  }

  public getUploadLabel(): string {
    if (this.uploadComplete === false) {
      return 'Uploading file: ' + this.file.name;
    } else {
      return 'Upload complete';
    }
  }

  public async next() {
    this.currentPage = 'page2';
    this.dialogTitle = 'Upload File';
    // await this.uploadMappedFile();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public async onFileAdded(event) {
    const file = event.target.files[0];
    if (file && file.type.includes("image/")) {
      this.fileTypeError = false;
      this.file = file;
      const fileName = this.file.name;
      this.currentPage = 'page2';
      await this.uploadLogo();
    } else {
      this.fileTypeError = true;
    }
  }

  public submit() {
    const dialogResult = new DialogResult(DialogButton.OK);
    this.dialogRef.close(dialogResult);
  }

  public async uploadLogo() {
    this.dialogTitle = 'Upload Logo';
    this.uploadStarted = true;

    const formData = new FormData();
    formData.append('file', this.file, this.file.name);
    formData.append('token', 'logo');
    formData.append('siteId', this.siteId);

    this.uploadProgress = this.siteDataService.uploadFile(
      formData
    );

    this.uploadProgress.subscribe(
      next => { },
      error => { },
      () => {
        this.uploadComplete = true;
      }
    );
  }
}
