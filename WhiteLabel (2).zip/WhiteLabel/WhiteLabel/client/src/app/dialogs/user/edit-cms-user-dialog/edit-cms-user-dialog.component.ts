import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { User } from '../../../models/user/user.model';
import { EMAIL_REGEX } from 'src/app/constants/email.regex';

/**
 * Dialog component to edit a site owner
 */
@Component({
  selector: 'app-edit-cms-user-dialog',
  templateUrl: './edit-cms-user-dialog.component.html',
  styleUrls: ['./edit-cms-user-dialog.component.scss']
})
export class EditCmsUserDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit User';
  public createButtonLabel = 'Update';
  public userForm: FormGroup;

  /**
   * Constructor
   * @param dialogRef - A reference to the dialog
   * @param user - The user being edited
   */
  constructor(
    public dialogRef: MdcDialogRef<EditCmsUserDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public user: User
  ) { }

  /**
   * Initialize the component
   */
  public ngOnInit() {
    this.initForm();
  }

  /**
   * Event handler for the cancel button
   */
  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  /**
   * Event handler for the submit button
   */
  public onSubmit(): void {
    if (this.userForm.invalid) {
      return;
    }

    const user = ObjectCopyUtil.deepCopy(this.user);
    user.firstName = this.userForm.get('firstName').value;
    user.lastName = this.userForm.get('lastName').value;
    user.email = this.userForm.get('email').value;

    const dialogResult = new DialogResult(DialogButton.OK, user);
    this.dialogRef.close(dialogResult);
  }

  /**
   * Initialize the form controls
   */
  private initForm() {
    const role = this.user.roles[0];
    this.userForm = new FormGroup({
      firstName: new FormControl(this.user.firstName, Validators.required),
      lastName: new FormControl(this.user.lastName, Validators.required),
      email: new FormControl(this.user.email, this.validateEmail)
    });
  }

  /**
   * Validate the contents of the email control
   */
  private validateEmail = (control: FormControl) => {
    try {

      const value = control.value;

      if (!value) {
        return {
          required: {
            invalid: true,
          },
        };
      }

      if (EMAIL_REGEX.test(value) === false) {
        return {
          invalidEmail: {
            invalid: true,
          },
        };
      }

      return {};
    } catch (error) {
      return {
        invalidEmail: {
          invalid: true,
        },
      };
    }
  }
}
