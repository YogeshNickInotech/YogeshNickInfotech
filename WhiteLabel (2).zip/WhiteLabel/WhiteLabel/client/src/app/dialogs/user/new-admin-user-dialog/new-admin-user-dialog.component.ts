import { Component, OnInit } from '@angular/core';
import { MdcDialogRef } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton } from 'leatherman';
import { NewUserRequest } from '../../../models/user/new-user-request.model';
import { EMAIL_REGEX } from 'src/app/constants/email.regex';
import { SPECIAL_CHARACTER_REGEX } from 'src/app/constants/special-character.regex';
import { LOWER_CASE_REGEX } from 'src/app/constants/lower-case.regex';
import { UPPER_CASE_REGEX } from 'src/app/constants/upper-case.regex';
import { NUMBER_REGEX } from 'src/app/constants/number.regex';

/**
 * Dialog component to create a new admin user
 */
@Component({
  selector: 'app-new-admin-user-dialog',
  templateUrl: './new-admin-user-dialog.component.html',
  styleUrls: ['./new-admin-user-dialog.component.scss']
})
export class NewAdminUserDialogComponent implements OnInit {
  public dialogMode = 'New';
  public dialogTitle = 'New Admin User';
  public createButtonLabel = 'Create';
  public userForm: FormGroup;

  /**
   * Constructor
   * @param dialogRef - A reference to the dialog
   */
  constructor(public dialogRef: MdcDialogRef<NewAdminUserDialogComponent>) { }

  /**
   * Initialize the component
   */
  public ngOnInit() {
    this.initForm();
  }

  /**
   * Event handler for the cancel button
   */
  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  /**
   * Event handler for the submit button
   */
  public onSubmit(): void {
    if (this.userForm.invalid) {
      return;
    }

    const firstName = this.userForm.get('firstName').value;
    const lastName = this.userForm.get('lastName').value;
    const email = this.userForm.get('email').value;
    const password = this.userForm.get('password').value;
    const roles: string[] = ['admin'];

    const newUserRequest = new NewUserRequest(
      firstName,
      lastName,
      email,
      password,
      roles
    );
    const dialogResult = new DialogResult(DialogButton.OK, newUserRequest);
    this.dialogRef.close(dialogResult);
  }

  /**
   * Initialize the form controls
   */
  private initForm() {
    this.userForm = new FormGroup({
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      email: new FormControl('', [this.validateEmail]),
      password: new FormControl('', [this.validatePassword]),
      role: new FormControl('user', Validators.required)
    });
  }

  /**
   * Validate the contents of the email control
   */
  private validateEmail = (control: FormControl) => {
    try {

      const value = control.value;

      if (!value) {
        return {
          required: {
            invalid: true,
          },
        };
      }

      if (EMAIL_REGEX.test(value) === false) {
        return {
          invalidEmail: {
            invalid: true,
          },
        };
      }

      return {};
    } catch (error) {
      return {
        invalidEmail: {
          invalid: true,
        },
      };
    }
  }

  /**
   * Validate the contents of the password control
   */
  private validatePassword = (control: FormControl) => {
    try {
      const value = control.value;

      if (!value) {
        return {
          required: {
            invalid: true,
          },
        };
      }

      if (LOWER_CASE_REGEX.test(value) === false) {
        return {
          lowerCase: {
            invalid: true,
          },
        };
      }

      if (UPPER_CASE_REGEX.test(value) === false) {
        return {
          upperCase: {
            invalid: true,
          },
        };
      }

      if (NUMBER_REGEX.test(value) === false) {
        return {
          number: {
            invalid: true,
          },
        };
      }

      if (SPECIAL_CHARACTER_REGEX.test(value) === false) {
        return {
          specialCharacter: {
            invalid: true,
          },
        };
      }

      if (value.length < 8) {
        return {
          minLength: {
            invalid: true,
          },
        };
      }

      if (value.length > 20) {
        return {
          maxLength: {
            invalid: true,
          },
        };
      }
      return {};
    } catch (error) {
      return {
        invalidPassword: {
          invalid: true,
        },
      };
    }
  }
}
