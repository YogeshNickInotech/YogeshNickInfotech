import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { UpdatePasswordRequest } from 'src/app/models/user/update-password-request.model';
import { LOWER_CASE_REGEX } from 'src/app/constants/lower-case.regex';
import { UPPER_CASE_REGEX } from 'src/app/constants/upper-case.regex';
import { NUMBER_REGEX } from 'src/app/constants/number.regex';
import { SPECIAL_CHARACTER_REGEX } from 'src/app/constants/special-character.regex';

/**
 * Dialog component to be used by system administrators to edit user passwords (bypasses email authentication)
 */
@Component({
  selector: 'app-admin-edit-password-dialog',
  templateUrl: './admin-edit-password-dialog.component.html',
  styleUrls: ['./admin-edit-password-dialog.component.scss']
})
export class AdminEditPasswordDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Change Password';
  public createButtonLabel = 'Update';
  public passwordForm: FormGroup;

  /**
   * Constructor
   * @param dialogRef - A reference to the dialog
   * @param userId - The ID of the user whose password is being updated
   */
  constructor(
    public dialogRef: MdcDialogRef<AdminEditPasswordDialogComponent>,
    @Inject(MDC_DIALOG_DATA) private userId: string
  ) { }

  /**
   * Initialize the form
   */
  public ngOnInit() {
    this.initForm();
  }

  /**
   * Event handler for the cancel button
   */
  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  /**
   * Event handler for the submit button
   */
  public onSubmit(): void {
    if (this.passwordForm.invalid) {
      return;
    }

    const updatePasswordRequest = new UpdatePasswordRequest();
    updatePasswordRequest.userId = this.userId;
    updatePasswordRequest.newPassword = this.passwordForm.get('newPassword').value;

    const dialogResult = new DialogResult(DialogButton.OK, updatePasswordRequest);
    this.dialogRef.close(dialogResult);
  }

  /**
   * Initialize the form controls
   */
  private initForm() {
    this.passwordForm = new FormGroup({
      newPassword: new FormControl('', [Validators.required, this.validatePassword]),
    });
  }

  /**
   * Validato the contents of the password control
   */
  private validatePassword = (control: FormControl) => {
    try {
      const value = control.value;

      if (!value) {
        return {
          required: {
            invalid: true,
          },
        };
      }

      if (LOWER_CASE_REGEX.test(value) === false) {
        return {
          lowerCase: {
            invalid: true,
          },
        };
      }

      if (UPPER_CASE_REGEX.test(value) === false) {
        return {
          upperCase: {
            invalid: true,
          },
        };
      }

      if (NUMBER_REGEX.test(value) === false) {
        return {
          number: {
            invalid: true,
          },
        };
      }

      if (SPECIAL_CHARACTER_REGEX.test(value) === false) {
        return {
          specialCharacter: {
            invalid: true,
          },
        };
      }

      if (value.length < 8) {
        return {
          minLength: {
            invalid: true,
          },
        };
      }

      if (value.length > 20) {
        return {
          maxLength: {
            invalid: true,
          },
        };
      }
      return {};
    } catch (error) {
      return {
        invalidPassword: {
          invalid: true,
        },
      };
    }
  }
}
