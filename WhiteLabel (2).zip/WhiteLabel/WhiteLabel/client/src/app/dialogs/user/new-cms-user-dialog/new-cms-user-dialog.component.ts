import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton } from 'leatherman';
import { NewUserRequest } from '../../../models/user/new-user-request.model';
import { Site } from 'src/app/models/site/site.model';
import { SPECIAL_CHARACTER_REGEX } from 'src/app/constants/special-character.regex';
import { NUMBER_REGEX } from 'src/app/constants/number.regex';
import { UPPER_CASE_REGEX } from 'src/app/constants/upper-case.regex';
import { LOWER_CASE_REGEX } from 'src/app/constants/lower-case.regex';
import { EMAIL_REGEX } from 'src/app/constants/email.regex';

/**
 * Dialog component to create a new site admin user
 */
@Component({
  selector: 'app-new-cms-user-dialog',
  templateUrl: './new-cms-user-dialog.component.html',
  styleUrls: ['./new-cms-user-dialog.component.scss']
})
export class NewCmsUserDialogComponent implements OnInit {
  public dialogTitle = 'New Site User';
  public createButtonLabel = 'Create';
  public userForm: FormGroup;
  public siteId: string;
  public sites: Site[] = [];

  /**
   * Constructor
   * @param dialogRef - A reference to the dialog
   * @param data - An object containing the dialog arguments
   */
  constructor(
    public dialogRef: MdcDialogRef<NewCmsUserDialogComponent>,
    @Inject(MDC_DIALOG_DATA) data
  ) {
    this.siteId = data.siteId;
    this.sites = data.sites;
  }

  /**
   * Initialize the component
   */
  public async ngOnInit() {
    this.initForm();
  }

  /**
   * Event handler for the cancel button
   */
  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  /**
   * Event handler for the submit button
   */
  public onSubmit(): void {
    if (this.userForm.invalid) {
      return;
    }

    let siteId: string;
    if (this.siteId) {
      siteId = this.siteId;
    } else {
      siteId = this.userForm.get('site').value;
    }

    const firstName = this.userForm.get('firstName').value;
    const lastName = this.userForm.get('lastName').value;
    const email = this.userForm.get('email').value;
    const password = this.userForm.get('password').value;

    const roles: string[] = ['site-owner'];

    const newUserRequest = new NewUserRequest(
      firstName,
      lastName,
      email,
      password,
      roles
    );

    newUserRequest.siteId = siteId;

    const dialogResult = new DialogResult(DialogButton.OK, newUserRequest);
    this.dialogRef.close(dialogResult);
  }

  /**
   * Initialize the form controls
   */
  private initForm() {
    this.userForm = new FormGroup({
      site: new FormControl('', Validators.required),
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      email: new FormControl('', this.validateEmail),
      password: new FormControl('', this.validatePassword)
    });
  }

  /**
   * Validat the contents of the email controls
   */
  private validateEmail = (control: FormControl) => {
    try {

      const value = control.value;

      if (!value) {
        return {
          required: {
            invalid: true,
          },
        };
      }

      if (EMAIL_REGEX.test(value) === false) {
        return {
          invalidEmail: {
            invalid: true,
          },
        };
      }

      return {};
    } catch (error) {
      return {
        invalidEmail: {
          invalid: true,
        },
      };
    }
  }

  /**
   * Validate the contents of the password control
   */
  private validatePassword = (control: FormControl) => {
    try {
      const value = control.value;

      if (!value) {
        return {
          required: {
            invalid: true,
          },
        };
      }

      if (LOWER_CASE_REGEX.test(value) === false) {
        return {
          lowerCase: {
            invalid: true,
          },
        };
      }

      if (UPPER_CASE_REGEX.test(value) === false) {
        return {
          upperCase: {
            invalid: true,
          },
        };
      }

      if (NUMBER_REGEX.test(value) === false) {
        return {
          number: {
            invalid: true,
          },
        };
      }

      if (SPECIAL_CHARACTER_REGEX.test(value) === false) {
        return {
          specialCharacter: {
            invalid: true,
          },
        };
      }

      if (value.length < 8) {
        return {
          minLength: {
            invalid: true,
          },
        };
      }

      if (value.length > 20) {
        return {
          maxLength: {
            invalid: true,
          },
        };
      }
      return {};
    } catch (error) {
      return {
        invalidPassword: {
          invalid: true,
        },
      };
    }
  }
}
