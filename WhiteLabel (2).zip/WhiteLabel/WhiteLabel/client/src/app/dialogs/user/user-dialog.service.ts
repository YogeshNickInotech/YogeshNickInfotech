import { Injectable } from '@angular/core';
import { DialogResult } from 'leatherman';
import { MdcDialog } from '@angular-mdc/web';
import { User } from '../../models/user/user.model';
import { EditAdminUserDialogComponent } from './edit-admin-user-dialog/edit-admin-user-dialog.component';
import { NewUserRequest } from '../../models/user/new-user-request.model';
import { EditUserNameDialogComponent } from './edit-user-name-dialog/edit-user-name-dialog.component';
import { EditPasswordDialogComponent } from './edit-password-dialog/edit-password-dialog.component';
import { UpdatePasswordRequest } from 'src/app/models/user/update-password-request.model';
import { EditCmsUserDialogComponent } from './edit-cms-user-dialog/edit-cms-user-dialog.component';
import { NewCmsUserDialogComponent } from './new-cms-user-dialog/new-cms-user-dialog.component';
import { NewAdminUserDialogComponent } from './new-admin-user-dialog/new-admin-user-dialog.component';
import { Site } from 'src/app/models/site/site.model';
import { AdminEditPasswordDialogComponent } from './admin-edit-password-dialog/admin-edit-password-dialog.component';

/**
 * Service to invoke user dialogs
 */
@Injectable({
  providedIn: 'root'
})
export class UserDialogService {
  /**
   * Constructor
   * @param dialog - A reference to the MDC dialog service
   */
  constructor(public dialog: MdcDialog) { }

  /**
   * Open an edit admin password dialog
   * @param userId - The ID of the user whose password is to be edited
   * @returns An update password request
   */
  public async openAdminEditPasswordDialog(userId: string): Promise<DialogResult<UpdatePasswordRequest>> {
    const dialogRef = this.dialog.open(AdminEditPasswordDialogComponent, {
      clickOutsideToClose: false,
      data: userId
    });

    const result: DialogResult<UpdatePasswordRequest> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  /**
   * Open an edit admin user dialog
   * @param user - The user to be edited
   * @returns An edited user object
   */
  public async openEditAdminUserDialog(user: User): Promise<DialogResult<User>> {
    const dialogRef = this.dialog.open(EditAdminUserDialogComponent, {
      clickOutsideToClose: false,
      data: user
    });

    const result: DialogResult<User> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  /**
   * Open an edit site admin user dialog
   * @param user - The user to be edited
   * @returns The edited user object
   */
  public async openEditCmsUserDialog(user: User): Promise<DialogResult<User>> {
    const dialogRef = this.dialog.open(EditCmsUserDialogComponent, {
      clickOutsideToClose: false,
      data: user
    });

    const result: DialogResult<User> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  /**
   * Open an edit password dialog
   * @param userId - The ID of the user whose password is to be edited
   * @returns An update password request
   */
  public async openEditPasswordDialog(userId: string): Promise<DialogResult<UpdatePasswordRequest>> {
    const dialogRef = this.dialog.open(EditPasswordDialogComponent, {
      clickOutsideToClose: false,
      data: userId
    });

    const result: DialogResult<UpdatePasswordRequest> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  /**
   * Open an edit user name dialog
   * @param user - The user to be edited
   * @returns An edited user object
   */
  public async openEditUserNameDialog(user: User): Promise<DialogResult<User>> {
    const dialogRef = this.dialog.open(EditUserNameDialogComponent, {
      clickOutsideToClose: false,
      data: user
    });

    const result: DialogResult<User> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  /**
   * Open a new admin user dialog
   * @returns A new user request object
   */
  public async openNewAdminUserDialog(): Promise<DialogResult<NewUserRequest>> {
    const dialogRef = this.dialog.open(NewAdminUserDialogComponent, {
      clickOutsideToClose: false,
      data: null
    });

    const result: DialogResult<NewUserRequest> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  /**
   * Open a new site admin user dialog
   * @param siteId - The site to which the user will belong
   * @param sites - An array of existing sites
   * @returns A new user request object
   */
  public async openNewCmsUserDialog(siteId: string, sites: Site[]): Promise<DialogResult<NewUserRequest>> {
    const dialogRef = this.dialog.open(NewCmsUserDialogComponent, {
      clickOutsideToClose: false,
      data: { siteId, sites }
    });

    const result: DialogResult<NewUserRequest> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }
}
