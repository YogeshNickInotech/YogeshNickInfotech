import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { User } from '../../../models/user/user.model';
import { UpdatePasswordRequest } from 'src/app/models/user/update-password-request.model';

/**
 * Dialog component to allow users to edit their own password
 */
@Component({
  selector: 'app-edit-password-dialog',
  templateUrl: './edit-password-dialog.component.html',
  styleUrls: ['./edit-password-dialog.component.scss']
})
export class EditPasswordDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Change Password';
  public createButtonLabel = 'Update';
  public passwordForm: FormGroup;

  /**
   * Constructor
   * @param dialogRef - A reference to the dialog
   * @param userId - The ID of the user editin their password
   */
  constructor(
    public dialogRef: MdcDialogRef<EditPasswordDialogComponent>,
    @Inject(MDC_DIALOG_DATA) private userId: string
  ) { }

  /**
   * Initialize the component
   */
  public ngOnInit() {
    this.initForm();
  }

  /**
   * Event handler for the cancel button
   */
  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  /**
   * Event handler for the submit button
   */
  public onSubmit(): void {
    this.validateForm();
    if (this.passwordForm.invalid) {
      return;
    }

    const updatePasswordRequest = new UpdatePasswordRequest();
    updatePasswordRequest.userId = this.userId;
    updatePasswordRequest.oldPassword = this.passwordForm.get('oldPassword').value;
    updatePasswordRequest.newPassword = this.passwordForm.get('newPassword').value;

    const dialogResult = new DialogResult(DialogButton.OK, updatePasswordRequest);
    this.dialogRef.close(dialogResult);
  }

  /**
   * Initialize the form controls
   */
  private initForm() {
    this.passwordForm = new FormGroup({
      oldPassword: new FormControl('', this.validateOldPassword),
      newPassword: new FormControl('', [this.validatePassword]),
      confirmNewPassword: new FormControl('', [Validators.required, this.validatePasswordMatch])
    });
  }

  /**
   * Validate all form fields for the passed form group
   * @param formGroup - The form group to validate
   */
  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        control.updateValueAndValidity();
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  /**
   * Validate all controls in the form
   * @returns True if all validation succeeds
   */
  private validateForm(): boolean {
    this.validateAllFormFields(this.passwordForm);
    this.passwordForm.markAsDirty();

    return true;
  }

  /**
   * Verify that the passwords match
   */
  private validatePasswordMatch = (control: FormControl) => {
    try {
      const verifyNewPassword = control.value;
      const newPassword = this.passwordForm.get('newPassword').value;

      if (verifyNewPassword !== newPassword) {
        return {
          passwordMatch: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidPassword: {
          invalid: true
        }
      };
    }
  }

  /**
   * Validate the controls of the old password control
   */
  private validateOldPassword = (control: FormControl) => {
    try {
      if (control.touched === false) {
        return {};
      }

      const value = control.value;
      if (!value) {
        return {
          required: {
            invalid: true
          }
        };
      }

      const stringValue: string = value;

      if (stringValue.trim().length === 0) {
        return {
          required: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidOldPassword: {
          invalid: true
        }
      };
    }
  }

  /**
   * Validate the contents of the password control
   */
  private validatePassword = (control: FormControl) => {
    try {

      const value = control.value;
      if (!value) {
        return {
          required: {
            invalid: true
          }
        };
      }

      const stringValue: string = value;

      if (stringValue.trim().length === 0) {
        return {
          required: {
            invalid: true
          }
        };
      }
      if (/(?=.*[a-z])/.test(value) === false) {
        return {
          lowerCase: {
            invalid: true
          }
        };
      }
      if (/(?=.*[A-Z])/.test(value) === false) {
        return {
          upperCase: {
            invalid: true
          }
        };
      }
      if (/(?=.*[0-9])/.test(value) === false) {
        return {
          number: {
            invalid: true
          }
        };
      }

      if (/(?=.[@%/'"!#,~&;`_<>\:\.\^\$\*\+\-\?\(\)\[\]\{\}\\\|])/.test(value) === false) {
        return {
          specialCharacter: {
            invalid: true,
          },
        };
      }

      if (value.length < 8) {
        return {
          minLength: {
            invalid: true
          }
        };
      }
      if (value.length > 20) {
        return {
          maxLength: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidPassword: {
          invalid: true
        }
      };
    }
  }
}
