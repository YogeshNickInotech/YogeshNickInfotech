import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { User } from '../../../models/user/user.model';
import { InfoDialogProperties } from '../_models/info-dialog-properties.model';

@Component({
  selector: 'app-info-dialog',
  templateUrl: './info-dialog.component.html',
  styleUrls: ['./info-dialog.component.scss']
})
export class InfoDialogComponent implements OnInit {
  constructor(
    public dialogRef: MdcDialogRef<InfoDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public dialogProperties: InfoDialogProperties
  ) { }

  // ngOnInit
  public ngOnInit() { }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    const dialogResult = new DialogResult(DialogButton.OK);
    this.dialogRef.close(dialogResult);
  }
}
