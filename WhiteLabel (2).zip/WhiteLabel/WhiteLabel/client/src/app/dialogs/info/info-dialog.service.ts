import { Injectable } from '@angular/core';
import { DialogResult } from 'leatherman';
import { MdcDialog } from '@angular-mdc/web';
import { User } from '../../models/user/user.model';
import { InfoDialogProperties } from './_models/info-dialog-properties.model';
import { InfoDialogComponent } from './info-dialog/info-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class InfoDialogService {
  constructor(public dialog: MdcDialog) {}

  public async openInfoDialog(
    title: string,
    message: string
  ): Promise<DialogResult<User>> {
    const dialogProperties = new InfoDialogProperties();
    dialogProperties.title = title;
    dialogProperties.message = message;
    const dialogRef = this.dialog.open(InfoDialogComponent, {
      clickOutsideToClose: false,
      data: dialogProperties
    });

    const result: DialogResult<User> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }
}
