export class InfoDialogProperties {
  public title: string;
  public message: string;
}
