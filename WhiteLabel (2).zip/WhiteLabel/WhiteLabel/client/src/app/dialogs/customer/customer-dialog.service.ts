import { Injectable } from '@angular/core';
import { DialogResult } from 'leatherman';
import { MdcDialog } from '@angular-mdc/web';
import { Customer } from '../../models/customer/customer.model';
import { EditCustomerDialogComponent } from './edit-customer-dialog/edit-customer-dialog.component';
// tslint:disable-next-line: max-line-length
import { EditCustomerBillingAddressDialogComponent } from './edit-customer-billing-address-dialog/edit-customer-billing-address-dialog.component';

@Injectable({
  providedIn: 'root'
})
   export class CustomerDialogService {
  constructor(public dialog: MdcDialog) { }

  public async openEditCustomerDialog(
    customer: Customer
  ): Promise<DialogResult<Customer>> {
    const dialogRef = this.dialog.open(EditCustomerDialogComponent, {
      clickOutsideToClose: false,
      data: customer
    });

    const result: DialogResult<Customer> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openEditCustomerBillingAddressDialog(
    customer: Customer
  ): Promise<DialogResult<Customer>> {
    const dialogRef = this.dialog.open(EditCustomerBillingAddressDialogComponent, {
      clickOutsideToClose: false,
      data: customer
    });

    const result: DialogResult<Customer> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openNewCustomerDialog(): Promise<DialogResult<Customer>> {
    const dialogRef = this.dialog.open(EditCustomerDialogComponent, {
      clickOutsideToClose: false,
      data: null
    });

    const result: DialogResult<Customer> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }
}
