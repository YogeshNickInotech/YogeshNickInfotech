import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Customer } from '../../../models/customer/customer.model';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';

@Component({
  selector: 'app-edit-customer-dialog',
  templateUrl: './edit-customer-dialog.component.html',
  styleUrls: ['./edit-customer-dialog.component.scss']
})
export class EditCustomerDialogComponent implements OnInit {
  public dialogMode = 'New';
  public dialogTitle = 'New Customer';
  public createButtonLabel = 'Create';
  public customerForm: FormGroup;
  constructor(
    public dialogRef: MdcDialogRef<EditCustomerDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public customer: Customer
  ) {
    if (customer) {
      this.dialogMode = 'Edit';
      this.dialogTitle = 'Edit Customer';
      this.createButtonLabel = 'Update';
    } else {
      this.customer = new Customer();
    }
  }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.customerForm.invalid) {
      return;
    }
    const customer = ObjectCopyUtil.deepCopy(this.customer);
    customer.firstName = this.customerForm.get('firstName').value;
    customer.lastName = this.customerForm.get('lastName').value;
    customer.address.address = this.customerForm.get('address').value;
    customer.address.city = this.customerForm.get('city').value;
    customer.address.state = this.customerForm.get('state').value;
    customer.address.zip = this.customerForm.get('zip').value;
    customer.email = this.customerForm.get('email').value;
    customer.phone = this.customerForm.get('telephone').value;
    customer.comments = this.customerForm.get('comments').value;
    const dialogResult = new DialogResult(DialogButton.OK, customer);
    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    this.customerForm = new FormGroup({
      firstName: new FormControl(this.customer.firstName),
      lastName: new FormControl(this.customer.lastName),
      address: new FormControl(this.customer.address.address),
      city: new FormControl(this.customer.address.city),
      state: new FormControl(this.customer.address.state),
      zip: new FormControl(this.customer.address.zip),
      email: new FormControl(this.customer.email, [
        Validators.email,
        Validators.required
      ]),
      telephone: new FormControl(this.customer.phone),
      comments: new FormControl(this.customer.comments)
    });
  }
}
