import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { Customer } from 'src/app/models/customer/customer.model';
import { CustomerBillingAddress } from 'src/app/models/customer/_submodels/customer-billing-address.model';

@Component({
  selector: 'app-edit-customer-billing-address-dialog',
  templateUrl: './edit-customer-billing-address-dialog.component.html',
  styleUrls: ['./edit-customer-billing-address-dialog.component.scss']
})
export class EditCustomerBillingAddressDialogComponent implements OnInit {
  public dialogMode = 'Edit';
  public dialogTitle = 'Edit Billing Address';
  public createButtonLabel = 'Update';
  public customerForm: FormGroup;
  constructor(
    public dialogRef: MdcDialogRef<EditCustomerBillingAddressDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public customer: Customer
  ) {
    if (!customer.billingAddress) {
      this.customer.billingAddress = new CustomerBillingAddress();
      this.dialogTitle = 'New Billing Address';
      this.dialogMode = 'New';
    }
  }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.customerForm.invalid) {
      return;
    }

    const customer = ObjectCopyUtil.deepCopy(this.customer);
    customer.billingAddress.address = this.customerForm.get('address').value;
    customer.billingAddress.city = this.customerForm.get('city').value;
    customer.billingAddress.state = this.customerForm.get('state').value;
    customer.billingAddress.zip = this.customerForm.get('zip').value;

    const dialogResult = new DialogResult(DialogButton.OK, customer);

    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    this.customerForm = new FormGroup({
      address: new FormControl(this.customer.billingAddress.address, Validators.required),
      city: new FormControl(this.customer.billingAddress.city, Validators.required),
      state: new FormControl(this.customer.billingAddress.state, Validators.required),
      zip: new FormControl(this.customer.billingAddress.zip, Validators.required)
    });
  }
}
