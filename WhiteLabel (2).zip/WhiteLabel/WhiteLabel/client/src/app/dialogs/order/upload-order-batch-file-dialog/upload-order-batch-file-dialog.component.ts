import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { DialogResult, DialogButton } from 'leatherman';
import * as Papa from 'papaparse';
import { FormGroup, FormControl } from '@angular/forms';
import { OrderDataService } from '../../../services/order/order-data.service';
import { Observable } from 'rxjs';
import * as XLSX from 'xlsx';

export class ColumnHeader {
  public index: number;
  public name: string;
}

@Component({
  selector: 'app-upload-order-batch-file-dialog',
  templateUrl: './upload-order-batch-file-dialog.component.html',
  styleUrls: ['./upload-order-batch-file-dialog.component.scss']
})
export class UploadOrderBatchFileDialogComponent implements OnInit {
  public dialogMode = 'standard';
  public file: File = null;

  public mapForm: FormGroup;
  public dialogTitle = 'Select Batch File';
  public uploadProgress: Observable<number>;
  public currentPage = 'page1';
  public submitButtonLabel = 'Next';
  public uploadComplete = false;
  // public fileSelected = false;
  // public uploadComplete = false;
  // public mappingComplete = false;
  public uploadStarted = false;

  public columns: ColumnHeader[] = [];

  constructor(
    public orderDataService: OrderDataService,
    public dialogRef: MdcDialogRef<UploadOrderBatchFileDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public orderId: string
  ) { }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public getProgressValue(progress: number): number {
    const progressPercent = progress / 100;
    return progressPercent;
  }

  public getUploadLabel(): string {
    if (this.uploadComplete === false) {
      return 'Uploading file: ' + this.file.name;
    } else {
      return 'Upload complete';
    }
  }

  public async next() {
    this.currentPage = 'page3';
    this.dialogTitle = 'Upload File';
    await this.uploadMappedFile();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public async onFileAdded(event) {
    this.file = event.target.files[0];
    const fileName = this.file.name;
    const fileElements = fileName.split('.');

    switch (this.filePreviewComplete[1].toLowerCase()) {
      case 'xlsx':
      case 'xls':
      case 'csv':
        // Continue
        break;
      default:
        console.log('Invalid file type');
        return;
        break;
    }

    if (fileElements[1].toLowerCase() === 'xlsx') {
      const reader: FileReader = new FileReader();
      reader.onload = async (e: any) => {
        /* read workbook */
        const bstr: string = e.target.result;
        const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

        /* grab first sheet */
        const wsname: string = wb.SheetNames[0];
        const ws: XLSX.WorkSheet = wb.Sheets[wsname];
        const columnHeaders: ColumnHeader[] = [];

        const rowCount = ws['!rows'].length;

        const letters = [
          'A',
          'B',
          'C',
          'D',
          'E',
          'F',
          'G',
          'H',
          'I',
          'J',
          'K',
          'L',
          'M',
          'N',
          'O',
          'P',
          'Q',
          'R',
          'S',
          'T'
        ];
        let index = 0;
        const columnNames: string[] = [];
        for (const letter of letters) {
          const columnHeader = new ColumnHeader();
          if (ws[letter + '1']) {
            columnHeader.index = index;
            columnHeader.name = ws[letter + '1'].v;
            columnHeaders.push(columnHeader);
            columnNames.push(columnHeader.name);
          }
          index++;
        }

        if (this.isStandardFile(columnNames) === true) {
          this.currentPage = 'page3';
          this.dialogMode = 'standard';
          this.dialogTitle = 'Upload File';
          await this.uploadStandardFile();
        } else {
          this.currentPage = 'page2';
          this.dialogMode = 'map';
          this.dialogTitle = 'Map Columns';
          const columns = columnHeaders;
          const blankColumn = new ColumnHeader();
          blankColumn.name = '';
          blankColumn.index = -1;
          columns.unshift(blankColumn);
          this.columns = columns;
        }
      };
      reader.readAsBinaryString(this.file);
    } else {
      const config = {
        preview: 1,
        complete: this.filePreviewComplete
      };

      Papa.parse(this.file, config);
    }
  }

  public submit() {
    const dialogResult = new DialogResult(DialogButton.OK);
    this.dialogRef.close(dialogResult);
  }

  public async uploadStandardFile() {
    this.dialogTitle = 'Upload File';
    this.uploadStarted = true;

    const formData = new FormData();
    formData.append('file', this.file, this.file.name);
    formData.append('fileType', 'standard');
    formData.append('fileMode', 'source');

    this.uploadProgress = this.orderDataService.uploadFile(
      formData,
      this.orderId
    );

    this.uploadProgress.subscribe(
      next => { },
      error => { },
      () => {
        this.uploadComplete = true;
      }
    );
  }

  public async uploadMappedFile() {
    this.dialogTitle = 'Upload File';
    this.uploadStarted = true;

    const firstNameIndex = this.mapForm.value.firstName;
    const firstName = this.getColumnName(this.columns, firstNameIndex);
    const lastNameIndex = this.mapForm.value.lastName;
    const lastName = this.getColumnName(this.columns, lastNameIndex);
    const propertyAddressIndex = this.mapForm.value.propertyAddress;
    const propertyAddress = this.getColumnName(
      this.columns,
      propertyAddressIndex
    );
    const propertyCityIndex = this.mapForm.value.propertyCity;
    const propertyCity = this.getColumnName(this.columns, propertyCityIndex);
    const propertyStateIndex = this.mapForm.value.propertyState;
    const propertyState = this.getColumnName(this.columns, propertyStateIndex);
    const propertyZipIndex = this.mapForm.value.propertyZip;
    const propertyZip = this.getColumnName(this.columns, propertyZipIndex);
    const mailingAddressIndex = this.mapForm.value.mailingAddress;
    const mailingAddress = this.getColumnName(
      this.columns,
      mailingAddressIndex
    );
    const mailingCityIndex = this.mapForm.value.mailingCity;
    const mailingCity = this.getColumnName(this.columns, mailingCityIndex);
    const mailingStateIndex = this.mapForm.value.mailingState;
    const mailingState = this.getColumnName(this.columns, mailingStateIndex);
    const mailingZipIndex = this.mapForm.value.mailingZip;
    const mailingZip = this.getColumnName(this.columns, mailingZipIndex);

    const formData = new FormData();
    formData.append('file', this.file, this.file.name);
    formData.append('fileType', 'map');
    formData.append('fileMode', 'source');
    formData.append('firstName', firstName);
    formData.append('firstNameIndex', firstNameIndex);
    formData.append('lastName', lastName);
    formData.append('lastNameIndex', lastNameIndex);
    formData.append('propertyAddress', propertyAddress);
    formData.append('propertyAddressIndex', propertyAddressIndex);
    formData.append('propertyCity', propertyCity);
    formData.append('propertyCityIndex', propertyCityIndex);
    formData.append('propertyState', propertyState);
    formData.append('propertyStateIndex', propertyStateIndex);
    formData.append('propertyZip', propertyZip);
    formData.append('propertyZipIndex', propertyZipIndex);
    formData.append('mailingAddress', mailingAddress);
    formData.append('mailingAddressIndex', mailingAddressIndex);
    formData.append('mailingCity', mailingCity);
    formData.append('mailingCityIndex', mailingCityIndex);
    formData.append('mailingState', mailingState);
    formData.append('mailingStateIndex', mailingStateIndex);
    formData.append('mailingZip', mailingZip);
    formData.append('mailingZipIndex', mailingZipIndex);

    this.uploadProgress = this.orderDataService.uploadFile(
      formData,
      this.orderId
    );

    this.uploadProgress.subscribe(
      next => { },
      error => { this.submit(); },
      () => {
        this.uploadComplete = true;
      }
    );
  }

  private filePreviewComplete = async (results, file) => {
    const rowCount = results.data.length;

    if (this.isStandardFile(results.data[0]) === true) {
      this.currentPage = 'page3';
      this.dialogMode = 'standard';
      this.dialogTitle = 'Upload File';
      await this.uploadStandardFile();
    } else {
      this.currentPage = 'page2';
      this.dialogMode = 'map';
      this.dialogTitle = 'Map Columns';
      const headerColumnValues = results.data[0];
      const columns: ColumnHeader[] = [];
      let index = 0;
      for (const headerColumnValue of headerColumnValues) {
        const columnHeader = new ColumnHeader();
        columnHeader.index = index;
        columnHeader.name = headerColumnValue;
        columns.push(columnHeader);
        index++;
      }
      const blankColumn = new ColumnHeader();
      blankColumn.name = '';
      blankColumn.index = -1;
      columns.unshift(blankColumn);
      this.columns = columns;
      this.columns = columns;
    }
  }

  private initForm() {
    this.mapForm = new FormGroup({
      firstName: new FormControl(''),
      lastName: new FormControl(''),
      propertyAddress: new FormControl(''),
      propertyCity: new FormControl(''),
      propertyState: new FormControl(''),
      propertyZip: new FormControl(''),
      mailingAddress: new FormControl(''),
      mailingCity: new FormControl(''),
      mailingState: new FormControl(''),
      mailingZip: new FormControl('')
    });
  }

  private isStandardFile(columnNames: string[]): boolean {
    if (
      columnNames.includes('INPUT_FIRST_NAME') &&
      columnNames.includes('INPUT_ADDRESS_LINE1')
    ) {
      return true;
    } else if (
      columnNames.includes('INPUT: First Name') &&
      columnNames.includes('INPUT: Address 1')
    ) {
      return true;
    }
    return false;
  }

  private columnHeaderIncludes(
    columnHeaders: ColumnHeader[],
    columnName: string
  ): boolean {
    for (const columnHeader of columnHeaders) {
      if (columnHeader.name === columnName) {
        return true;
      }
    }
    return false;
  }

  private getColumnName(
    columnHeaders: ColumnHeader[],
    columnIndex: string
  ): string {
    const colunmIndexInt = parseInt(columnIndex, 10);
    for (const columnHeader of columnHeaders) {
      if (columnHeader.index === colunmIndexInt) {
        return columnHeader.name;
      }
    }
    return '';
  }
}
