import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Order } from '../../../models/order/order.model';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';

@Component({
  selector: 'app-edit-order-dialog',
  templateUrl: './edit-order-dialog.component.html',
  styleUrls: ['./edit-order-dialog.component.scss']
})
export class EditOrderDialogComponent implements OnInit {
  public dialogMode = 'New';
  public dialogTitle = 'New Order';
  public createButtonLabel = 'Create';
  public orderForm: FormGroup;
  constructor(
    public dialogRef: MdcDialogRef<EditOrderDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public order: Order
  ) {
    if (order) {
      this.dialogMode = 'Edit';
      this.dialogTitle = 'Edit Order Comments';
      this.createButtonLabel = 'Update';
    } else {
      this.order = new Order();
    }
  }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.orderForm.invalid) {
      return;
    }

    const order = ObjectCopyUtil.deepCopy(this.order);
    order.orderNumber = this.orderForm.get('orderNumber').value;
    order.comments = this.orderForm.get('comments').value;
    // if (this.dialogMode === 'Edit') {
    //   order.status = this.orderForm.get('status').value;
    // } else {
    //   order.status = 'Open';
    // }
    const dialogResult = new DialogResult(DialogButton.OK, order);
    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    const defaultOrderStatus =
      this.dialogMode === 'New' ? 'Open' : this.order.status;
    this.orderForm = new FormGroup({
      orderNumber: new FormControl(this.order.orderNumber),
      // status: new FormControl(defaultOrderStatus, Validators.required),
      comments: new FormControl(this.order.comments)
    });
  }
}
