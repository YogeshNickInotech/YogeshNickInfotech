import { Injectable } from '@angular/core';
import { DialogResult } from 'leatherman';
import { MdcDialog } from '@angular-mdc/web';
import { Order } from '../../models/order/order.model';
import { EditOrderDialogComponent } from './edit-order-dialog/edit-order-dialog.component';
import { UploadOrderBatchFileDialogComponent } from './upload-order-batch-file-dialog/upload-order-batch-file-dialog.component';
@Injectable({
  providedIn: 'root'
})
export class OrderDialogService {
  constructor(public dialog: MdcDialog) { }

  public async openEditOrderDialog(order: Order): Promise<DialogResult<Order>> {
    const dialogRef = this.dialog.open(EditOrderDialogComponent, {
      clickOutsideToClose: false,
      data: order
    });

    const result: DialogResult<Order> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openNewOrderDialog(): Promise<DialogResult<Order>> {
    const dialogRef = this.dialog.open(EditOrderDialogComponent, {
      clickOutsideToClose: false,
      data: null
    });

    const result: DialogResult<Order> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openUploadBatchFileDialog(
    orderId: string
  ): Promise<DialogResult<FormData>> {
    const dialogRef = this.dialog.open(UploadOrderBatchFileDialogComponent, {
      clickOutsideToClose: false,
      data: orderId
    });

    const result: DialogResult<FormData> = await dialogRef.afterClosed().toPromise<any>();

    return result;
  }
}
