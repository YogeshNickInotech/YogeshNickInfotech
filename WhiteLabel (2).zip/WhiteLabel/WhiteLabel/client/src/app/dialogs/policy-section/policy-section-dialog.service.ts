import { Injectable } from '@angular/core';
import { DialogResult } from 'leatherman';
import { MdcDialog } from '@angular-mdc/web';
import { PolicySection } from 'src/app/models/policy-section/policy-section.model';
import { EditPolicySectionDialogComponent } from './edit-policy-section-dialog/edit-policy-section-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class PolicySectionDialogService {
  constructor(public dialog: MdcDialog) { }

  public async openEditPolicySectionDialog(policySection: PolicySection): Promise<DialogResult<PolicySection>> {
    const dialogRef = this.dialog.open(EditPolicySectionDialogComponent, {
      clickOutsideToClose: false,
      data: policySection
    });

    const result: DialogResult<PolicySection> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openNewPolicySectionDialog(): Promise<DialogResult<PolicySection>> {
    const dialogRef = this.dialog.open(EditPolicySectionDialogComponent, {
      clickOutsideToClose: false,
      data: null
    });

    const result: DialogResult<PolicySection> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }
}
