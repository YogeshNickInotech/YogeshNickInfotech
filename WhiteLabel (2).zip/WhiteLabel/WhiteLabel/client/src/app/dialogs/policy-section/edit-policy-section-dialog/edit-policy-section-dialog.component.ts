import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators ,ValidatorFn} from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { Faq } from 'src/app/models/faq/faq.model';
import { PolicySection } from 'src/app/models/policy-section/policy-section.model';
import { contentValidator } from './contentValidator';
@Component({
  selector: 'app-edit-policy-section-dialog',
  templateUrl: './edit-policy-section-dialog.component.html',
  styleUrls: ['./edit-policy-section-dialog.component.scss']
})
export class EditPolicySectionDialogComponent implements OnInit {
  public dialogMode = 'New';
  public submitted = false;
  private dialogIsOpen: boolean;
  public dialogTitle = 'New Policy Section';
  public createButtonLabel = 'Create';
  public policySectionForm: FormGroup;
  constructor(
    public dialogRef: MdcDialogRef<EditPolicySectionDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public policySection: PolicySection
  ) {
    if (policySection) {
      this.dialogMode = 'Edit';
      this.dialogTitle = 'Edit Policy Section';
      this.createButtonLabel = 'Update';
    } else {
      this.policySection = new PolicySection();
    }
  }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    this.submitted = true;
    if (this.policySectionForm.invalid) {
      return;
    }
  
    const content: string = this.policySectionForm.get('content').value;

    let contentLines = content.split('\n');
    contentLines = contentLines.filter(t => t.trim().length > 0);

    const policySection = ObjectCopyUtil.deepCopy(this.policySection);
    policySection.title = this.policySectionForm.get('title').value;
    policySection.content = contentLines;

    if (this.dialogMode === 'Edit') {
      policySection.index = parseInt(this.policySectionForm.get('index').value, 10);
    }

    const dialogResult = new DialogResult(DialogButton.OK, policySection);
    this.dialogRef.close(dialogResult);
  }

  private initForm() {
    let content = '';
    for (const contentLine of this.policySection.content) {
      content += contentLine + '\n\n';
    }

    if (this.dialogMode === 'Edit') {
      this.policySectionForm = new FormGroup({
        title: new FormControl(this.policySection.title),
     
        content: new FormControl(this.policySection.content,Validators.required),
        index: new FormControl(this.policySection.index,Validators.required),
      });
    } else {
      this.policySectionForm = new FormGroup({
        title: new FormControl("",[Validators.required]),
        content: new FormControl("",[Validators.required,contentValidator.cannotContainSpace,]),
      });
    } 

    // if (this.dialogMode === 'Edit') {
    //   this.policySectionForm = new FormGroup({
    //     title: new FormControl(this.policySection.title),
     
    //     content: new FormControl(this.policySection.content,Validators.required),
    //     index: new FormControl(this.policySection.index,Validators.required),
    //   });
    // } else {
    //   this.policySectionForm = new FormGroup({
    //     title: new FormControl("",[Validators.required]),
    //     content: new FormControl("",[Validators.required]),
    //   });
    // } 
  }
  
  // get f() { return this.policySectionForm.controls; }
   control = new FormControl('');
     // content: new FormControl( Validators.required,contentValidator.cannotContainSpace),

     
}
