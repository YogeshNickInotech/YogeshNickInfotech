import { Injectable } from '@angular/core';
import { DialogResult } from 'leatherman';
import { MdcDialog } from '@angular-mdc/web';
import { Faq } from 'src/app/models/faq/faq.model';
import { EditFaqDialogComponent } from './edit-faq-dialog/edit-faq-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class FaqDialogService {
  constructor(public dialog: MdcDialog) { }

  public async openEditFaqDialog(faq: Faq): Promise<DialogResult<Faq>> {
    const dialogRef = this.dialog.open(EditFaqDialogComponent, {
      clickOutsideToClose: false,
      data: faq
    });

    const result: DialogResult<Faq> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }

  public async openNewFaqDialog(): Promise<DialogResult<Faq>> {
    const dialogRef = this.dialog.open(EditFaqDialogComponent, {
      clickOutsideToClose: false,
      data: null
    });

    const result: DialogResult<Faq> = await dialogRef
      .afterClosed()
      .toPromise<any>();

    return result;
  }
}
