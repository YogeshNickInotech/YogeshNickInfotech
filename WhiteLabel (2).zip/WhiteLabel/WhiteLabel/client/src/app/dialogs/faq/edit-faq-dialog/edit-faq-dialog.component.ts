import { Component, Inject, OnInit } from '@angular/core';
import { MdcDialogRef, MDC_DIALOG_DATA } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DialogResult, DialogButton, ObjectCopyUtil } from 'leatherman';
import { Faq } from 'src/app/models/faq/faq.model';

@Component({
  selector: 'app-edit-faq-dialog',
  templateUrl: './edit-faq-dialog.component.html',
  styleUrls: ['./edit-faq-dialog.component.scss']
})
export class EditFaqDialogComponent implements OnInit {
  public dialogMode = 'New';
  public dialogTitle = 'New FAQ Question';
  public createButtonLabel = 'Create';
  public faqForm: FormGroup;
  constructor(
    public dialogRef: MdcDialogRef<EditFaqDialogComponent>,
    @Inject(MDC_DIALOG_DATA) public faq: Faq
  ) {
    if (faq) {
      this.dialogMode = 'Edit';
      this.dialogTitle = 'Edit FAQ';
      this.createButtonLabel = 'Update';
    } else {
      this.faq = new Faq();
    }
  }

  // ngOnInit
  public ngOnInit() {
    this.initForm();
  }

  public onCancel() {
    const dialogResult = new DialogResult(DialogButton.Cancel);
    this.dialogRef.close(dialogResult);
  }

  public submit(): void {
    if (this.faqForm.invalid) {
      return;
    }

    const faq = ObjectCopyUtil.deepCopy(this.faq);
    faq.question = this.faqForm.get('question').value;
    faq.answer = this.faqForm.get('answer').value;
    faq.index = parseInt(this.faqForm.get('index').value, 10);

    const dialogResult = new DialogResult(DialogButton.OK, faq);
    this.dialogRef.close(dialogResult);
  }

  private initForm() { 
    this.faqForm = new FormGroup({
      question: new FormControl(this.faq.question, Validators.required),
      answer: new FormControl(this.faq.answer, Validators.required),
      index: new FormControl(this.faq.index),
    }); 

    this.index.valueChanges.subscribe(checked => {
      if (this.dialogMode == 'New')  {
        this.index.setValidators(null);
      } else {
        this.index.setValidators([Validators.required]);
      }
      this.index.updateValueAndValidity();
    });
  }

  get index() {
    return this.faqForm.get('index') as FormControl;
  } 
}
