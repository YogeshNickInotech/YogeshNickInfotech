import { BaseModel } from 'leatherman';

export class Faq extends BaseModel {
  public siteId: string;
  public question: string;
  public answer: string;
  public index: number;
}
