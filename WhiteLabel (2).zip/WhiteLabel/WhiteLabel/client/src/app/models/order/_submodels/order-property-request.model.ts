export class OrderPropertyRequest {
    /** The first name of the person to search for */
    public firstName: string;

    /** The last name of the person to search for */
    public lastName: string;

    /** The full name of the person to search for */
    public fullName: string;

    /** The full address of the property */
    public fullAddress: string;

    /** The address of the property (street number and name) */
    public address: string;

    /** The city of the property */
    public city: string;

    /** The state of the property */
    public state: string;

    /** The zip of the property */
    public zip: string;

    /** The mailing address of the property (street number and name) */
    public mailingAddress?: string;

    /** The city of the property */
    public mailingCity?: string;

    /** The state of the property */
    public mailingState?: string;

    /** The zip of the property */
    public mailingZip?: string;
}
