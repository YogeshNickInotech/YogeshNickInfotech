export class OrderCost {
    // Costs
    public unitCost: number;
    public extendedCost: number;
}