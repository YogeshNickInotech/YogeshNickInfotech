import { BaseModel } from 'leatherman';
import { OrderCost } from './_submodels/order-cost.model';
import { OrderMeta } from './_submodels/order-meta.model';
import { OrderProperty } from '../order-property/order-property.model';
import { OrderPropertyRequest } from './_submodels/order-property-request.model';
import { OrderFile } from './_submodels/order-file.model';

export class Order extends BaseModel {
  public siteId: string;
  public orderNumber: number;
  public orderDate: Date;
  public customerId: string;
  public status: string;
  public facetStatus: string;

  public requests: OrderPropertyRequest[] = [];
  public properties: OrderProperty[] = [];
  public cost: OrderCost = new OrderCost();
  public batchFile: OrderFile;
  public meta: OrderMeta = new OrderMeta();

  public promoCode: string;

  public comments: string;
}
