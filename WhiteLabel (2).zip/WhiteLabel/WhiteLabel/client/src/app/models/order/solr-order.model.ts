import { Order } from './order.model';

export class SolrOrder {
  public _id: string;
  public siteId: string;
  public customerId: string;
  public orderNumber: number;
  public status: string;
  public facetStatus: string;
  public comments: string;

  public addressCount: number;
  public validAddressCount = 0;
  public invalidAddressCount = 0;
  public fromCacheCount = 0;
  public fromServiceCount = 0;
  public secondaryMatchCount = 0;
  public matchCount = 0;
  public noMatchCount = 0;
  public fromCachePercent = 0;
  public matchPercent = 0;

  // Costs
  public unitCost: number;
  public extendedCost: number;

  public dateCreated: Date;
  public dateModified: Date;
  public indexBatch: string;
}
