export class OrderMeta {
    // Counts
    public requestCount = 0;
    public validAddressCount = 0;
    public invalidAddressCount = 0;
    public fromCacheCount = 0;
    public fromIdiCacheCount = 0;
    public fromDelvePointCacheCount = 0;
    public fromServiceCount = 0;
    public fromIdiServiceCount = 0;
    public fromDelvePointServiceCount = 0;
    public secondaryMatchCount = 0;
    public matchCount = 0;
    public noMatchCount = 0;
    public fromCachePercent = 0;
    public matchPercent = 0;
    public indexBatch: string;
    public orderYear: number;
    public orderMonth: number;
    public orderDay: number;
}
