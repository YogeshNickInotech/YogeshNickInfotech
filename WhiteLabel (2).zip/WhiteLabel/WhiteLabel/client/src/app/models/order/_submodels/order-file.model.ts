import { OrderFileMapping } from './order-file-mapping.model';

export class OrderFile {
  public id: string;
  public importDate: Date;
  public originalFileName: string;
  public temporaryFileName: string;
  public fileType: string;
  public fileMode: string;
  public processed = false;
  public status: string;
  public mapping: OrderFileMapping;

  public percentComplete: number;

  // Parse counts
  public addressCount: number;
  public validAddressCount: number;
  public invalidAddressCount: number;
  // public uniqueAddressCount: number;

  // Match counts
  public fromCacheAddressCount = 0;
  public fromServiceAddressCount = 0;
  public secondaryMatchAddressCount = 0;
  public matchCount = 0;
  public noMatchCount = 0;
  public fromCachePercent = 0;
  public matchPercent = 0;
}
