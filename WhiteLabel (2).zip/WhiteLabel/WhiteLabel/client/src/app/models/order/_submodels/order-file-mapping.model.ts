export class OrderFileMapping {
  public firstName: string;
  public firstNameIndex: number;

  public lastName: string;
  public lastNameIndex: number;

  public propertyAddress: string;
  public propertyAddressIndex: number;

  public propertyCity: string;
  public propertyCityIndex: number;

  public propertyState: string;
  public propertyStateIndex: number;

  public propertyZip: string;
  public propertyZipIndex: number;

  public mailingAddress: string;
  public mailingAddressIndex: number;

  public mailingCity: string;
  public mailingCityIndex: number;

  public mailingState: string;
  public mailingStateIndex: number;

  public mailingZip: string;
  public mailingZipIndex: number;
}
