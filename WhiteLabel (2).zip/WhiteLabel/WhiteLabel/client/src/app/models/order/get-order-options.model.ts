import { GetOptions } from 'leatherman';

export class GetOrderOptions extends GetOptions {
    public siteId: string;
    public customerId: string;
}
