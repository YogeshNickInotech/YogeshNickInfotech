export class ListState {
  public query: string;
  public filter: string;
  public pageSize: number;
  public currentPage: number;
  public pageCount: number;
  public rowCount: number;
  public sortColumn: string;
  public sortAscending: boolean;

  //check
}
