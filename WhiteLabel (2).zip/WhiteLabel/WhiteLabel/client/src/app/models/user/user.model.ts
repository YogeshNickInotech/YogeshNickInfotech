import { BaseUser } from 'leatherman';

/** A user derived from the base user class */
export class User extends BaseUser {
    public siteId: string;
    public siteName: string;
}
