import { BaseNewUserRequest } from 'leatherman';

/**
 * A request for a new user
 */
export class NewUserRequest extends BaseNewUserRequest {
  public siteId: string;

  constructor(
    firstName: string,
    lastName: string,
    email: string,
    password: string,
    roles: string[]
  ) {
    super(firstName, lastName, email, password, roles);
  }
}
