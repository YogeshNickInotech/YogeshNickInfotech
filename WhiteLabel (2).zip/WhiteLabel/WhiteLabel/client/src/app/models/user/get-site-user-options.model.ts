import { GetOptions } from 'leatherman';

export class GetSiteUserOptions extends GetOptions {
    public siteId: string;
}
