export class PasswordReset {
  constructor(public token: string, public userId: string, public newPassword: string) { }
}
