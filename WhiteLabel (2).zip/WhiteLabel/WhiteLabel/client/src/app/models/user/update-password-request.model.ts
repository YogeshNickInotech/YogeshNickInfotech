export class UpdatePasswordRequest {
    public userId: string;
    public oldPassword: string;
    public newPassword: string;
}