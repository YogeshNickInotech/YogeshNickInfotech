import { BaseModel } from 'leatherman';
import { CustomerAddress } from './_submodels/customer-address.model';
import { CustomerBillingAddress } from './_submodels/customer-billing-address.model';

export class Customer extends BaseModel {
  public siteId: string;
  public firstName: string;
  public lastName: string;
  public fullName: string;
  public email: string;
  public phone: string;
  public address: CustomerAddress = new CustomerAddress();
  public billingAddress: CustomerBillingAddress = new CustomerBillingAddress();
  public addressCount: number;
  public orderCount: number;
  public totalSpend: number;
  public averageOrderValue: number;
  public lastOrderDate: Date;
  public comments: string;
  public siteName: string;

  constructor() {
    super();
  }
}
