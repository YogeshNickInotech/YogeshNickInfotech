import { Customer } from './customer.model';

export class SolrCustomer {
  public _id: string;

  public siteId: string;
  public siteName: string;
  public firstName: string;
  public lastName: string;
  public fullName: string;
  public fullAddress: string;
  public addressCount: number;
  public orderCount: number;
  public totalSpend: number;
  public averageOrderValue: number;
  public dateCreated: Date;
  public dateModified: Date;
  public indexBatch: string;
  public lastOrderDate: Date;
}
