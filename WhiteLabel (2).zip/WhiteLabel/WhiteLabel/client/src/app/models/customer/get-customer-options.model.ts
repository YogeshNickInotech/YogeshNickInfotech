import { GetOptions } from 'leatherman';

export class GetCustomerOptions extends GetOptions {
    public siteId: string;
}
