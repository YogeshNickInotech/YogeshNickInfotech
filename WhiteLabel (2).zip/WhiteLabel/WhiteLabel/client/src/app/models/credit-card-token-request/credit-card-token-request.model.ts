import { CustomerCreditCard } from '../customer/_submodels/customer-credit-card.model';
import { CustomerBillingAddress } from '../customer/_submodels/customer-billing-address.model';

export class CreditCardTokenRequest {
    public creditCard: CustomerCreditCard = new CustomerCreditCard();
    public billingAddress: CustomerBillingAddress = new CustomerBillingAddress();
}
