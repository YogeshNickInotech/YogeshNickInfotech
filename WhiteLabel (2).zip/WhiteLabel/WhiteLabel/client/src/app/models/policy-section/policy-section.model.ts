import { BaseModel } from 'leatherman';
import { TestArtifact } from 'leatherman/lib/enums/test-artifact.enum';

/**
 * The policy section model
 */
export class PolicySection extends BaseModel {
  public siteId: string;
  public policy: string;
  public title: string;
  public content: string[] = [];
  public index: number;

  /**
   * Constructor
   * @param testArtifact - Boolean indicating whether the object is a test artifact
   */
  constructor(testArtifact?: TestArtifact) {
    super(testArtifact);
  }
}
