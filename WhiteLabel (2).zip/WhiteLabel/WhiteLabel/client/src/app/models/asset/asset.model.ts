import { BaseModel } from 'leatherman';
import { TestArtifact } from 'leatherman/lib/enums/test-artifact.enum';

/**
 * The asset model
 */
export class Asset extends BaseModel {
  public siteId: string;
  public token: string;
  public temporaryFileName: string;
  public fileName: string;

  /**
   * Constructor
   * @param testArtifact - Boolean indicating whether the object is a test artifact
   */
  constructor(testArtifact?: TestArtifact) {
    super(testArtifact);
  }
}
