import 'reflect-metadata';
import { BaseModel } from 'leatherman';
import { SitePricing } from './_submodels/site-pricing.model';
import { SiteBilling } from './_submodels/site-billing.model';
import { SiteContact } from './_submodels/site-contact.model';
import { SiteHeadings } from './_submodels/site-headings.model';
import { SiteFees } from './_submodels/site-fees.model';

export class Site extends BaseModel {
  public name: string;
  public displayName: string;
  public theme: string;
  public backgroundImage: string;
  public backgroundImage2: string;
  public backgroundImage3: string;
  public url: string;
  public appUrl: string;
  public pricing: SitePricing = new SitePricing();
  public billing: SiteBilling = new SiteBilling();
  public contact: SiteContact = new SiteContact();
  public headings: SiteHeadings = new SiteHeadings();
  public fees: SiteFees = new SiteFees();
  public dnsVerificationCode: string;
  public firstDnsHost: string;
  public secondDnsHost: string;
  public chatraId: string;
  public chatEnabled: boolean;
  public hideDisplayName: boolean;
  public googleAnalyticsId: string;
  public googleAnalyticsEnabled: boolean;
  public firstPromoterKey: string;
  public firstPromoterEnabled: boolean;
  public firstPromoterWid: string;
  public firstPromoterCid: string;
  public connectedAccountId: string;
  constructor() {
    super();
  }
}
