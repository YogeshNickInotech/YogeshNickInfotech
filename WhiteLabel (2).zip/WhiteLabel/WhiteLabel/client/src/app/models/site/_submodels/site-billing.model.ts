import { SiteBillingAddress } from './site-billing-address.model';
import { SiteBillingCreditCard } from './site-billing-credit-card.model';

export class SiteBilling {
  public billingAddress: SiteBillingAddress = new SiteBillingAddress();
  public creditCard: SiteBillingCreditCard = new SiteBillingCreditCard();
}
