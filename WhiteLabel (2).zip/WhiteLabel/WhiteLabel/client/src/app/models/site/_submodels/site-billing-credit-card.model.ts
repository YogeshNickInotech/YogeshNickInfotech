export class SiteBillingCreditCard {
  public creditCardNumber: string;
  public nameOnCard: string;
  public expirationMonth: number;
  public expirationYear: number;
  public cvv: string;
}
