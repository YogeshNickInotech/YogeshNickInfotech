import { Site } from "./site.model";

export class SolrSite {
  public _id: string;

  public name: string;
  public displayName: string;
  public url: string;
}
