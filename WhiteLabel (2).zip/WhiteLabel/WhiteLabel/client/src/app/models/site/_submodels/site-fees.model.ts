export class SiteFees {
  public monthly: number;
  public transaction: number;

  constructor() {
    this.monthly = 1000;
    this.transaction = 0.1;
  }
}
