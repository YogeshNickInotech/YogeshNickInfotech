import { SiteContactAddress } from './site-contact-address.model';

export class SiteHeadings {
  public faq = 'Frequently Asked Questions';
  public privacyPolicy = 'Privacy Policy';
  public termsOfService = 'Terms of Service';
  public refundPolicy = 'Refund Policy';
}
