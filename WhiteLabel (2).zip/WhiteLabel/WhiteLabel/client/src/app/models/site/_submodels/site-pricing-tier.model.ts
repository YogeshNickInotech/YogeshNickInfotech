export class SitePricingTier {
    public quantity: number;
    public unitPrice: number;
}