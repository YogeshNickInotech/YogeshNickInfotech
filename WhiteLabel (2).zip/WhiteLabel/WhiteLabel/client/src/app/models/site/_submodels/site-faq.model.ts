import { SiteBillingAddress } from './site-billing-address.model';
import { SiteBillingCreditCard } from './site-billing-credit-card.model';
import { SiteContactAddress } from './site-contact-address.model';

export class SiteFaq {
  public heading: string;
  public faqs: string;
}
