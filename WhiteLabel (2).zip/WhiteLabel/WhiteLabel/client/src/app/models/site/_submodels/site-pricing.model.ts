import { SitePricingTier } from "./site-pricing-tier.model";

export class SitePricing {
  public defaultPrice: number;
  public sitePricingTiers: SitePricingTier[];

  public static getUnitPrice(pricing: SitePricing, quantity: number) {
    if (quantity === 0) {
      return 0;
    } else {
      let unitPrice = pricing.defaultPrice;
      const { sitePricingTiers } = pricing;
      if (sitePricingTiers) {
        for (let i = 0; i < sitePricingTiers.length; i++) {
          const sitePricingTier = sitePricingTiers[i];
          if (quantity >= sitePricingTier.quantity) {
            unitPrice = sitePricingTier.unitPrice;
          } else {
            break;
          }
        }
      }
      return unitPrice;
    }
  }
}
