export class SiteBillingAddress {
  public address: string;
  public city: string;
  public state: string;
  public zip: string;
}
