/**
 * A class to store information about the property owner's bankruptcy
 */
export class PropertyOwnerBankruptcy {
  /** A flag to record whether the property owner has every been bankrupt */
  public bankruptcy: boolean;

  /** The date of the bankruptcy */
  public filingDate: Date;
}
