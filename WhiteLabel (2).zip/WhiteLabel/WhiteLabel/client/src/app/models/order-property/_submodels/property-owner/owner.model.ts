import { PropertyOwnerName } from './name.model';
import { PropertyOwnerPhone } from './phone.model';
import { PropertyOwnerDeath } from './death.model';
import { PropertyOwnerBankruptcy } from './bankruptcy.model';
import { OrderPropertyAddress } from '../address.model';

export class PropertyOwner {
  public pid: string;

  /** The name of the property owner */
  public name: PropertyOwnerName = new PropertyOwnerName();

  /** The mailing address of the property owner */
  public mailingAddress: OrderPropertyAddress = new OrderPropertyAddress();

  /** The phone numbers of the property owner */
  // public phone: SkipTracingPropertyOwnerPhone = new SkipTracingPropertyOwnerPhone();
  public phones: PropertyOwnerPhone[] = [];

  /** The email addresses of the property owner */
  // public email: SkipTracingPropertyOwnerEmail = new SkipTracingPropertyOwnerEmail();
  public emails: string[] = [];

  /** Information about the property owner's death */
  public death: PropertyOwnerDeath = new PropertyOwnerDeath();

  /** Information about any property owner bankruptcies */
  public bankruptcy: PropertyOwnerBankruptcy = new PropertyOwnerBankruptcy();
}
