// /**
//  * A class store the the property owner's email addresses
//  */
// export class SkipTracingPropertyOwnerEmail {
//   /** The first email address */
//   public email1: string;

//   /** The second email address */
//   public email2: string;

//   /**
//    * Convert the email addresses to lower case
//    */
//   public toLowerCase() {
//     this.email1 = this.email1 != undefined ? this.email1.toLowerCase() : undefined;
//     this.email2 = this.email2 != undefined ? this.email2.toLowerCase() : undefined;
//   }
// }
