/**
 * A class to store information about the property owner's death
 */
export class PropertyOwnerDeath {
  /** A flag to record whether the property owner is deceased */
  public deceased: boolean;

  /** The date that the property owner died */
  public dateOfDeath: Date;
}
