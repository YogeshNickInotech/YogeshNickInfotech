export class PropertyOwnerPhone {
  public number: string;
  public type: string;
  public score: number;
}
