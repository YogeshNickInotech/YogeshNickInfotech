/**
 * A class to store an address
 */
export class OrderPropertyAddress {
  /** The full property address (street number, street name, city, state and zip) */
  public fullAddress: string;

  /** The address (street number and street name) of the property */
  public address: string;

  /** The city of the property */
  public city: string;

  /** The state of the property */
  public state: string;

  /** The zip of the property */
  public zip: string;

  public dateFirstSeen: Date;
  public dateLastSeen: Date;

  public latitude: number;
  public longitude: number;
}
