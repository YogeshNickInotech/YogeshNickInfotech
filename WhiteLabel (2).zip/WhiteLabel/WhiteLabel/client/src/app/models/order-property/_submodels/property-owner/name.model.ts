/**
 * A class to store the property owner's name
 */
export class PropertyOwnerName {
  /** The property owner's first name */
  public first: string;

  /** The property owner's last name */
  public last: string;

  public full: string;
}
