import { BaseModel } from 'leatherman';
import { PropertyOwner } from './_submodels/property-owner/owner.model';
import { PropertyMeta } from './_submodels/meta.model';
import { OrderPropertyAddress } from './_submodels/address.model';
import { OrderPropertyRequest } from '../order/_submodels/order-property-request.model';

export class OrderProperty extends BaseModel {
  public orderId: string;
  public customerId: string;
  public siteId: string;
  public request: OrderPropertyRequest;
  public address: OrderPropertyAddress;
  public owner: PropertyOwner = new PropertyOwner();
  public meta: PropertyMeta = new PropertyMeta();
}
