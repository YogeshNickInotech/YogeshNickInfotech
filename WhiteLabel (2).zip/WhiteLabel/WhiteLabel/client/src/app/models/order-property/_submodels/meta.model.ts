export class PropertyMeta {
  /** The date that the data was retrieved from the skip tracing API and cached */
  public cacheDate: Date;
  /** A boolean flag indicating whether the data came from cached data */
  public fromCache = false;
  public fromApi = false;
  public fromIdiApi = false;
  public fromDelvePointApi = false;
  /** A boolean flag indicating whether no data was found for the property address */
  public hasData?: boolean;
  // /** A boolean flag indicating whether the request object was empty */
  // public emptyRequest?: boolean;
  /** The text of an error (if any) */
  public error?: string;
  /** The ID of the address in the MySQL database */
  public addressId?: number;
  public addressHash: string;
  public inputMailingAddressHash: string;
  public propertyId: string;
  public hasDelvePointData = false;
  public hasEnformionData = false;
  public hasIdiData = false;
  public secondaryMatch = false;
  public secondaryMatchType: string;
  public secondaryMatchPropertyId: string;
  public hasMailingAddress = false;
  public phoneNumberCount: number;
  public mailingAddressHash: string;

  public idiInputPropertyAddressValidated: boolean;
  public idiInputMailingAddressValidated: boolean;
  public idiMailingAddressValidated: boolean;
}
