// import { BaseModel } from 'leatherman';

// export class FirstPromoterCoupon extends BaseModel {
//   public promotions: Promo[] = [];
// }

// export class Promo {
//   public promo_code: string;
// }


