import { BaseModel } from 'leatherman';

export class FirstPromoterScriptDetails extends BaseModel {
  public cid: string;
  public domain: string;
  public wid: string;
}
