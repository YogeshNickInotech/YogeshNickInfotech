export class ReportRequest {}
