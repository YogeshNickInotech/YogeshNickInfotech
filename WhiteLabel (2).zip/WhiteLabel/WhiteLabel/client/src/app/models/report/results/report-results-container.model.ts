import { ReportFacet } from './report-facet.model';
import { ReportResultsDto } from './report-results-dto.model';
import { ReportOption } from './report-option.model';
import { ReportRow } from '../rows/report-row.model';

export class ReportResultsContainer<T extends ReportRow> {
  public reportType: string;
  public facets: ReportFacet[] = [];
  public options: ReportOption[] = [];
  public data: T[];

  constructor(reportResultsDto: ReportResultsDto<T>) {
    this.reportType = reportResultsDto.reportType;
    this.data = reportResultsDto.data;
    this.facets = reportResultsDto.facets;
    this.options = reportResultsDto.options;
  }
}
