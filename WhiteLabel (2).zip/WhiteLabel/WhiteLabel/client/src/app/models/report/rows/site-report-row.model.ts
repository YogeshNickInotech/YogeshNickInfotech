export class SiteReportRow {
  constructor(
    public label: string,
    public orderCount: number,
    public addressCount: number,
    public totalBilledAmount: number,
    public totalPaymentAmount: number,
    public netSales: number,
    public totalMatchCount: number,
    public totalMatchPercent: number
  ) { }
}
