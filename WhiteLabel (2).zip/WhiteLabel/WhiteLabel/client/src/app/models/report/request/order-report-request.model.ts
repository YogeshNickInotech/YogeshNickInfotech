import { ReportRequest } from './report-request.model';

export class OrderReportRequest extends ReportRequest {
  public siteId: string;
  public year: number;
  public month: number;
}
