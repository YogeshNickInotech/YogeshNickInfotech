export class ReportOptionValue {
    public label: string;
    public query: string;
}