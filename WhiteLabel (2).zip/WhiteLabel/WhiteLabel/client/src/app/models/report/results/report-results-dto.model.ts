import { ReportFacet } from './report-facet.model';
import { Status, Dto } from 'leatherman';
import { ReportOption } from './report-option.model';

export class ReportResultsDto<T> extends Dto {
  public reportType: string;
  public facets: ReportFacet[] = [];
  public options: ReportOption[] = [];
  constructor(code: Status, public data: T[]) {
    super(code);
  }
}
