import { GetOptions } from 'leatherman';

export class GetReportOptions extends GetOptions {
    public siteId: string;
}
