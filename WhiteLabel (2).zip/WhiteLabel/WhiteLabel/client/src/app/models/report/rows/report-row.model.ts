export class ReportRow {}
