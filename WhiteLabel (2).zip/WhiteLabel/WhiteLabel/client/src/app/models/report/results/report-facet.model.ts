import { ReportFacetItem } from './report-facet-item.model';

export class ReportFacet {
  public items: ReportFacetItem[];

  constructor(public field: string, public label: string) {
    this.items = [];
  }
}
