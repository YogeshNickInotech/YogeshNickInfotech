export class CustomerReportRow {
  constructor(
    public label: string,
    public orderCount: number,
    public addressCount: number,
    public orderValue: number,
    public totalMatchCount: number,
    public totalMatchPercent: number,
    public netSales: number
  ) {}
}
