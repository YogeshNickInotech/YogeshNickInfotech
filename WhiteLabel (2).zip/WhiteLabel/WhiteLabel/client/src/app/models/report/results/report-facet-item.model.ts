export class ReportFacetItem {
  public token: string;
  public value: string;
  public label: string;
  public query: string;
  public active: boolean;

  constructor() {
    this.label = '';
    this.query = '';
    this.active = false;
  }
}
