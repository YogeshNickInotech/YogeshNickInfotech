import { ReportOptionValue } from "./report-option-value.model";

export class ReportOption {
    public name: string;
    public label: string;
    public selectedValue: string;
    public values: ReportOptionValue[] = [];
}