export class TipSettings {
    public hideAll = false;
    public hideDashboard: boolean;
    public hideSettings: boolean;
}
