import 'reflect-metadata';
import { ListSettings } from './_submodels/list-settings.model';
import { BaseModel } from 'leatherman';
import { TipSettings } from './_submodels/tip-settings.model';

/**
 * description
 */
export class UserSettings extends BaseModel {
  /** The name of the user setting */
  public sites: ListSettings = new ListSettings();
  public customers: ListSettings = new ListSettings();
  public orders: ListSettings = new ListSettings();
  public users: ListSettings = new ListSettings();

  public tips: TipSettings = new TipSettings();

  constructor() {
    super();
  }
}

