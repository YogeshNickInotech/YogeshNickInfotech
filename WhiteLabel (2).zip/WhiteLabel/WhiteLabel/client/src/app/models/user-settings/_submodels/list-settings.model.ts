import 'reflect-metadata';

export class ListSettings {
  public sortColumn: string;
  public sortAscending: boolean;
}
