import { BaseModel } from 'leatherman';
import { CustomerCreditCard } from '../customer/_submodels/customer-credit-card.model';
import { CustomerBillingAddress } from '../customer/_submodels/customer-billing-address.model';
import { OrderPropertyRequest } from '../order/_submodels/order-property-request.model';
import { OrderCost } from '../order/_submodels/order-cost.model'; 

export class OrderRequest extends BaseModel {
    public orderId: string;
    public token: string;
    public siteId: string;
    public customerId: string;
    public promoCode: string;
    public firstPromoterTrackingId: string;
    public requestCount: number;
    public requests: OrderPropertyRequest[] = [];
    public creditCard: CustomerCreditCard = new CustomerCreditCard();
    public billingAddress: CustomerBillingAddress = new CustomerBillingAddress();
    public cost: OrderCost = new OrderCost(); 
}
