export class PaymentInfo {
   
  public id: string;
  public object: string;
  public amount: number;
  public currency: string;
  public description: string;
  public fee: number;
  public status: string;
  public type: string; 

}
