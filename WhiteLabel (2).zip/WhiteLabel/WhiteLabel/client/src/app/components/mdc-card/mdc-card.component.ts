import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { SafeStyle, DomSanitizer } from '@angular/platform-browser';
import { CardItem } from './_models/card-item.model';
import { MdcCardUIService } from './_services/mdc-card-ui.service';

@Component({
  selector: 'app-mdc-card',
  templateUrl: './mdc-card.component.html',
  styleUrls: ['./mdc-card.component.scss']
})
export class MdcCardComponent implements OnInit {
  @Input() item: CardItem;
  @Input() uiService: MdcCardUIService;
  @ViewChild('socialButton', { static: false })
  private socialButtonElementRef: ElementRef;
  @ViewChild('otherButton', { static: false })
  private otherButtonElementRef: ElementRef;

  constructor(private domSanitizer: DomSanitizer) {}

  ngOnInit() {}

  // public favorite() {
  //   this.item.favorite = true;
  // }

  public pinItem() {
    this.uiService.pinItem(this.item);
  }

  // public unfavorite() {
  //   this.item.favorite = false;
  // }

  public getStyle(item: CardItem): SafeStyle {
    // if (item.imageUrl) {
    return this.domSanitizer.bypassSecurityTrustStyle(
      'url(' + item.imageUrl + ')'
    );
    // } else {
    //   return this.domSanitizer.bypassSecurityTrustStyle(
    //     'url(' + item.defaultImageDataUri + ')'
    //   );
    // }
  }

  // openSocialMenu
  public openSocialMenu() {
    this.uiService.openSocialMenu(this.item, this.socialButtonElementRef);
  }

  // openOtherMenu
  public openOtherMenu() {
    this.uiService.openOtherMenu(this.item, this.otherButtonElementRef);
  }
}
