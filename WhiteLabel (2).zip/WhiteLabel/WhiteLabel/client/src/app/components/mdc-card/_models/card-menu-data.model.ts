import { ElementRef } from '@angular/core';

export class CardMenuData {
  constructor(public data: any, public anchorElement: ElementRef) {}
}
