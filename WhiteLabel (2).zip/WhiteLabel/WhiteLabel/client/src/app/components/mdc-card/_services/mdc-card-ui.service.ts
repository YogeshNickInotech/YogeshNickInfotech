import { BaseComponentUIService } from 'leatherman';
import { Subject } from 'rxjs';
import { CardItem } from '../_models/card-item.model';
import { ElementRef } from '@angular/core';
import { CardMenuData } from '../_models/card-menu-data.model';

export class MdcCardUIService extends BaseComponentUIService {
  public openSocialMenuSubject$ = new Subject<CardMenuData>();
  public openOtherMenuSubject$ = new Subject<CardMenuData>();
  public pinItemSubject$ = new Subject<CardItem>();

  public openOtherMenu(item: CardItem, anchorElement: ElementRef) {
    const menuData = new CardMenuData(item, anchorElement);
    this.openOtherMenuSubject$.next(menuData);
  }

  public openSocialMenu(item: CardItem, anchorElement: ElementRef) {
    const menuData = new CardMenuData(item, anchorElement);
    this.openSocialMenuSubject$.next(menuData);
  }

  public pinItem(item: CardItem) {
    this.pinItemSubject$.next(item);
  }
}
