export class CardItem {
  public hasImage: boolean;

  constructor(
    public name: string,
    public type: string,
    public description: string,
    public imageUrl?: string,
    public favorite?: boolean
  ) {
    if (imageUrl) {
      this.hasImage = true;
    }
  }
}
