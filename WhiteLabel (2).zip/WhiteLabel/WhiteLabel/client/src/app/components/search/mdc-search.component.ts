import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-mdc-search',
  templateUrl: './mdc-search.component.html',
  styleUrls: ['./mdc-search.component.scss']
})
export class MdcSearchComponent implements OnInit {
  @Input() defaultSearch: string;
  @Output() searchTextChanged: EventEmitter<string> = new EventEmitter<
    string
  >();
  @Output() filterButtonClicked: EventEmitter<void> = new EventEmitter<void>();

  public ngOnInit() {}

  public onSearch(event: any) {
    this.searchTextChanged.emit(event);
  }

  public onFilterButtonClicked(event: any) {
    this.filterButtonClicked.emit();
  }
}
