import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SearchResultFacet, SearchResultFacetItem } from 'leatherman';

@Component({
  selector: 'app-mdc-report-facet',
  templateUrl: './mdc-report-facet.component.html',
  styleUrls: ['./mdc-report-facet.component.scss']
})
export class MdcReportFacetComponent implements OnInit {
  @Input() public set facet(value: SearchResultFacet) {
    this._facet = value;
    this.facetItems = value.items;
  }
  public get facet(): SearchResultFacet {
    return this._facet;
  }

  private _facet: SearchResultFacet;
  public facetItems: SearchResultFacetItem[];

  @Output() facetItemClicked: EventEmitter<
    SearchResultFacetItem
  > = new EventEmitter<SearchResultFacetItem>();

  public ngOnInit() {}

  public onFacetItemClicked(facetItem: SearchResultFacetItem) {
    this.facetItemClicked.emit(facetItem);
  }
}
