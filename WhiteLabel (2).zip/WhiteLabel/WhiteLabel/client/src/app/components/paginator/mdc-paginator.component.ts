import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { PaginatorRow } from './_models/paginator-row.model';
import { PreviousButtonState } from './_models/previous-button-state.model';
import { NextButtonState } from './_models/next-button-state.model';
import { DecimalPipe } from '@angular/common';

@Component({
  selector: 'app-mdc-paginator',
  templateUrl: './mdc-paginator.component.html',
  styleUrls: ['./mdc-paginator.component.scss']
})
export class MdcPaginatorComponent implements OnInit {
  @Input() set currentPage(value: number) {
    if (this._currentPage === value) {
      return;
    }
    this._currentPage = value;
    this.initializePages();
    this.calculatePageRange();
  }
  get currentPage(): number {
    return this._currentPage;
  }
  private _currentPage: number;

  @Input() set pageCount(value: number) {
    // if (this._pageCount === value) {
    //   return;
    // }
    this._pageCount = value;
    this.initializePages();
    this.calculatePageRange();
  }
  get pageCount(): number {
    return this._pageCount;
  }
  private _pageCount: number;

  @Input() set rowCount(value: number) {
    // if (this._pageSize === value) {
    //   return;
    // }
    this._rowCount = value;
    this.calculatePageRange();
  }
  get rowCount(): number {
    return this._rowCount;
  }
  private _rowCount: number;

  @Input() set pageSize(value: number) {
    // if (this._pageSize === value) {
    //   return;
    // }
    this._pageSize = value;
    this.calculatePageRange();
  }
  get pageSize(): number {
    return this._pageSize;
  }
  private _pageSize: number;

  @Output() pageChanged: EventEmitter<number> = new EventEmitter<number>();

  public previousButtonState: PreviousButtonState = new PreviousButtonState();
  public previousRows: PaginatorRow[] = [];
  public currentRows: PaginatorRow[] = [];
  public nextRows: PaginatorRow[] = [];
  public nextButtonState: NextButtonState = new NextButtonState();

  public firstRow = 0;
  public lastRow = 0;
  public noData = false;

  constructor(private decimalPipe: DecimalPipe) {}

  public ngOnInit() {
    this.initializePages();
    this.calculatePageRange();
  }

  public formatRowCount(rowCount: number): string {
    if (rowCount === 1) {
      return '1 row';
    } else {
      const formattedRowCount = this.decimalPipe.transform(rowCount, '1.0-0');
      return `${formattedRowCount} rows`;
    }
  }

  public formatPageRange(firstRow: number, lastRow: number): string {
    const formattedFirstRow = this.decimalPipe.transform(firstRow, '1.0-0');
    const formattedLastRow = this.decimalPipe.transform(lastRow, '1.0-0');
    return `Rows ${formattedFirstRow} to ${formattedLastRow}`;
  }

  public pageClicked(pageNumber: number, enabled: boolean) {
    if (pageNumber === this._currentPage) {
      return;
    }
    if (enabled === false) {
      return;
    }
    this.pageChanged.emit(pageNumber);
  }

  private calculatePageRange() {
    if (this.rowCount === 0) {
      this.noData = true;
    } else {
      this.noData = false;
    }
    this.firstRow = (this.currentPage - 1) * this.pageSize + 1;
    this.lastRow = this.currentPage * this.pageSize;
    if (this.lastRow > this.rowCount) {
      this.lastRow = this.rowCount;
    }
  }

  private initializePages() {
    this.currentRows = [];
    if (this._currentPage > 1) {
      this.previousButtonState.firstEnabled = true;
      this.previousButtonState.previousEnabled = true;
      this.previousButtonState.previousPageNumber = this._currentPage - 1;
    } else {
      this.previousButtonState.firstEnabled = false;
      this.previousButtonState.previousEnabled = false;
    }

    for (
      let pageNumber = this._currentPage - 3;
      pageNumber < this._currentPage;
      pageNumber++
    ) {
      if (pageNumber < 1) {
        continue;
      }
      this.currentRows.push(new PaginatorRow(pageNumber));
    }

    this.currentRows.push(new PaginatorRow(this._currentPage, true));

    for (
      let pageNumber = this._currentPage + 1;
      pageNumber < this._currentPage + 3;
      pageNumber++
    ) {
      if (pageNumber > this.pageCount) {
        continue;
      }
      this.currentRows.push(new PaginatorRow(pageNumber));
    }

    if (this._currentPage < this.pageCount) {
      this.nextButtonState.nextEnabled = true;
      this.nextButtonState.nextPageNumber = this._currentPage + 1;
      this.nextButtonState.lastEnabled = true;
      this.nextButtonState.lastPageNumber = this.pageCount;
    } else {
      this.nextButtonState.nextEnabled = false;
      this.nextButtonState.lastEnabled = false;
    }
  }
}
