export class PaginatorRow {
  public pageNumber: number;
  public current: boolean;

  constructor(pageNumber?: number, current?: boolean) {
    this.pageNumber = pageNumber;
    this.current = !!current ? current : false;
  }
}
