export class PreviousButtonState {
  public firstEnabled: boolean;
  public previousEnabled: boolean;
  public previousPageNumber: number;
}
