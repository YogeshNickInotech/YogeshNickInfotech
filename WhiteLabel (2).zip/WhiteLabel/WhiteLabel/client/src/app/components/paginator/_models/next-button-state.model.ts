export class NextButtonState {
  public nextEnabled: boolean;
  public nextPageNumber: number;
  public lastEnabled: boolean;
  public lastPageNumber: number;
}
