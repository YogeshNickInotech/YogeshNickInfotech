import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SearchResultFacet, SearchResultFacetItem } from 'leatherman';

@Component({
  selector: 'app-mdc-facet',
  templateUrl: './mdc-facet.component.html',
  styleUrls: ['./mdc-facet.component.scss']
})
export class MdcFacetComponent implements OnInit {
  @Input() public set facet(value: SearchResultFacet) {
    this._facet = value;

    if (this.expanded === true) {
      this.facetItems = value.items;
    } else {
      this.facetItems = value.items.slice(0, 8);
    }
  }
  public get facet(): SearchResultFacet {
    return this._facet;
  }
  @Output() facetItemClicked: EventEmitter<
    SearchResultFacetItem
  > = new EventEmitter<SearchResultFacetItem>();

  private _facet: SearchResultFacet;
  public facetItems: SearchResultFacetItem[];
  public expanded = false;

  public ngOnInit() {}

  public onFacetItemClicked(facetItem: SearchResultFacetItem) {
    this.facetItemClicked.emit(facetItem);
  }

  public onExpandIconClicked() {
    this.expanded = !this.expanded;
    if (this.expanded === true) {
      this.facetItems = this._facet.items;
    } else {
      this.facetItems = this._facet.items.slice(0, 8);
    }
  }
}
