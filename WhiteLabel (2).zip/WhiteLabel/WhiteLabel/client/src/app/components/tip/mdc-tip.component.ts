import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Location } from '@angular/common';
import { UserSettingsService } from 'src/app/services/user-settings/user-settings.service';
import { UserSettings } from 'src/app/models/user-settings/user-settings.model';

@Component({
  selector: 'app-mdc-tip',
  templateUrl: './mdc-tip.component.html',
  styleUrls: ['./mdc-tip.component.scss']
})
export class MdcTipComponent implements OnInit {
  @Input() public token: string;
  public showTip = false;
  private userSettings: UserSettings;

  constructor(private userSettingsService: UserSettingsService) { }
  public async ngOnInit() {
    await this.loadData();
  }

  public async onClose() {
    this.userSettings.tips['hide' + this.token] = true;
    const result = await this.userSettingsService.updateUserSettings(this.userSettings);
    this.showTip = false;
  }

  private async loadData() {
    this.userSettings = await this.userSettingsService.getUserSettings();
    if (this.userSettings.tips.hideAll === true || this.userSettings.tips['hide' + this.token] === true) {
      this.showTip = false;
    } else {
      this.showTip = true;
    }

  }
}
