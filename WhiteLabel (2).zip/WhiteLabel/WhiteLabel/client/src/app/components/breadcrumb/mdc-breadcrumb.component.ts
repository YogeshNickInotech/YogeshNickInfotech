import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-mdc-breadcrumb',
  templateUrl: './mdc-breadcrumb.component.html',
  styleUrls: ['./mdc-breadcrumb.component.scss']
})
export class MdcBreadcrumbComponent implements OnInit {
  @Input() public back: string;
  @Input() public current: string;
  @Output() backLinkClick: EventEmitter<void> = new EventEmitter<void>();

  constructor() {}
  public ngOnInit() {}

  public onBack() {
    this.backLinkClick.emit();
  }
}
