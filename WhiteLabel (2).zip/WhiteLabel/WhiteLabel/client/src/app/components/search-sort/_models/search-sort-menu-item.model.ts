export class SearchSortMenuItem {
  public buttonLabel: string;
  public buttonIcon: string;
  public text: string;
}
