import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SearchSortMenuItem } from './_models/search-sort-menu-item.model';

@Component({
  selector: 'app-mdc-search-sort',
  templateUrl: './mdc-search-sort.component.html',
  styleUrls: ['./mdc-search-sort.component.scss']
})
export class MdcSearchSortComponent implements OnInit {
  @Input() defaultSearch: string;
  @Input() buttonLabel: string;
  @Input() buttonIcon: string;
  @Input() menuItems: SearchSortMenuItem[] = [];
  @Output() menuItemChanged: EventEmitter<string> = new EventEmitter<string>();
  @Output() searchTextChanged: EventEmitter<string> = new EventEmitter<
    string
  >();
  @Output() filterButtonClicked: EventEmitter<void> = new EventEmitter<void>();

  public ngOnInit() {}

  public onMenuSelect(event: any) {
    const menuItem = this.menuItems[event.index];
    this.menuItemChanged.emit(menuItem.text);
  }

  public onSearch(event: any) {
    this.searchTextChanged.emit(event);
  }

  public onFilterButtonClicked(event: any) {
    this.filterButtonClicked.emit();
  }
}
