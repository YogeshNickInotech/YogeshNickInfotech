import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Location } from '@angular/common';
import { UserSettingsService } from 'src/app/services/user-settings/user-settings.service';
import { UserSettings } from 'src/app/models/user-settings/user-settings.model';

@Component({
  selector: 'app-mdc-under-construction',
  templateUrl: './mdc-under-construction.component.html',
  styleUrls: ['./mdc-under-construction.component.scss']
})
export class MdcUnderConstructionComponent implements OnInit {

  public async ngOnInit() {
  }
}
