import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CmsLayoutComponent } from './layouts/cms/cms-layout.component';
import { PageNotFoundComponent } from 'leatherman';
import { Login2Component } from './pages/_common/login/login.component';
import { PublicLayoutComponent } from './layouts/public/public-layout.component';
import { AdminLayoutComponent } from './layouts/admin/admin-layout.component';
import { RequestPasswordReset2Component } from './pages/_common/request-password-reset/request-password-reset.component';
import { ResetPassword2Component } from './pages/_common/reset-password/reset-password.component';
import { VerifyEmailComponent } from './pages/_common/verify-email/verify-email.component';
import { AuthGuardUtil } from './util/auth-guard/auth-guard.util';

export const routes: Routes = [
  { path: '', pathMatch: 'full', component: Login2Component },
  {
    path: '',
    component: AdminLayoutComponent,
    canActivate: [AuthGuardUtil],
    data: { roles: ['admin'] },
    children: [
      { path: 'admin', loadChildren: './pages/admin/admin.module#AdminModule' }
    ]
  },
  {
    path: '',
    component: CmsLayoutComponent,
    canActivate: [AuthGuardUtil],
    data: { roles: ['site-owner'] },
    children: [
      { path: 'cms', loadChildren: './pages/cms/cms.module#CmsModule' }
    ]
  },
  {
    path: '',
    canActivate: [AuthGuardUtil],
    component: PublicLayoutComponent,
    data: { roles: ['user'] },
    children: [
      { path: 'app', loadChildren: './pages/public/public.module#PublicModule' }
    ]
  },
  { path: 'request-password-reset', component: RequestPasswordReset2Component },
  { path: 'reset-password', component: ResetPassword2Component },
  { path: 'verify-email', component: VerifyEmailComponent },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
