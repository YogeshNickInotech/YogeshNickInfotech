import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  ViewChild
} from '@angular/core';
import { NavigationState } from '../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../services/navigation/navigation.service';
import {
  BaseComponent,
  GetOptions,
  SearchResultFacet,
  SearchResultFacetItem
} from 'leatherman';
import { UserSettingsService } from '../../../services/user-settings/user-settings.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ListState } from '../../../models/list-state/list-state.model';
import { Sort } from '@angular/material/sort';
import { NotificationService } from '../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../services/notification/_models/notification.model';
import { MdcMenu, MdcIconRegistry } from '@angular-mdc/web';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { SolrCustomer } from 'src/app/models/customer/solr-customer.model';
import { TimerUtil } from 'src/app/util/timer/timer.util';
import { CmsCustomerPagerService } from 'src/app/services/pager/cms-customer-pager.service';
import { GetCustomerOptions } from 'src/app/models/customer/get-customer-options.model';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-cms-customers',
  templateUrl: './cms-customers.component.html',
  styleUrls: ['./cms-customers.component.scss']
})
export class CmsCustomersComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  // Public properties
  public customers: SolrCustomer[] = [];
  public numFound = 0;
  public facets: SearchResultFacet[] = [];
  public pageState: ListState = new ListState();
  public userRole: string;
  public menuCustomerId: string;
  public displayedColumns: string[] = [
    'fullName',
    'dateCreated',
    'lastOrderDate',
    'addressCount',
    'orderCount',
    'actions'
  ];
  private dialogIsOpen: boolean;
  private siteId: string;
  private navigationState: NavigationState;
  @ViewChild('otherMenu', { static: false })
  private otherMenu: MdcMenu;

  // constructor
  constructor(
    private userService: UserService,
    private customerPagerService: CmsCustomerPagerService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private customerService: CustomerService,
    private userSettingsService: UserSettingsService,
    private notificationService: NotificationService,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Customers';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = false;
    this.activatedRoute.queryParams.subscribe(async params => {
      this.isLoading = true;
      await this.initializePageState(params);
      await this.loadData();
      this.isLoading = false;
      this.isInitialized = true;
    });
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  // onDelete
  public onDelete = async (event: any, id: string) => {
    event.stopPropagation();
    if ((await this.customerService.deleteCustomer(id)) === false) {
      return;
    }
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  // onEdit
  public onEdit = async (event: any, id: string) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedCustomer = await this.customerService.editCustomer(id);
    this.dialogIsOpen = false;
    if (editedCustomer) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public async onFacetItemClicked(facetItem: SearchResultFacetItem) {
    this.pageState.filter = facetItem.query;
    this.pageState.currentPage = 1;
    this.pageState.sortColumn = '';
    this.updateUrl();
    await this.loadData();
  }

  // onNew
  public onNew = async () => {
    // const newCustomer = await this.customerService.newCustomer();
    // if (newCustomer) {
    //   await TimerUtil.delay(1000);
    //   await this.loadData();
    // }
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => {
    // let customer: Customer;
    // if (!this.customers) {
    //   return;
    // }
    // switch (notification.type) {
    //   case 'customer-file-import-complete':
    //   case 'customer-api-dataset-import-complete':
    //     await TimerUtil.delay(5000);
    //     customer = CollectionUtil.findById(
    //       this.customers,
    //       notification.data.customerId
    //     );
    //     if (customer) {
    //       const updatedCustomer = await this.customerService.getCustomer(
    //         notification.data.customerId
    //       );
    //       customer.status = updatedCustomer.status;
    //       customer.addressCount = updatedCustomer.addressCount;
    //       customer.fromCacheCount = updatedCustomer.fromCacheCount;
    //       customer.secondaryMatchCount = updatedCustomer.secondaryMatchCount;
    //       customer.fromServiceCount = updatedCustomer.fromServiceCount;
    //       customer.matchCount = updatedCustomer.matchCount;
    //       customer.matchPercent = updatedCustomer.matchPercent;
    //     }
    //     break;
    //   case 'customer-file-import-progress':
    //   case 'customer-api-dataset-import-progress':
    //     customer = CollectionUtil.findById(
    //       this.customers,
    //       notification.data.customerId
    //     );
    //     if (customer) {
    //       customer.status = notification.message;
    //     }
    //     break;
    // }
  }

  // onOtherMenu
  public openOtherMenu = async (event: any, customerId: string) => {
    event.stopPropagation();
    this.menuCustomerId = customerId;
    this.otherMenu.fixed = true;
    this.otherMenu.anchorElement = event.target;
    this.otherMenu.open = true;
  }

  // onPageChanged
  public async onPageChanged(pageNumber: number) {
    this.pageState.currentPage = pageNumber;
    this.updateUrl();
    await this.loadData();
    window.scrollTo(0, 0);
  }

  public onRowClick(customer: SolrCustomer) {
    const currentCustomerIndex = this.getCustomerIndex(customer._id);
    this.customerPagerService.initialize(
      currentCustomerIndex,
      this.pageState,
      this.customers,
      this.siteId
    );
    this.router.navigate([`/cms/customers/${customer._id}`]);
  }

  // onSearchTextChanged
  public async onSearchTextChanged(query: any) {
    this.pageState.query = query;
    this.updateUrl();
    await this.loadData();
  }

  // onSortChange
  public async onSortChange(sort: Sort) {
    console.log('Sort changed');
    this.pageState.sortColumn = sort.active;
    this.pageState.sortAscending = sort.direction === 'desc' ? false : true;
    this.updateUrl();
    await this.loadData();
    const userSettings = await this.userSettingsService.getUserSettings();
    userSettings.customers.sortColumn = this.pageState.sortColumn;
    userSettings.customers.sortAscending = this.pageState.sortAscending;
    await this.userSettingsService.updateUserSettings(userSettings);
  }

  // getOptions
  private getOptions(): GetCustomerOptions {
    const options = new GetCustomerOptions(
      this.pageState.currentPage,
      this.pageState.pageSize
    );
    if (this.pageState.sortColumn) {
      options.setSort(this.pageState.sortColumn, this.pageState.sortAscending);
    }
    options.query = this.encodeURIComponent(this.pageState.query);
    options.filter = this.pageState.filter;
    options.siteId = this.siteId;
    return options;
  }

  // getCustomerIndex
  private getCustomerIndex(customerId: string): number {
    const customerIndex = this.customers.findIndex(p => p._id === customerId);
    return customerIndex;
  }

  // initializePageState
  private async initializePageState(queryParams: any) {
    const userSettings = await this.userSettingsService.getUserSettings();
    this.pageState.query = this.decodeURIComponent(queryParams.q);
    this.pageState.filter = queryParams.f;
    if (queryParams.sort) {
      this.pageState.sortColumn = queryParams.sort;
    } else if (userSettings.customers && userSettings.customers.sortColumn) {
      this.pageState.sortColumn = userSettings.customers.sortColumn;
    } else {
      this.pageState.sortColumn = 'relevance';
    }
    if (queryParams.customer) {
      this.pageState.sortAscending =
        queryParams.customer.toLowerCase() === 'desc' ? false : true;
    } else if (
      userSettings.customers &&
      userSettings.customers.sortAscending !== undefined
    ) {
      this.pageState.sortAscending = userSettings.customers.sortAscending;
    } else if (queryParams.sort === undefined) {
      this.pageState.sortAscending = false;
    } else {
      this.pageState.sortAscending = true;
    }
    if (queryParams.p) {
      const currentPage = parseInt(queryParams.p, 10);
      this.pageState.currentPage = currentPage > 0 ? currentPage : 1;
    } else {
      this.pageState.currentPage = 1;
    }
    this.pageState.pageSize = 25;
  }

  // loadData
  private async loadData() {
    this.siteId = await this.userService.getUserSiteId();
    const options = this.getOptions();
    const searchResultsContainer = await this.customerService.getCustomers(
      options
    );
    this.numFound = searchResultsContainer.meta.numFound;
    this.customers = searchResultsContainer.data;
    this.facets = searchResultsContainer.facets;
    this.pageState.pageCount = GetOptions.calculatePageCount(
      searchResultsContainer.meta.numFound,
      this.pageState.pageSize
    );
    this.pageState.rowCount = searchResultsContainer.meta.numFound;
  }

  public onBackLinkClicked() {
    this.router.navigate(['cms/dashboard']);
  }

  // updateUrl
  private updateUrl() {
    const queryParams: any = {};
    if (this.pageState.query) {
      queryParams.q = this.encodeURIComponent(this.pageState.query);
    }
    if (this.pageState.filter) {
      queryParams.f = this.pageState.filter;
    }

    if (!this.pageState.sortColumn) {
      queryParams.sort = 'relevance';
      queryParams.order = 'asc';
    } else if (this.pageState.sortColumn !== 'relevance') {
      queryParams.sort = this.pageState.sortColumn;
      queryParams.order =
        this.pageState.sortAscending === true ? 'asc' : 'desc';
    }

    queryParams.p = this.pageState.currentPage;
    this.router.navigate(['/cms/customers'], {
      queryParams
    });
  }
}
