import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  Inject
} from '@angular/core';
import { NavigationState } from '../../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../../services/navigation/navigation.service';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig,
  GetOptions
} from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { MdcIconRegistry } from '@angular-mdc/web';
import { UserService } from 'src/app/services/user/user.service';
import { ListState } from 'src/app/models/list-state/list-state.model';
import { FaqService } from 'src/app/services/faq/faq.service';
import { Faq } from 'src/app/models/faq/faq.model';
import { TimerUtil } from 'src/app/util/timer/timer.util';
import { SiteService } from 'src/app/services/site/site.service';
import { SiteHeadings } from 'src/app/models/site/_submodels/site-headings.model';

@Component({
  selector: 'app-cms-site-faq',
  templateUrl: './cms-site-faq.component.html',
  styleUrls: ['./cms-site-faq.component.scss']
})
export class CmsSiteFaqComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public serverUrl: string;
  public pageState: ListState = new ListState();
  public faqs: Faq[];
  public heading: string;
  private navigationState: NavigationState;
  private siteId: string;
  private dialogIsOpen: boolean; 

  // constructor
  constructor(
    @Inject(LeathermanAppConfigInjectionToken) config: ILeathermanAppConfig,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private faqService: FaqService,
    private siteService: SiteService,
    private userService: UserService,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'FAQ';
    // this.navigationState.selectedTabIndex = 2;
    // this.navigationState.addTab(
    //   'General',
    //   '/cms/setup',
    //   'info'
    // );
    // this.navigationState.addTab(
    //   'Policies',
    //   '/cms/setup/policies',
    //   'account_balance'
    // );
    // this.navigationState.addTab(
    //   'FAQ',
    //   '/cms/setup/faq',
    //   'question_answer'
    // );
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
    this.serverUrl = config.serverUrl;
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = false;
    this.activatedRoute.queryParams.subscribe(async params => {
      this.isLoading = true;
      await this.initializePageState(params);
      this.siteId = await this.userService.getUserSiteId();
      await this.loadData();
      this.isLoading = false;
      this.isInitialized = true;
    });
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
  }

  public getQuestionLabel(index: number): string {
    if (index === 0) {
      return 'Questions';
    }
    return '';
  }

  public onBackLinkClicked() {
    this.router.navigate(['cms/dashboard']);
  }

  // onDeleteFaq
  public onDeleteFaq = async (event: any, id: string) => {
    event.stopPropagation();
    if ((await this.faqService.deleteFaq(id)) === false) {
      return;
    }
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  // onEditFaq
  public onEditFaq = async (event: any, id: string) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedFaq = await this.faqService.editFaq(id);
    this.dialogIsOpen = false;
    if (editedFaq) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onEditFaqHeading
  public onEditFaqHeading = async (event: any) => {
    event.stopPropagation();
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    const editedHeading = await this.siteService.editSiteHeading(this.siteId, 'faq');
    this.dialogIsOpen = false;
    if (editedHeading) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public async onNewFaq() {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    const newFaq = await this.faqService.newFaq(this.siteId);
    this.dialogIsOpen = false;
    if (newFaq) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onPageChanged
  public async onPageChanged(pageNumber: number) {
    // this.pageState.currentPage = pageNumber;
    // this.updateUrl();
    // await this.loadData();
    // window.scrollTo(0, 0);
  }

  // initializePageState
  private async initializePageState(queryParams: any) {
    if (queryParams.p) {
      const currentPage = parseInt(queryParams.p, 10);
      this.pageState.currentPage = currentPage > 0 ? currentPage : 1;
    } else {
      this.pageState.currentPage = 1;
    }
    this.pageState.pageSize = 25;
  }

  public async loadData() {
    const site = await this.siteService.getSite(this.siteId);
    if (!site.headings) {
      site.headings = new SiteHeadings();
    }
    this.heading = site.headings.faq;
    const options = new GetOptions();
    options.setSort('index', true);
    this.faqs = await this.faqService.getFaqs(options, this.siteId);
    const faqCount = await this.faqService.getFaqCount(options, this.siteId);

    this.pageState.pageCount = GetOptions.calculatePageCount(
      faqCount,
      this.pageState.pageSize
    );
    this.pageState.rowCount = faqCount;
  }
}
