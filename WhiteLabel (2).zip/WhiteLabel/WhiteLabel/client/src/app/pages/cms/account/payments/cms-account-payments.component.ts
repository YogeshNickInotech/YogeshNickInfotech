import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { NavigationState } from '../../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../../services/navigation/navigation.service';
import { BaseComponent } from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from '../../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../../services/notification/_models/notification.model';
import { MdcIconRegistry } from '@angular-mdc/web';
import { TimerUtil } from 'src/app/util/timer/timer.util';
import { UserService } from 'src/app/services/user/user.service';
import { User } from 'src/app/models/user/user.model';
import { SiteService } from 'src/app/services/site/site.service';
import { PaymentService } from 'src/app/services/payment/payment.service';
import { Site } from 'src/app/models/site/site.model';
import { SiteBilling } from 'src/app/models/site/_submodels/site-billing.model';
import { SiteBillingCreditCard } from 'src/app/models/site/_submodels/site-billing-credit-card.model';

@Component({
  selector: 'app-cms-account-payments',
  templateUrl: './cms-account-payments.component.html',
  styleUrls: ['./cms-account-payments.component.scss']
})
export class CmsAccountPaymentsComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public user: User;
  public siteId: string;
  public site: Site;
  private navigationState: NavigationState;
  private dialogIsOpen: boolean;
  // constructor
  constructor(
    private userService: UserService,
    private siteService: SiteService,
    private paymentService: PaymentService,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private router: Router,
    iconRegistry: MdcIconRegistry,
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Account';
    this.navigationState.selectedTabIndex = 2;
    this.navigationState.addTab('Your Account', '/cms/account', 'person');
    this.navigationState.addTab(
      'Billing',
      '/cms/account/billing',
      'credit_card'
    );
    this.navigationState.addTab(
      'Payments',
      '/cms/account/payments',
      'attach_money'
    );
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = true; 
    this.isLoading = false;
    this.user = await this.userService._getCurrentUser();
    this.siteId = await this.userService.getUserSiteId(); 
  }
 
  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public getCreditCardNumber(): string {
    if (!this.site.billing.creditCard || !this.site.billing.creditCard.creditCardNumber) {
      return '';
    }
    const creditCardNumber = '**** **** **** ' + this.site.billing.creditCard.creditCardNumber.substr(12, 4);
    return creditCardNumber;
  }


  public getCreditCardExpirationDate(): string {
    if (!this.site.billing.creditCard || !this.site.billing.creditCard.expirationMonth || !this.site.billing.creditCard.expirationYear) {
      return '';
    }
    const expirationDate = `${this.site.billing.creditCard.expirationMonth}/${this.site.billing.creditCard.expirationYear}`;
    return expirationDate;
  }

  public getCreditCardCvv(): string {
    if (!this.site.billing.creditCard || !this.site.billing.creditCard.cvv) {
      return '';
    }
    return '***';
  }

  public async loadData() {
    this.user = await this.userService._getCurrentUser();
    this.site = await this.siteService.getSite(this.siteId);

    if (!this.site.billing) {
      this.site.billing = new SiteBilling();
    }
    if (!this.site.billing.creditCard) {
      this.site.billing.creditCard = new SiteBillingCreditCard();
    }
  }

  public onBackLinkClicked() {
    this.router.navigate(['cms/dashboard']);
  }

  public onEditSiteBillingAddress = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSiteBillingAddress(
      this.site._id
    );
    this.dialogIsOpen = false;
    if (editedSite) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public onEditSiteCreditCard = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSiteCreditCard(this.site._id);
    this.dialogIsOpen = false;
    if (editedSite) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public onEditUserName = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedUser = await this.userService.editUserName(this.user._id);
    this.dialogIsOpen = false;
    if (editedUser) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  public validBillingAddress(): boolean {
    if (this.site && this.site.billing && this.site.billing.billingAddress && this.site.billing.billingAddress.address) {
      return true;
    }
    return false;
  }

  public validCreditCardData(): boolean {
    if (this.site && this.site.billing && this.site.billing.creditCard && this.site.billing.creditCard.creditCardNumber) {
      return true;
    }
    return false;
  }
}
