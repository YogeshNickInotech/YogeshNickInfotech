import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  Inject
} from '@angular/core';
import { NavigationState } from '../../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../../services/navigation/navigation.service';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig
} from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from '../../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../../services/notification/_models/notification.model';
import { MdcIconRegistry } from '@angular-mdc/web';
import { SiteService } from 'src/app/services/site/site.service';
import { TimerUtil } from 'src/app/util/timer/timer.util';
import { UserService } from 'src/app/services/user/user.service';
import { Site } from 'src/app/models/site/site.model';
import { Asset } from 'src/app/models/asset/asset.model';
import { AssetService } from 'src/app/services/asset/asset.service';
import { THEMES } from 'src/app/constants/themes.const';
import { SiteContact } from 'src/app/models/site/_submodels/site-contact.model';
import { BACKGROUND_IMAGES, BACKGROUND_IMAGES3, BACKGROUND_IMAGES2 } from 'src/app/constants/background-images.const';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-cms-site-general',
  templateUrl: './cms-site-general.component.html',
  styleUrls: ['./cms-site-general.component.scss']
})
export class CmsSiteGeneralComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public site: Site;
  public serverUrl: string;
  public randomNumber: 1234;
  private navigationState: NavigationState;
  private siteId: string;
  public logoAsset: Asset;
  public backgroundImage1Asset: Asset;
  public backgroundImage2Asset: Asset;
  public backgroundImage3Asset: Asset;
  private themes = THEMES;
  // private backgroundImages = BACKGROUND_IMAGES;
  // private backgroundImages2 = BACKGROUND_IMAGES2;
  // private backgroundImages3 = BACKGROUND_IMAGES3;
  private dialogIsOpen: boolean;
  public stripeConnectionStatus: string;
  public stripeUrl: string;
  // constructor
  constructor(
    @Inject(LeathermanAppConfigInjectionToken) config: ILeathermanAppConfig,
    private router: Router,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private siteService: SiteService,
    private assetService: AssetService,
    private userService: UserService,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Setup';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
    this.serverUrl = config.serverUrl;
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = false;
    this.isLoading = true;
    this.siteId = await this.userService.getUserSiteId();
    await this.loadData();
    this.isLoading = false;
    this.isInitialized = true;
    this.stripeUrl = "https://connect.stripe.com/oauth/authorize?response_type=code&client_id=" + environment.stripeClientId + "&scope=read_write&redirect_uri=https://" + this.site.appUrl + "/cms/setup";
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public getBackgroundImage1Url() {
    let url: string;

    if (this.backgroundImage1Asset) {
      url = `${this.serverUrl}/sites/${this.siteId}/${this.backgroundImage1Asset.fileName}`;
    } else {
      switch (this.site.backgroundImage) {
        case 'BG1':
          url = `${this.serverUrl}/default/background-image-1/background-image-1-1.jpg`;
          break;
        case 'BG2':
          url = `${this.serverUrl}/default/background-image-1/background-image-1-2.jpg`;
          break;
        case 'BG3':
          url = `${this.serverUrl}/default/background-image-1/background-image-1-3.jpg`;
          break;
        case 'BG4':
          url = `${this.serverUrl}/default/background-image-1/background-image-1-4.jpg`;
          break;
        case 'BG5':
          url = `${this.serverUrl}/default/background-image-1/background-image-1-5.jpg`;
          break;
        default:
          url = `${this.serverUrl}/default/background-image-1/background-image-1-1.jpg`;
          break;
      }
    }

    return url;
  }

  public getBackgroundImage2Url() {
    let url: string;

    if (this.backgroundImage2Asset) {
      url = `${this.serverUrl}/sites/${this.siteId}/${this.backgroundImage2Asset.fileName}`;
    } else {
      url = `${this.serverUrl}/default/background-image-2/background-image-2-1.jpg`;
    }

    return url;
  }

  public getBackgroundImage3Url() {
    let url: string;

    if (this.backgroundImage3Asset) {
      url = `${this.serverUrl}/sites/${this.siteId}/${this.backgroundImage3Asset.fileName}`;
    } else {
      url = `${this.serverUrl}/default/background-image-3/background-image-3-1.jpg`;
    }

    return url;
  }

  public getLogoUrl() {
    const url = `${this.serverUrl}/sites/${this.siteId}/${this.logoAsset.fileName}`;

    return url;
  }

  public getThemeLabel(themeValue: string): string {
    const matchingTheme = this.themes.find(t => t.value === themeValue);
    if (!matchingTheme) {
      return 'Default';
    }
    return matchingTheme.label;
  }

  public onBackLinkClicked() {
    this.router.navigate(['cms/dashboard']);
  }

  public onEditBackgroundImage = async (event: any, token: string, position: string) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const result = await this.siteService.uploadBackgroundImage(this.siteId, token, position);
    this.dialogIsOpen = false;
    if (result === true) {
      TimerUtil.delay(2500);
      this.loadData();
    }
  }

  public disconnectStripe = async (event: any) => {
    const updatedSite = await this.siteService.disconnectStripeAccount(this.siteId, this.site.connectedAccountId);
    if (updatedSite) {
      await this.loadData();
    }
  }

  public onEditChatraSettings = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editChatraSettings(
      this.site._id
    );
    this.dialogIsOpen = false;
    if (editedSite) {
      await this.loadData();
    }
  }

  public onEditFirstPromoterSettings = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editFirstPromoterSettings(
      this.site._id
    );
    this.dialogIsOpen = false;
    if (editedSite) {
      await this.loadData();
    }
  }

  public onEditGoogleAnalyticsSettings = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editGoogleAnalyticsSettings(
      this.site._id
    );
    this.dialogIsOpen = false;
    if (editedSite) {
      await this.loadData();
    }
  }

  public onEditSiteContact = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSiteContact(this.siteId);
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditSiteMailingAddress = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSiteMailingAddress(this.siteId);
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditSitePricing = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSitePricing(this.siteId);
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditSiteProperties = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSite(this.siteId);
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditSiteLogo = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const result = await this.siteService.uploadSiteLogo(this.siteId);
    this.dialogIsOpen = false;
    if (result === true) {
      TimerUtil.delay(2500);
      this.loadData();
    }
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  public toYesNo(value: boolean): string {
    return value === true ? 'Yes' : 'No';
  }

  private async loadData() {
    this.site = await this.siteService.getSite(this.siteId);
    console.log('this.siteId',this.siteId);
    if (!this.site.theme) {
      this.site.theme = 'Default';
    }
    if (!this.site.contact) {
      this.site.contact = new SiteContact();
    }
    if (!this.site.firstDnsHost) {
      this.site.firstDnsHost = '@';
    }
    if (!this.site.secondDnsHost) {
      this.site.secondDnsHost = 'app';
    }
    this.logoAsset = await this.assetService.getAssetByToken(
      this.siteId,
      'logo'
    );
    this.backgroundImage1Asset = await this.assetService.getAssetByToken(
      this.siteId,
      'background-image-1'
    );
    this.backgroundImage2Asset = await this.assetService.getAssetByToken(
      this.siteId,
      'background-image-2'
    );
    this.backgroundImage3Asset = await this.assetService.getAssetByToken(
      this.siteId,
      'background-image-3'
    );
    if (this.site.connectedAccountId) {
      this.stripeConnectionStatus = 'Connected';
    } else {
      this.stripeConnectionStatus = 'Not Connected';
    }
    const parsedUrl = this.router.parseUrl(this.router.url);
    const stripeAuthorizationCode = parsedUrl.queryParams.code;
    if (stripeAuthorizationCode) {
      const response = await this.getTokenAndSave(stripeAuthorizationCode, this.siteId);
      if (response) {
        this.site = await this.siteService.getSite(this.siteId);
        this.stripeConnectionStatus = 'Connected';
        this.router.navigate(['cms/setup']);
      }
    }
  }

  public async getTokenAndSave(stripeAuthorizationCode: string, siteId: string): Promise<boolean> {
    const siteResolvedWithStripe = await this.siteService.resolveStripeAccount(siteId, stripeAuthorizationCode);
    if (siteResolvedWithStripe) {
      return true;
    } else {
      return false;
    }
  }
}
