import { Component, OnInit, Inject, AfterViewInit } from '@angular/core';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig
} from 'leatherman';
import { Customer } from '../../../../../models/customer/customer.model';
import { NavigationState } from '../../../../../services/navigation/_models/navigation-state.model';
import { WebSocketNotification } from '../../../../../services/notification/_models/notification.model';
import { NavigationService } from 'src/app/services/navigation/navigation.service';
import { DOCUMENT } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService } from 'src/app/services/notification/notification.service';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { UserService } from 'src/app/services/user/user.service';
import { CmsCustomerPagerService } from 'src/app/services/pager/cms-customer-pager.service';

@Component({
  selector: 'app-cms-customer',
  templateUrl: './cms-customer.component.html',
  styleUrls: ['./cms-customer.component.scss']
})
export class CmsCustomerComponent extends BaseComponent
  implements OnInit, AfterViewInit {
  private navigationState: NavigationState;
  public customerId: string;
  public customer: Customer;
  public userRole: string;
  public hideNextButton = true;
  public hidePreviousButton = true;
  private siteId: string;
  private dialogIsOpen: boolean;

  // constructor
  constructor(
    private userService: UserService,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private customerService: CustomerService,
    @Inject(LeathermanAppConfigInjectionToken)
    public config: ILeathermanAppConfig,
    private notificationService: NotificationService,
    private router: Router,
    @Inject(DOCUMENT) private document: Document,
    private customerPagerService: CmsCustomerPagerService
  ) {
    super();

    this.navigationState = new NavigationState();
    this.navigationState.title = 'Customer';
    this.navigationService.updateNavigationState(this.navigationState);
  }

  // ngOnInit
  public async ngOnInit() {
    this.userRole = this.userService._getPrimaryUserRole();
    this.activatedRoute.params.subscribe(async params => {
      this.customerId = params.customerId;
      await this.loadData(this.customerId);
      this.isInitialized = true;
    });
    this.hideNextButton = this.customerPagerService.hideNext();
    this.hidePreviousButton = this.customerPagerService.hidePrevious();
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public getFullAddress(customer: Customer): string {
    if (!customer) {
      return '';
    }
    const fullAddress =
      customer.address.address +
      ', ' +
      customer.address.city +
      ', ' +
      customer.address.state +
      ' ' +
      customer.address.zip;
    return fullAddress;
  }

  public onBackLinkClicked() {
    this.customerPagerService.goBack();
  }

  public onDelete = async () => {
    // if ((await this.customerService.deleteCustomer(this.customerId)) === false) {
    //   return;
    // }
    // await TimerUtil.delay(1000);
    // this.customerPagerService.goBack();
  }

  public onEdit = async () => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;

    const editedCustomer = await this.customerService.editCustomer(
      this.customerId
    );
    this.dialogIsOpen = false;
    if (editedCustomer == null) {
      return;
    }
    await this.loadData(this.customerId);
  }

  private async loadData(customerId: string) {
    this.customer = await this.customerService.getCustomer(customerId);
   console.log("customerDetail",JSON.stringify(this.customer))
    this.siteId = this.customer.siteId;
    this.customerPagerService.setSiteId(this.siteId);
    this.isLoading = false;
  }

  public onNextCustomer = async () => {
    const nextCustomerId = await this.customerPagerService.getNextCustomerId();
    if (!nextCustomerId) {
      this.hideNextButton = true;
      return;
    }
    this.router.navigate(['cms/customers', nextCustomerId]);
    this.hideNextButton = this.customerPagerService.hideNext();
    this.hidePreviousButton = this.customerPagerService.hidePrevious();
  }

  public onNotification = async (notification: WebSocketNotification) => {
    // if (!notification.data || notification.data.customerId !== this.customerId) {
    //   return;
    // }
    // switch (notification.type) {
    //   case 'customer-file-import-complete':
    //     await TimerUtil.delay(3000);
    //     this.loadData(this.customerId);
    //     break;
    //   case 'customer-file-import-progress':
    //     this.customer.status = notification.message;
    //     const file = Customer.getFile(this.customer, notification.data.fileId);
    //     if (file) {
    //       file.status = notification.message;
    //     }
    //     break;
    //   case 'customer-api-dataset-import-complete':
    //     await TimerUtil.delay(3000);
    //     this.loadData(this.customerId);
    //     break;
    //   case 'customer-api-dataset-import-progress':
    //     this.customer.status = notification.message;
    //     const apiDataset = Customer.getApiDataset(this.customer, notification.data.apiDatasetId);
    //     if (apiDataset) {
    //       apiDataset.status = notification.message;
    //     }
    //    break;
    // }
  }

  public onPreviousCustomer = async () => {
    const previousCustomerId = await this.customerPagerService.getPreviousCustomerId();
    if (!previousCustomerId) {
      return;
    }
    this.router.navigate(['cms/customers', previousCustomerId]);
    this.hideNextButton = this.customerPagerService.hideNext();
    this.hidePreviousButton = this.customerPagerService.hidePrevious();
  }

  public toYesNo(value: boolean): string {
    return value === true ? 'Yes' : 'No';
  }
}
