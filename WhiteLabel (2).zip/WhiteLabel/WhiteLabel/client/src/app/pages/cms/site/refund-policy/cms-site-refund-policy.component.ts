import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  Inject
} from '@angular/core';
import { NavigationState } from '../../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../../services/navigation/navigation.service';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig,
  GetOptions
} from 'leatherman';
import { NotificationService } from '../../../../services/notification/notification.service';
import { ListState } from '../../../../models/list-state/list-state.model';
import { WebSocketNotification } from '../../../../services/notification/_models/notification.model';
import { MdcIconRegistry } from '@angular-mdc/web';
import { SiteService } from 'src/app/services/site/site.service';
import { TimerUtil } from 'src/app/util/timer/timer.util';
import { UserService } from 'src/app/services/user/user.service';
import { SiteHeadings } from 'src/app/models/site/_submodels/site-headings.model';
import { Router,ActivatedRoute } from '@angular/router';
import { PolicySection } from 'src/app/models/policy-section/policy-section.model';
import { PolicySectionService } from 'src/app/services/policy-section/policy-section.service';

@Component({
  selector: 'app-cms-site-refund-policy',
  templateUrl: './cms-site-refund-policy.component.html',
  styleUrls: ['./cms-site-refund-policy.component.scss']
})
export class CmsSiteRefundPolicyComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public heading: string;
  public policySections: PolicySection[];
  public serverUrl: string;
  public pageState: ListState = new ListState();
  private navigationState: NavigationState;
  private siteId: string;
  private dialogIsOpen: boolean;
  // constructor
  constructor(
    @Inject(LeathermanAppConfigInjectionToken) config: ILeathermanAppConfig,
    private router: Router,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private siteService: SiteService,
    private activatedRoute: ActivatedRoute,
    private userService: UserService,
    private policySectionService: PolicySectionService,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Setup';
    this.navigationState.selectedTabIndex = 1;
    this.navigationState.addTab(
      'Terms of Service',
      '/cms/policies/terms-of-service',
      'gavel'
    );
    this.navigationState.addTab(
      'Privacy Policy',
      '/cms/policies/privacy-policy',
      'lock'
    );
    this.navigationState.addTab(
      'Refund Policy',
      '/cms/policies/refund-policy',
      'money_off'
    );
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
    this.serverUrl = config.serverUrl;
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = false;
    this.isLoading = true;
    this.siteId = await this.userService.getUserSiteId();
    this.activatedRoute.queryParams.subscribe(async params => {
      await this.initializePageState(params);
      await this.loadData();
      this.isLoading = false;
      this.isInitialized = true;
    });
  
  }

  public getContentLabel(index: number): string {
    if (index === 0) {
      return 'Content';
    }
    return '';
  }

  public getSectionLabel(index: number): string {
    const sectionNumber = index + 1;
    return 'Section ' + sectionNumber;
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public onBackLinkClicked() {
    this.router.navigate(['cms/dashboard']);
  }

  // onDeletePolicySection
  public onDeletePolicySection = async (event: any, id: string) => {
    event.stopPropagation();
    if ((await this.policySectionService.deletePolicySection(id)) === false) {
      return;
    }
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  // onEditRefundPolicyHeading
  public onEditHeading = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedHeading = await this.siteService.editSiteHeading(this.siteId, 'refund-policy');
    this.dialogIsOpen = false;
    if (editedHeading) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onEditPolicySection
  public onEditPolicySection = async (event: any, id: string) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedPolicySection = await this.policySectionService.editPolicySection(id);
    this.dialogIsOpen = false;
    if (editedPolicySection) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public async onNewPolicySection() {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    const newPolicySection = await this.policySectionService.newPolicySection(this.siteId, 'refund-policy');
    this.dialogIsOpen = false;
    if (newPolicySection) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  private async loadData() {
    const site = await this.siteService.getSite(this.siteId);
    if (!site.headings) {
      site.headings = new SiteHeadings();
    }
    this.heading = site.headings.refundPolicy;
    const options = new GetOptions(this.pageState.currentPage, this.pageState.pageSize);
    options.setSort('index', true);
    
    this.policySections = await this.policySectionService.getPolicySections(options, this.siteId, 'refund-policy');
    this.pageState.rowCount = await this.policySectionService.getPolicySectionsCount(this.siteId, 'refund-policy');
    this.pageState.pageCount = GetOptions.calculatePageCount(this.pageState.rowCount, this.pageState.pageSize);
  }


   // paging start
  private updateUrl() {
    const queryParams: any = {};
    if (this.pageState.query) {
      queryParams.q = this.encodeURIComponent(this.pageState.query);
    }
    queryParams.p = this.pageState.currentPage;
    this.router.navigate(['/cms/policies/refund-policy'], {
      queryParams
    });
  }

  // initializePageState
private async initializePageState(queryParams: any) {
  this.pageState.query = this.decodeURIComponent(queryParams.q);

  if (queryParams.p) {
    const currentPage = parseInt(queryParams.p, 5);
    this.pageState.currentPage = currentPage > 0 ? currentPage : 1;
  } else {
    this.pageState.currentPage = 1;
  }

  this.pageState.pageSize = 5;
}

// onPageChanged
public async onPageChanged(pageNumber: number) {
  this.pageState.currentPage = pageNumber;
  this.updateUrl();
  await this.loadData();
  window.scrollTo(0, 0);
}
}
