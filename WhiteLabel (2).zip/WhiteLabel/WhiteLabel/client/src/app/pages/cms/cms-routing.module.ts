import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CmsDashboardComponent } from './dashboard/cms-dashboard.component';
import { CmsOrdersComponent } from './orders/cms-orders.component';
import { CmsOrderComponent } from './orders/_pages/mdc-order-component/cms-order.component';
import { CmsCustomersComponent } from './customers/cms-customers.component';
import { CmsCustomerComponent } from './customers/_pages/cms-customer-component/cms-customer.component';
import { CmsOrderReportComponent } from './reports/order-report/cms-order-report.component';
import { CmsCustomerReportComponent } from './reports/customer-report/cms-customer-report.component';
import { CmsSiteGeneralComponent } from './site/general/cms-site-general.component';
import { CmsSiteFaqComponent } from './site/faq/cms-site-faq.component';
import { CmsAccountGeneralComponent } from './account/general/cms-account-general.component';
import { CmsAccountBillingComponent } from './account/billing/cms-account-billing.component';
import { CmsAccountPaymentsComponent } from './account/payments/cms-account-payments.component';
import { CmsSitePrivacyPolicyComponent } from './site/privacy-policy/cms-site-privacy-policy.component';
import { CmsSiteTermsOfServiceComponent } from './site/terms-of-service/cms-site-terms-of-service.component';
import { CmsSiteRefundPolicyComponent } from './site/refund-policy/cms-site-refund-policy.component';
import { CmsSettingsComponent } from './settings/cms-settings.component';
import { CmsUsersComponent } from './users/cms-users.component';

const routes: Routes = [
  {
    path: 'dashboard',
    component: CmsDashboardComponent,
    data: { title: 'Dashboard', breadcrumb: 'Dashboard' }
  },
  {
    path: 'orders',
    component: CmsOrdersComponent,
    data: { title: 'Orders', breadcrumb: 'Orders' }
  },
  {
    path: 'orders/:orderId',
    component: CmsOrderComponent,
    data: { title: 'Order', breadcrumb: 'Order' }
  },
  {
    path: 'customers',
    component: CmsCustomersComponent,
    data: { title: 'Customers', breadcrumb: 'Customers' }
  },
  {
    path: 'customers/:customerId',
    component: CmsCustomerComponent,
    data: { title: 'Customer', breadcrumb: 'Customer' }
  },
  {
    path: 'reports/order-report',
    component: CmsOrderReportComponent,
    data: { title: 'Order Report', breadcrumb: 'Order Report' }
  },
  {
    path: 'reports/customer-report',
    component: CmsCustomerReportComponent,
    data: { title: 'Customer Report', breadcrumb: 'Customer Report' }
  },
  {
    path: 'setup',
    component: CmsSiteGeneralComponent,
    data: { title: 'Setup', breadcrumb: 'Setup' }
  },
  {
    path: 'policies/terms-of-service',
    component: CmsSiteTermsOfServiceComponent,
    data: { title: 'Policies', breadcrumb: 'Policies' }
  },
  {
    path: 'policies/privacy-policy',
    component: CmsSitePrivacyPolicyComponent,
    data: { title: 'Policies', breadcrumb: 'Policies' }
  },
  {
    path: 'faq',
    component: CmsSiteFaqComponent,
    data: { title: 'Setup FAQ', breadcrumb: 'Setup FAQ' }
  },
  {
    path: 'policies/refund-policy',
    component: CmsSiteRefundPolicyComponent,
    data: { title: 'Policies', breadcrumb: 'Policies' }
  },
  {
    path: 'users',
    component: CmsUsersComponent,
    data: { title: 'Users', breadcrumb: 'Users' }
  },
  {
    path: 'account',
    component: CmsAccountGeneralComponent,
    data: { title: 'Account', breadcrumb: 'Account' }
  },
  {
    path: 'account/billing',
    component: CmsAccountBillingComponent,
    data: { title: 'Account', breadcrumb: 'Account' }
  },
  {
    path: 'account/payments',
    component: CmsAccountPaymentsComponent,
    data: { title: 'Account', breadcrumb: 'Account' }
  },
  {
    path: 'settings',
    component: CmsSettingsComponent,
    data: { title: 'Settings', breadcrumb: 'Settings' }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CmsRoutingModule { }
