import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { NavigationState } from '../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../services/navigation/navigation.service';
import { BaseComponent } from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from '../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../services/notification/_models/notification.model';
import { MdcIconRegistry } from '@angular-mdc/web';

@Component({
  selector: 'app-cms-dashboard',
  templateUrl: './cms-dashboard.component.html',
  styleUrls: ['./cms-dashboard.component.scss']
})
export class CmsDashboardComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  private navigationState: NavigationState;

  // constructor
  constructor(
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private router: Router,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Dashboard';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = true;
    this.isLoading = false;
    this.activatedRoute.queryParams.subscribe(async params => {
      // this.isLoading = true;
      // await this.initializePageState(params);
      // await this.loadData();
      // this.isLoading = false;
      // this.isInitialized = true;
    });
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  public onAccount() {
    this.router.navigate(['cms/account']);
  }

  public onCustomers() {
    this.router.navigate(['cms/customers']);
  }

  public onFaq() {
    this.router.navigate(['cms/faq']);
  }

  public onOrders() {
    this.router.navigate(['cms/orders']);
  }

  public onPolicies() {
    this.router.navigate(['cms/policies/terms-of-service']);
  }

  public onReports() {
    this.router.navigate(['cms/reports/order-report']);
  }

  public onSettings() {
    this.router.navigate(['cms/settings']);
  }

  public onSetup() {
    this.router.navigate(['cms/setup']);
  }

  public onUsers() {
    this.router.navigate(['cms/users']);
  }
}
