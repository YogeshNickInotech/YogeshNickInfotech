import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { NavigationState } from '../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../services/navigation/navigation.service';
import { BaseComponent } from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from '../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../services/notification/_models/notification.model';
import { MdcIconRegistry } from '@angular-mdc/web';
import { UserSettingsService } from 'src/app/services/user-settings/user-settings.service';
import { InfoDialogService } from 'src/app/dialogs/info/info-dialog.service';
import { SiteService } from 'src/app/services/site/site.service';
import { Site } from 'src/app/models/site/site.model';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-cms-settings',
  templateUrl: './cms-settings.component.html',
  styleUrls: ['./cms-settings.component.scss']
})
export class CmsSettingsComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public hideAll: boolean;
  public showTip: boolean;
  private navigationState: NavigationState;
  public site: Site;
  public siteId: string;
  private dialogIsOpen: boolean; 
  // constructor
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private userSettingsService: UserSettingsService,
    iconRegistry: MdcIconRegistry,
    private infoDialogService: InfoDialogService,
    private siteService: SiteService,
    private userService: UserService
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Settings';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    await this.loadData();
    this.isInitialized = true;
    this.isLoading = false;
    this.siteId = await this.userService.getUserSiteId();
    this.site = await this.siteService.getSite(this.siteId);
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public onBackLinkClicked() {
    this.router.navigate(['cms/dashboard']);
  }

  public async onChangeHideAllTips($event) {
    await this.userSettingsService.hideTips($event.checked);
    await this.loadData();
  }

  public onEditSettingGroup1() { }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  public async onRestoreAllTips() {
    const result = await this.userSettingsService.restoreAllTips();;
    if (result === true) {
      await this.infoDialogService.openInfoDialog('Restore All Tips', 'Your tips have been reset.');
    } else {
      await this.infoDialogService.openInfoDialog('Restore All Tips', 'There was a problem resetting your tips.');
    }
    this.showTip = true;
    await this.loadData();
  }

  public onEditChartioSettings = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editChatraSettings(
      this.site._id
    );
    this.dialogIsOpen = false;
    if (editedSite) { 
      await this.loadData();
    }
  }

  private async loadData() {
    const userSettings = await this.userSettingsService.getUserSettings();
    this.hideAll = userSettings.tips.hideAll;
    if (userSettings.tips.hideAll === true || userSettings.tips.hideSettings === true) {
      this.showTip = false;
    } else {
      this.showTip = true;
    }
  }
}
