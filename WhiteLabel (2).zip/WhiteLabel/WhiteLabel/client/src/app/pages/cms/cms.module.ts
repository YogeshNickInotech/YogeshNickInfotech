import { NgModule } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { LeathermanUikitMdcModule } from 'src/app/mdc.module';
import { AngularModule } from 'src/app/angular.module';
import { SharedModule } from 'src/app/shared.module';
import { CommonModule } from '@angular/common';
import { CmsDashboardComponent } from './dashboard/cms-dashboard.component';
import { CmsOrdersComponent } from './orders/cms-orders.component';
import { CmsCustomersComponent } from './customers/cms-customers.component';
import { CmsAccountGeneralComponent } from './account/general/cms-account-general.component';
import { CmsSiteGeneralComponent } from './site/general/cms-site-general.component';
import { CmsSiteFaqComponent } from './site/faq/cms-site-faq.component';
import { CmsRoutingModule } from './cms-routing.module';
import { CmsOrderComponent } from './orders/_pages/mdc-order-component/cms-order.component';
import { CmsCustomerReportComponent } from './reports/customer-report/cms-customer-report.component';
import { CmsOrderReportComponent } from './reports/order-report/cms-order-report.component';
import { CmsCustomerComponent } from './customers/_pages/cms-customer-component/cms-customer.component';
import { CmsAccountBillingComponent } from './account/billing/cms-account-billing.component';
import { CmsAccountPaymentsComponent } from './account/payments/cms-account-payments.component';
import { CmsSitePrivacyPolicyComponent } from './site/privacy-policy/cms-site-privacy-policy.component';
import { CmsSiteTermsOfServiceComponent } from './site/terms-of-service/cms-site-terms-of-service.component';
import { CmsSiteRefundPolicyComponent } from './site/refund-policy/cms-site-refund-policy.component';
import { CmsSettingsComponent } from './settings/cms-settings.component';
import { CmsUsersComponent } from './users/cms-users.component';
import { MatSortModule } from '@angular/material/sort';

@NgModule({
  imports: [
    CommonModule,
    AngularModule,
    SharedModule,
    // RouterModule,
    // AngularFontAwesomeModule,
    // BrowserAnimationsModule,
    MatTableModule,
    MatSortModule,
    MatProgressSpinnerModule,
    LeathermanUikitMdcModule,
    // LeathermanModule.forRoot(
    //   appConfig,
    //   MockErrorDialogService,
    //   MockConfirmDialogService
    // ),
    CmsRoutingModule,
  ],
  declarations: [
    CmsDashboardComponent,
    CmsOrdersComponent,
    CmsCustomersComponent,
    CmsAccountGeneralComponent,
    CmsAccountBillingComponent,
    CmsAccountPaymentsComponent,
    CmsSettingsComponent,
    CmsSiteGeneralComponent,
    CmsSitePrivacyPolicyComponent,
    CmsSiteFaqComponent,
    CmsOrderComponent,
    CmsCustomerReportComponent,
    CmsOrderReportComponent,
    CmsCustomerComponent,
    CmsSiteTermsOfServiceComponent,
    CmsSiteRefundPolicyComponent,
    CmsUsersComponent
  ]
})
export class CmsModule { }
