import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { UserService } from "../../../services/user/user.service";

@Component({
  selector: "app-verify-email",
  templateUrl: "./verify-email.component.html",
  styleUrls: ["./verify-email.component.scss"]
})
export class VerifyEmailComponent implements OnInit {
  private token: string;
  public isTokenVerified: boolean;

  // constructor
  constructor(
    private router: Router,
    private userService: UserService,
    private activatedRoute: ActivatedRoute
  ) {}

  // ngOnInit
  public async ngOnInit() {
    this.userService._logoutUser();

    this.token = this.activatedRoute.snapshot.queryParamMap.get("token"); 
    const response = await this.userService.validateVerifyEmailToken(
      this.token
    ); 
    this.isTokenVerified =  response && response.validToken;
  }

  public async redirectToLogin() {
    this.router.navigate(['/']);
  }
}
