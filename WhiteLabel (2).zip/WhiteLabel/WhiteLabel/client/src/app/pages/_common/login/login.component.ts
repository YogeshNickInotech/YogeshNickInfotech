import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl,ValidatorFn } from '@angular/forms';
import { Router } from '@angular/router';
import {
  ErrorDialogService,
  LoginRequest,
  AuthenticationService
} from 'leatherman';
import { UserService } from '../../../services/user/user.service';
import { InfoDialogService } from '../../../dialogs/info/info-dialog.service';
import { ChatraUtil } from 'src/app/util/chatra/chatra.util';
import { FirstPromoterUtil } from 'src/app/util/first-promoter/first-promoter.util';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { UsernameValidator } from './username.validator';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class Login2Component implements OnInit {
  public loginForm: FormGroup;
  private dialogIsOpen: boolean;

  // constructor
  constructor(
    private infoDialogService: InfoDialogService,
    private formBuilder: FormBuilder,
    private router: Router,
    private userService: UserService,
    private authenticationService: AuthenticationService,
    private errorDialogService: ErrorDialogService,
    // private fb: FormBuilder
  ) { }

  // ngOnInit
  public ngOnInit() {
    this.userService._logoutUser();
    this.initForm();
   
    //FirstPromoterUtil.initialize(true,'','');
    
  }

  public async resetPassword() {
    this.router.navigate(['/request-password-reset']);
  }

  public async submit() {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    this.validateForm();
    if (this.loginForm.invalid) {
      this.dialogIsOpen = false;
      return;
    }
   
    const email = this.loginForm.get('email').value;
    const password = this.loginForm.get('password').value;
    const loginRequest = new LoginRequest(email, password);
    const loginResult = await this.userService.loginUser(loginRequest);
    if (!loginResult) {
      this.infoDialogService.openInfoDialog(
        'Login Error',
        'Login failed. Invalid username or password.'
      );
      this.dialogIsOpen = false;
      return;
    }
    const roles = await this.authenticationService.getUserRoles();
    this.dialogIsOpen = false;
    if (roles.includes('admin')) {
      this.router.navigate(['/admin/dashboard']);
      return;
    } else if (roles.includes('site-owner')) {
      this.router.navigate(['/cms/dashboard']);
      return;
    }

    const parsedUrl = this.router.parseUrl(this.router.url);
    sessionStorage.setItem('fp_coupon', parsedUrl.queryParams.coupon);
    this.router.navigate(['/app/dashboard']);
  }

  // initForm
  private initForm() {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
    // whiteSpace:[" ",[Validators.required,UsernameValidator.cannotContainSpace,]]
    });
  }

  // // private validateTrim = (control: FormControl) => {
  // //   try {
  // //     if (control.value.startsWith( '   ' )) {
  // //       return {
  // //         noWhiteSpace: {
  // //           invalid: true
  // //         }
  // //       };
      
  // //     }
     
      
     
  // //   } catch (error) {
      
  // //   }
  // }
  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        control.updateValueAndValidity();
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  private validateForm(): boolean {
    this.validateAllFormFields(this.loginForm);
    this.loginForm.markAsDirty();

    return true;
  }

  // loginForm1 = new FormGroup({
  //   username: new FormControl('', [Validators.required, Validators.minLength(3), UsernameValidator.cannotContainSpace]),
  //   password: new FormControl('', Validators.required)
  // });
   
  get f(){
    return this.loginForm.controls;
  }
    
  

 
  control = new FormControl('', );

  
}
