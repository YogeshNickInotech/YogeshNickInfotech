import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../../services/user/user.service';
import { MdcSnackbar } from '@angular-mdc/web';
import { TimerUtil } from 'src/app/util/timer/timer.util';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPassword2Component implements OnInit {
  public resetPasswordForm: FormGroup;
  private token: string;
  private userId: string;

  // constructor
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private userService: UserService,
    private snackbar: MdcSnackbar,
    private activatedRoute: ActivatedRoute
  ) { }

  // ngOnInit
  public async ngOnInit() {
    this.initForm();
    this.userService._logoutUser();

    this.token = this.activatedRoute.snapshot.queryParamMap.get('token');
    console.log(this.token);
    const response = await this.userService.validatePasswordResetToken(this.token);
    console.log(response);
    if (response.validToken === true) {
      this.userId = response.userId;
    } else {
      this.router.navigate(['/']);
    }
  }

  public async submit() {
    this.validateForm();
    if (this.resetPasswordForm.invalid) {
      return;
    }

    const newPassword = this.resetPasswordForm.value.password;
    const result = await this.userService.resetPassword(this.token, this.userId, newPassword);
    console.log(result);
    await TimerUtil.delay(1000);
    if (result === true) {
      this.snackbar.open('Your password was successfully reset', ' ', {
        dismiss: true
      });
      await TimerUtil.delay(3000);
      this.router.navigate(['/']);
    } else {
      this.snackbar.open('There was a problem resetting your password', ' ', {
        dismiss: true
      });
    }
  }

  // initForm
  private initForm() {
    this.resetPasswordForm = this.formBuilder.group({
      password: ['', [Validators.required, this.validatePassword]],
      passwordVerify: ['', [Validators.required, this.validatePasswordMatch]],
    });
  }

  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        control.updateValueAndValidity();
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  private validateForm(): boolean {
    this.validateAllFormFields(this.resetPasswordForm);
    this.resetPasswordForm.markAsDirty();

    return true;
  }

  private validatePasswordMatch = (control: FormControl) => {
    try {
      const verifyNewPassword = control.value;
      const newPassword = this.resetPasswordForm.get('password').value;

      if (verifyNewPassword !== newPassword) {
        return {
          passwordMatch: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidPassword: {
          invalid: true
        }
      };
    }
  }

  private validatePassword = (control: FormControl) => {
    try {
      const value = control.value;

      if (/(?=.*[a-z])/.test(value) === false) {
        return {
          lowerCase: {
            invalid: true
          }
        };
      }
      if (/(?=.*[A-Z])/.test(value) === false) {
        return {
          upperCase: {
            invalid: true
          }
        };
      }
      if (/(?=.*[0-9])/.test(value) === false) {
        return {
          number: {
            invalid: true
          }
        };
      }
      // if (/(?=.[!@$*|_\^])/.test(value) === false) {
      //   return {
      //     specialCharacter: {
      //       invalid: true
      //     }
      //   };
      // }
      if (value.length < 8) {
        return {
          minLength: {
            invalid: true
          }
        };
      }
      if (value.length > 20) {
        return {
          maxLength: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidPassword: {
          invalid: true
        }
      };
    }
  }
}
