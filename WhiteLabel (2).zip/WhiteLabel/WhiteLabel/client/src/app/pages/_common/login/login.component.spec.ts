import {async, ComponentFixture , TestBed} from '@angular/core/testing'
import{Login2Component} from './login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {HttpClientModule} from '@angular/common/http';
import {
    MdcTopAppBarModule,
    MdcFabModule,
    MdcIconModule,
    MdcMenuModule,
    MdcDrawerModule,
    MdcListModule,
    MdcTabBarModule,
    MdcElevationModule,
    MdcButtonModule,
    MdcCardModule,
    MdcIconButtonModule,
    MdcCheckboxModule,
    MdcChipsModule,
    MdcRadioModule,
    MdcSliderModule,
    MdcSnackbarModule,
    MdcSwitchModule,
    MdcFormFieldModule,
    MdcTextFieldModule,
    MdcTypographyModule,
    MdcDialogModule,
    MdcSelectModule,
    MdcLinearProgressModule,
  } from '@angular-mdc/web';
  
// import { UserService } from 'src/app/services/user/user.service';


  
     describe('Login2Component',() =>{
    //  let userService: UserService;
     let component :Login2Component;
     let fixture :ComponentFixture<Login2Component>;
     
     beforeEach(async(()=>{
       TestBed.configureTestingModule({
           declarations:[Login2Component],
           imports:[
               ReactiveFormsModule,
               RouterTestingModule,
               MdcTopAppBarModule,
               MdcFabModule,
               MdcIconModule,
               MdcMenuModule,
               MdcDrawerModule,
               MdcListModule,
               MdcTabBarModule,
               MdcElevationModule,
               MdcButtonModule,
               MdcCardModule,
               MdcIconButtonModule,
               MdcCheckboxModule,
               MdcChipsModule,
               MdcRadioModule,
               MdcSliderModule,
               MdcSnackbarModule,
               MdcSwitchModule,
               MdcFormFieldModule,
               MdcTextFieldModule,
               MdcTypographyModule,
               MdcDialogModule,
               MdcSelectModule,
               MdcLinearProgressModule,
               BrowserModule,
               BrowserAnimationsModule,
               HttpClientTestingModule,HttpClientModule],

              

       })
       .compileComponents();
       
   }));


   beforeEach(()=>{
       fixture=TestBed.createComponent(Login2Component);
       component=fixture.componentInstance;
       fixture.detectChanges();
   });
   it('should create',()=>{
       expect(component).toBeTruthy();
   });

   it('should contain a default value for the loginForm',()=>{
       expect(component.loginForm.value).toEqual({email:'', password:''});
   });

})