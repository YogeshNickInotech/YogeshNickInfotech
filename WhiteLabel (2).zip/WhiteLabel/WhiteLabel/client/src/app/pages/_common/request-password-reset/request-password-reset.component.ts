import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../../services/user/user.service';
import { MdcSnackbar } from '@angular-mdc/web';
import { InfoDialogService } from 'src/app/dialogs/info/info-dialog.service';

@Component({
  selector: 'app-request-password-reset',
  templateUrl: './request-password-reset.component.html',
  styleUrls: ['./request-password-reset.component.scss']
})
export class RequestPasswordReset2Component implements OnInit {
  public requestPasswordResetForm: FormGroup;

  // constructor
  constructor(
    private infoDialogService: InfoDialogService,
    private formBuilder: FormBuilder,
    private router: Router,
    private userService: UserService,
    private snackbar: MdcSnackbar
  ) { }

  // ngOnInit
  public ngOnInit() {
    this.userService._logoutUser();
    this.initForm();
  }

  public async onLogin() {
    this.router.navigate(['/']);
  }

  public async submit() {
    if (this.requestPasswordResetForm.invalid) {
      return;
    }

    const email: string = this.requestPasswordResetForm.get('email').value;
    const result = await this.userService.requestPasswordReset(email);
    if (result !== true) {
      await this.infoDialogService.openInfoDialog('Account Not Found',
        'We were unable to find an account that matched the e-mail address you entered. Please check your e-mail address and try again.');
      return;
    }

    this.snackbar.open('An email has been sent with further instructions', ' ', {
      dismiss: true
    });
    // this.requestPasswordResetForm.reset();
    const delay = ms => new Promise(res => setTimeout(res, ms));
    await delay(3000);
    this.router.navigate(['/']);
  }

  // initForm
  private initForm() {
    this.requestPasswordResetForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        control.updateValueAndValidity();
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  private validateForm(): boolean {
    this.validateAllFormFields(this.requestPasswordResetForm);
    this.requestPasswordResetForm.markAsDirty();

    return true;
  }
}
