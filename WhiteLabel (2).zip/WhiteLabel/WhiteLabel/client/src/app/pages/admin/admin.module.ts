import { NgModule } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { LeathermanUikitMdcModule } from 'src/app/mdc.module';
import { AngularModule } from 'src/app/angular.module';
import { SharedModule } from 'src/app/shared.module';
import { CommonModule } from '@angular/common';
import { AdminDashboardComponent } from './dashboard/admin-dashboard.component';
import { AdminOrdersComponent } from './orders/admin-orders.component';
import { AdminOrderComponent } from './orders/_pages/admin-order-component/admin-order.component';
import { AdminSitesComponent } from './sites/admin-sites.component';
import { AdminSiteSetupComponent } from './sites/_pages/setup/admin-site-setup.component';
import { AdminSiteOrdersComponent } from './sites/_pages/orders/admin-site-orders.component';
import { AdminSiteOrderComponent } from './sites/_pages/orders/admin-site-order-component/admin-site-order.component';
import { AdminAccountComponent } from './account/admin-account.component';
import { AdminSettingsComponent } from './settings/admin-settings.component';
import { AdminSiteFaqComponent } from './sites/_pages/faq/admin-site-faq.component';
import { AdminUsersComponent } from './admin-users/admin-users.component';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminSitePrivacyPolicyComponent } from './sites/_pages/privacy-policy/admin-site-privacy-policy.component';
import { AdminSiteTermsOfServiceComponent } from './sites/_pages/terms-of-service/admin-site-terms-of-service.component';
import { AdminCustomerReportComponent } from './reports/customer-report/admin-customer-report.component';
import { AdminOrderReportComponent } from './reports/order-report/admin-order-report.component';
import { AdminSitePaymentsComponent } from './sites/_pages/payments/admin-site-payments.component';
import { AdminSiteRefundPolicyComponent } from './sites/_pages/refund-policy/admin-site-refund-policy.component';
import { AdminSiteUsersComponent } from './site-users/admin-site-users.component';
import { AdminCustomersComponent } from './customers/admin-customers.component';
import { AdminCustomerComponent } from './customers/_pages/admin-customer-component/admin-customer.component';
import { MatSortModule } from '@angular/material/sort';
import { AdminSiteReportComponent } from './reports/site-report/admin-site-report.component';

@NgModule({
  imports: [
    CommonModule,
    AngularModule,
    SharedModule,
    // RouterModule,
    // AngularFontAwesomeModule,
    // BrowserAnimationsModule,
    MatTableModule,
    MatSortModule,
    MatProgressSpinnerModule,
    LeathermanUikitMdcModule,
    // LeathermanModule.forRoot(
    //   appConfig,
    //   MockErrorDialogService,
    //   MockConfirmDialogService
    // ),
    AdminRoutingModule,
  ],
  declarations: [
    AdminDashboardComponent,
    AdminOrdersComponent,
    AdminOrderComponent,
    AdminSitesComponent,
    AdminSiteSetupComponent,
    AdminSiteOrdersComponent,
    AdminSiteOrderComponent,
    AdminAccountComponent,
    AdminSettingsComponent,
    AdminSitePrivacyPolicyComponent,
    AdminSiteTermsOfServiceComponent,
    AdminSiteRefundPolicyComponent,
    AdminSiteFaqComponent,
    AdminUsersComponent,
    AdminCustomerReportComponent,
    AdminOrderReportComponent,
    AdminSiteReportComponent,
    AdminSitePaymentsComponent,
    AdminSiteUsersComponent,
    AdminCustomersComponent,
    AdminCustomerComponent
  ]
})
export class AdminModule { }
