import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { NavigationState } from '../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../services/navigation/navigation.service';
import { BaseComponent } from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from '../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../services/notification/_models/notification.model';
import { MdcIconRegistry } from '@angular-mdc/web';

@Component({
  selector: 'app-mdc-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  private navigationState: NavigationState;

  // constructor
  constructor(
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private router: Router,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Dashboard';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = true;
    this.isLoading = false;
    this.activatedRoute.queryParams.subscribe(async params => {
      // this.isLoading = true;
      // await this.initializePageState(params);
      // await this.loadData();
      // this.isLoading = false;
      // this.isInitialized = true;
    });
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public onAccount() {
    this.router.navigate(['admin/account']);
  }

  public onCustomers() {
    this.router.navigate(['admin/customers']);
  }

  public onOrders() {
    this.router.navigate(['admin/orders']);
  }

  public onReports() {
    this.router.navigate(['admin/reports/order-report']);
  }

  public onSettings() {
    this.router.navigate(['admin/settings']);
  }

  public onSites() {
    this.router.navigate(['admin/sites']);
  }

  public onSiteUsers() {
    this.router.navigate(['admin/site-users']);
  }

  public onAdminUsers() {
    this.router.navigate(['admin/admin-users']);
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };
}
