import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  ViewChild
} from '@angular/core';
import { NavigationState } from '../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../services/navigation/navigation.service';
import {
  BaseComponent,
  GetOptions,
  SearchResultFacet,
  SearchResultFacetItem
} from 'leatherman';
import { TimerUtil } from '../../../util/timer/timer.util';
import { UserSettingsService } from '../../../services/user-settings/user-settings.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ListState } from '../../../models/list-state/list-state.model';
import { Sort } from '@angular/material/sort';
import { NotificationService } from '../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../services/notification/_models/notification.model';
import { MdcMenu, MdcIconRegistry } from '@angular-mdc/web';
import { OrderService } from 'src/app/services/order/order.service';
import { AdminOrderPagerService } from 'src/app/services/pager/admin-order-pager.service';
import { SolrOrder } from 'src/app/models/order/solr-order.model';
import { GetOrderOptions } from 'src/app/models/order/get-order-options.model';

@Component({
  selector: 'app-admin-orders',
  templateUrl: './admin-orders.component.html',
  styleUrls: ['./admin-orders.component.scss']
})
export class AdminOrdersComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  private dialogIsOpen: boolean;
  // constructor
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private orderService: OrderService,
    private orderPagerService: AdminOrderPagerService,
    private userSettingsService: UserSettingsService,
    private notificationService: NotificationService,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Orders';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }
  // Public properties
  public orders: SolrOrder[] = [];
  public numFound = 0;
  public facets: SearchResultFacet[] = [];
  public pageState: ListState = new ListState();
  public userRole: string;
  public menuOrderId: string;
  public displayedColumns: string[] = [
    'orderNumber',
    'siteName',
    'customerName',
    'dateCreated',
    'status',
    'requestCount',
    'matchCount',
    'matchPercent',
    'comments',
    'actions'
  ];

  private navigationState: NavigationState;
  @ViewChild('otherMenu', { static: false })
  private otherMenu: MdcMenu;

  // ngOnInit
  public async ngOnInit() {
    // this.userRole = this.userService._getPrimaryUserRole();
    this.isInitialized = false;
    this.activatedRoute.queryParams.subscribe(async params => {
      this.isLoading = true;
      await this.initializePageState(params);
      await this.loadData();
      this.isLoading = false;
      this.isInitialized = true;
    });
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  // onCloseOrder
  public onCloseOrder = async (event: any, id: string) => {
    event.preventDefault();
    const order = await this.orderService.getOrder(id);
    order.status = 'Closed';
    await this.orderService.updateOrder(order);
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  // onDelete
  public onDelete = async (event: any, id: string) => {
    event.stopPropagation();
    if ((await this.orderService.deleteOrder(id)) === false) {
      return;
    }
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  public onBackLinkClicked() {
    this.router.navigate(['admin/dashboard']);
  }

  // onEdit
  public onEdit = async (event: any, id: string) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();

    const editedOrder = await this.orderService.editOrder(id);
    this.dialogIsOpen = false;
    if (editedOrder) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public async onFacetItemClicked(facetItem: SearchResultFacetItem) {
    this.pageState.filter = facetItem.query;
    this.pageState.currentPage = 1;
    this.pageState.sortColumn = '';
    this.updateUrl();
    await this.loadData();
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => {

  }

  // onOtherMenu
  public openOtherMenu = async (event: any, orderId: string) => {
    event.stopPropagation();
    this.menuOrderId = orderId;
    this.otherMenu.fixed = true;
    this.otherMenu.anchorElement = event.target;
    this.otherMenu.open = true;
  }

  // onPageChanged
  public async onPageChanged(pageNumber: number) {
    this.pageState.currentPage = pageNumber;
    this.updateUrl();
    await this.loadData();
    window.scrollTo(0, 0);
  }

  public onRowClick(order: SolrOrder) {
    const currentOrderIndex = this.getOrderIndex(order._id);
    this.orderPagerService.initialize(
      currentOrderIndex,
      this.pageState,
      this.orders
    );
    this.router.navigate([`/admin/orders/${order._id}`]);
  }

  // onSearchTextChanged
  public async onSearchTextChanged(query: any) {
    this.pageState.query = query;
    this.updateUrl();
    await this.loadData();
  }

  // onSortChange
  public async onSortChange(sort: Sort) {
    this.pageState.sortColumn = sort.active;
    this.pageState.sortAscending = sort.direction === 'desc' ? false : true;
    this.updateUrl();
    await this.loadData();
    const userSettings = await this.userSettingsService.getUserSettings();
    userSettings.orders.sortColumn = this.pageState.sortColumn;
    userSettings.orders.sortAscending = this.pageState.sortAscending;
    await this.userSettingsService.updateUserSettings(userSettings);
  }

  // getOptions
  private getOptions(): GetOrderOptions {
    const options = new GetOrderOptions(
      this.pageState.currentPage,
      this.pageState.pageSize
    );
    if (this.pageState.sortColumn) {
      options.setSort(this.pageState.sortColumn, this.pageState.sortAscending);
    }
    options.query = this.encodeURIComponent(this.pageState.query);
    options.filter = this.pageState.filter;
    return options;
  }

  // getOrderIndex
  private getOrderIndex(orderId: string): number {
    const orderIndex = this.orders.findIndex(p => p._id === orderId);
    return orderIndex;
  }

  // initializePageState
  private async initializePageState(queryParams: any) {
    const userSettings = await this.userSettingsService.getUserSettings();
    this.pageState.query = this.decodeURIComponent(queryParams.q);
    this.pageState.filter = queryParams.f;
    if (queryParams.sort) {
      this.pageState.sortColumn = queryParams.sort;
    } else if (userSettings.orders && userSettings.orders.sortColumn) {
      this.pageState.sortColumn = userSettings.orders.sortColumn;
    } else {
      this.pageState.sortColumn = 'relevance';
    }
    if (queryParams.order) {
      this.pageState.sortAscending =
        queryParams.order.toLowerCase() === 'desc' ? false : true;
    } else if (
      userSettings.orders &&
      userSettings.orders.sortAscending !== undefined
    ) {
      this.pageState.sortAscending = userSettings.orders.sortAscending;
    } else if (queryParams.sort === undefined) {
      this.pageState.sortAscending = false;
    } else {
      this.pageState.sortAscending = true;
    }
    if (queryParams.p) {
      const currentPage = parseInt(queryParams.p, 10);
      this.pageState.currentPage = currentPage > 0 ? currentPage : 1;
    } else {
      this.pageState.currentPage = 1;
    }
    this.pageState.pageSize = 25;
  }

  // loadData
  private async loadData() {
    const options = this.getOptions();
    const searchResultsContainer = await this.orderService.getOrders(options);
    this.numFound = searchResultsContainer.meta.numFound;
    this.orders = searchResultsContainer.data;
    this.facets = searchResultsContainer.facets;
    this.pageState.pageCount = GetOptions.calculatePageCount(
      searchResultsContainer.meta.numFound,
      this.pageState.pageSize
    );
    this.pageState.rowCount = searchResultsContainer.meta.numFound;
  }

  // updateUrl
  private updateUrl() {
    const queryParams: any = {};
    if (this.pageState.query) {
      queryParams.q = this.encodeURIComponent(this.pageState.query);
    }
    if (this.pageState.filter) {
      queryParams.f = this.pageState.filter;
    }

    if (!this.pageState.sortColumn) {
      queryParams.sort = 'relevance';
      queryParams.order = 'asc';
    } else if (this.pageState.sortColumn !== 'relevance') {
      queryParams.sort = this.pageState.sortColumn;
      queryParams.order =
        this.pageState.sortAscending === true ? 'asc' : 'desc';
    }

    queryParams.p = this.pageState.currentPage;
    this.router.navigate(['/admin/orders'], {
      queryParams
    });
  }
}
