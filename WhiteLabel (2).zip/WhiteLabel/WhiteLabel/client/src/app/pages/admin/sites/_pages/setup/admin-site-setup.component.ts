import { Component, OnInit, Inject, AfterViewInit } from '@angular/core';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig
} from 'leatherman';
import { Site } from '../../../../../models/site/site.model';
import { NavigationState } from '../../../../../services/navigation/_models/navigation-state.model';
import { WebSocketNotification } from '../../../../../services/notification/_models/notification.model';
import { NavigationService } from 'src/app/services/navigation/navigation.service';
import { DOCUMENT } from '@angular/common';
import { SitePagerService } from 'src/app/services/pager/site-pager.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService } from 'src/app/services/notification/notification.service';
import { SiteService } from 'src/app/services/site/site.service';
import { UserService } from 'src/app/services/user/user.service';
import { THEMES } from 'src/app/constants/themes.const';
import { Asset } from 'src/app/models/asset/asset.model';
import { AssetService } from 'src/app/services/asset/asset.service';
import { TimerUtil } from 'src/app/util/timer/timer.util';
import { SiteContact } from 'src/app/models/site/_submodels/site-contact.model';
import { SiteFees } from 'src/app/models/site/_submodels/site-fees.model';
import { BACKGROUND_IMAGES, BACKGROUND_IMAGES2, BACKGROUND_IMAGES3 } from 'src/app/constants/background-images.const';

@Component({
  selector: 'app-admin-site-setup',
  templateUrl: './admin-site-setup.component.html',
  styleUrls: ['./admin-site-setup.component.scss']
})
export class AdminSiteSetupComponent extends BaseComponent
  implements OnInit, AfterViewInit {
  private navigationState: NavigationState;
  public siteId: string;
  public site: Site;
  public userRole: string;
  public hideNextButton = true;
  public hidePreviousButton = true;
  public serverUrl: string;
  public logoAsset: Asset;
  public backgroundImage1Asset: Asset;
  public backgroundImage2Asset: Asset;
  public backgroundImage3Asset: Asset;
  private themes = THEMES;
  private dialogIsOpen: boolean;
  // private backgroundImages = BACKGROUND_IMAGES;
  // private backgroundImages2 = BACKGROUND_IMAGES2;
  // private backgroundImages3 = BACKGROUND_IMAGES3;

  // constructor
  constructor(
    private userService: UserService,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private siteService: SiteService,
    private assetService: AssetService,
    @Inject(LeathermanAppConfigInjectionToken)
    public config: ILeathermanAppConfig,
    private notificationService: NotificationService,
    private router: Router,
    @Inject(DOCUMENT) private document: Document,
    private sitePagerService: SitePagerService
  ) {
    super();

    this.navigationState = new NavigationState();
    this.navigationState.title = 'Site';
    this.navigationService.updateNavigationState(this.navigationState);
    this.serverUrl = config.serverUrl;
  }

  // ngOnInit
  public async ngOnInit() {
    this.userRole = this.userService._getPrimaryUserRole();
    this.activatedRoute.params.subscribe(async params => {
      this.siteId = params.siteId;

      await this.loadData(this.siteId);
      this.isInitialized = true;
    });
    this.hideNextButton = this.sitePagerService.hideNext();
    this.hidePreviousButton = this.sitePagerService.hidePrevious();
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  // public getBackgroundImageLabel(backgroundImageValue: string): string {
  //   const matchingBackgroundImage = this.backgroundImages.find(t => t.value === backgroundImageValue);
  //   if (!matchingBackgroundImage) {
  //     return 'Image 1';
  //   }
  //   return matchingBackgroundImage.label;
  // }

  // public getBackgroundImage2Label(backgroundImageValue: string): string {
  //   const matchingBackgroundImage = this.backgroundImages2.find(t => t.value === backgroundImageValue);
  //   if (!matchingBackgroundImage) {
  //     return 'Image 1';
  //   }
  //   return matchingBackgroundImage.label;
  // }

  // public getBackgroundImage3Label(backgroundImageValue: string): string {
  //   const matchingBackgroundImage = this.backgroundImages3.find(t => t.value === backgroundImageValue);
  //   if (!matchingBackgroundImage) {
  //     return 'Image 1';
  //   }
  //   return matchingBackgroundImage.label;
  // }

  public getBackgroundImage1Url() {
    let url: string;

    if (this.backgroundImage1Asset) {
      url = `${this.serverUrl}/sites/${this.siteId}/${this.backgroundImage1Asset.fileName}`;
    } else {
      switch (this.site.backgroundImage) {
        case 'BG1':
          url = `${this.serverUrl}/default/background-image-1/background-image-1-1.jpg`;
          break;
        case 'BG2':
          url = `${this.serverUrl}/default/background-image-1/background-image-1-2.jpg`;
          break;
        case 'BG3':
          url = `${this.serverUrl}/default/background-image-1/background-image-1-3.jpg`;
          break;
        case 'BG4':
          url = `${this.serverUrl}/default/background-image-1/background-image-1-4.jpg`;
          break;
        case 'BG5':
          url = `${this.serverUrl}/default/background-image-1/background-image-1-5.jpg`;
          break;
        default:
          url = `${this.serverUrl}/default/background-image-1/background-image-1-1.jpg`;
          break;
      }
    }

    return url;
  }

  public getBackgroundImage2Url() {
    let url: string;

    if (this.backgroundImage2Asset) {
      url = `${this.serverUrl}/sites/${this.siteId}/${this.backgroundImage2Asset.fileName}`;
    } else {
      url = `${this.serverUrl}/default/background-image-2/background-image-2-1.jpg`;
    }

    return url;
  }

  public getBackgroundImage3Url() {
    let url: string;

    if (this.backgroundImage3Asset) {
      url = `${this.serverUrl}/sites/${this.siteId}/${this.backgroundImage3Asset.fileName}`;
    } else {
      url = `${this.serverUrl}/default/background-image-3/background-image-3-1.jpg`;
    }

    return url;
  }

  public getLogoUrl() {
    if (!this.logoAsset || !this.logoAsset.fileName) {
      return '';
    }
    const url = `${this.serverUrl}/sites/${this.siteId}/${this.logoAsset.fileName}`;

    return url;
  }

  public getThemeLabel(themeValue: string): string {
    const matchingTheme = this.themes.find(t => t.value === themeValue);
    if (!matchingTheme) {
      return 'Default';
    }
    return matchingTheme.label;
  }

  public onBackLinkClicked() {
    this.sitePagerService.goBack();
  }

  public onDelete = async () => {
    // if ((await this.siteService.deleteSite(this.siteId)) === false) {
    //   return;
    // }
    // await TimerUtil.delay(1000);
    // this.sitePagerService.goBack();
  }

  public onEdit = async () => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    const editedSite = await this.siteService.editSite(this.siteId);
    this.dialogIsOpen = false;
    if (editedSite == null) {
      return;
    }
    await this.loadData(this.siteId);
  }

  public onEditBackgroundImage = async (event: any, token: string, position: string) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const result = await this.siteService.uploadBackgroundImage(this.siteId, token, position);
    this.dialogIsOpen = false;
    if (result === true) {
      TimerUtil.delay(2500);
      this.loadData(this.siteId);
    }
  }

  public onEditChatraSettings = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editChatraSettings(
      this.site._id
    );
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditDnsVerificationCode = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSiteDnsVerificationCode(this.siteId);
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditFirstPromoterSettings = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editFirstPromoterSettings(
      this.site._id
    );
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditGoogleAnalyticsSettings = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editGoogleAnalyticsSettings(
      this.site._id
    );
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditSiteContact = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSiteContact(this.siteId);
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditSiteMailingAddress = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSiteMailingAddress(this.siteId);
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditSiteFees = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSiteFees(this.siteId);
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditSitePricing = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSitePricing(this.siteId);
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditSiteProperties = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedSite = await this.siteService.editSite(this.siteId);
    this.dialogIsOpen = false;
    if (editedSite) {
      this.site = editedSite;
    }
  }

  public onEditSiteLogo = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const result = await this.siteService.uploadSiteLogo(this.siteId);
    this.dialogIsOpen = false;
    if (result === true) {
      TimerUtil.delay(2500);
      this.loadData(this.siteId);
    }
  }

  public onNextSite = async () => {
    const nextSiteId = await this.sitePagerService.getNextSiteId();
    if (!nextSiteId) {
      this.hideNextButton = true;
      return;
    }
    this.router.navigate(['admin/sites', nextSiteId, 'setup']);
    this.hideNextButton = this.sitePagerService.hideNext();
    this.hidePreviousButton = this.sitePagerService.hidePrevious();
  }

  public onNotification = async (notification: WebSocketNotification) => {

  }

  public onPreviousSite = async () => {
    const previousSiteId = await this.sitePagerService.getPreviousSiteId();
    if (!previousSiteId) {
      return;
    }
    this.router.navigate(['admin/sites', previousSiteId, 'setup']);
    this.hideNextButton = this.sitePagerService.hideNext();
    this.hidePreviousButton = this.sitePagerService.hidePrevious();
  }

  public toYesNo(value: boolean): string {
    return value === true ? 'Yes' : 'No';
  }

  private async loadData(siteId: string) {
    this.site = await this.siteService.getSite(siteId);
    if (!this.site.theme) {
      this.site.theme = 'Default';
    }
    if (!this.site.contact) {
      this.site.contact = new SiteContact();
    }
    if (!this.site.appUrl) {
      this.site.appUrl = 'app.' + this.site.url;
    }
    if (!this.site.firstDnsHost) {
      this.site.firstDnsHost = '@';
    }
    if (!this.site.secondDnsHost) {
      this.site.secondDnsHost = 'app';
    }
    this.logoAsset = await this.assetService.getAssetByToken(
      this.siteId,
      'logo'
    );
    this.backgroundImage1Asset = await this.assetService.getAssetByToken(
      this.siteId,
      'background-image-1'
    );
    this.backgroundImage2Asset = await this.assetService.getAssetByToken(
      this.siteId,
      'background-image-2'
    );
    this.backgroundImage3Asset = await this.assetService.getAssetByToken(
      this.siteId,
      'background-image-3'
    );
    if (!this.site.fees) {
      this.site.fees = new SiteFees();
    }

    this.isLoading = false;
  }
}
