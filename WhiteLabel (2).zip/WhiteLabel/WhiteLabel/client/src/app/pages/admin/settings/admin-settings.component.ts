import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { NavigationState } from '../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../services/navigation/navigation.service';
import { BaseComponent } from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from '../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../services/notification/_models/notification.model';
import { MdcIconRegistry } from '@angular-mdc/web';
import { UserSettingsService } from 'src/app/services/user-settings/user-settings.service';
import { InfoDialogService } from 'src/app/dialogs/info/info-dialog.service';

@Component({
  selector: 'app-admin-settings',
  templateUrl: './admin-settings.component.html',
  styleUrls: ['./admin-settings.component.scss']
})
export class AdminSettingsComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public hideAll: boolean;
  public showTip: boolean;
  private navigationState: NavigationState;

  // constructor
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private userSettingsService: UserSettingsService,
    iconRegistry: MdcIconRegistry,
    private infoDialogService: InfoDialogService
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Settings';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    await this.loadData();
    this.isInitialized = true;
    this.isLoading = false;
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public onBackLinkClicked() {
    this.router.navigate(['admin/dashboard']);
  }

  public async onChangeHideAllTips($event) {
    await this.userSettingsService.hideTips($event.checked);
    await this.loadData();
  }

  public onEditSettingGroup1() { }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  public async onRestoreAllTips() {
    const result = await this.userSettingsService.restoreAllTips();
    if (result === true) {
      await this.infoDialogService.openInfoDialog('Restore All Tips', 'Your tips have been reset.');
    } else {
      await this.infoDialogService.openInfoDialog('Restore All Tips', 'There was a problem resetting your tips.');
    }
    this.showTip = true;
    await this.loadData();
  }

  private async loadData() {
    const userSettings = await this.userSettingsService.getUserSettings();
    console.log(userSettings);
    this.hideAll = userSettings.tips.hideAll;
    if (userSettings.tips.hideAll === true || userSettings.tips.hideSettings === true) {
      this.showTip = false;
    } else {
      this.showTip = true;
    }
  }
}
