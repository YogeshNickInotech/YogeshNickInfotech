import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  Inject
} from '@angular/core';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig,
  GetOptions
} from 'leatherman';
import { MdcIconRegistry } from '@angular-mdc/web';
import { SiteService } from 'src/app/services/site/site.service';
import { TimerUtil } from 'src/app/util/timer/timer.util';

import { ListState } from 'src/app/models/list-state/list-state.model';
import { UserService } from 'src/app/services/user/user.service';
import { SiteHeadings } from 'src/app/models/site/_submodels/site-headings.model';
import { Router, ActivatedRoute } from '@angular/router';
import { PolicySection } from 'src/app/models/policy-section/policy-section.model';
import { PolicySectionService } from 'src/app/services/policy-section/policy-section.service';
import { NavigationState } from 'src/app/services/navigation/_models/navigation-state.model';
import { NotificationService } from 'src/app/services/notification/notification.service';
import { NavigationService } from 'src/app/services/navigation/navigation.service';
import { WebSocketNotification } from 'src/app/services/notification/_models/notification.model';
import { SitePagerService } from 'src/app/services/pager/site-pager.service';
import { Site } from 'src/app/models/site/site.model';

@Component({
  selector: 'app-admin-site-refund-policy',
  templateUrl: './admin-site-refund-policy.component.html',
  styleUrls: ['./admin-site-refund-policy.component.scss']
})
export class AdminSiteRefundPolicyComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public heading: string;
  public policySections: PolicySection[];
  public pageState: ListState = new ListState();
  public serverUrl: string;
  private navigationState: NavigationState;
  public hideNextButton = true;
  public hidePreviousButton = true;
  private siteId: string;
  public site: Site;
  private dialogIsOpen: boolean; 
  // constructor
  constructor(
    @Inject(LeathermanAppConfigInjectionToken) config: ILeathermanAppConfig,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private siteService: SiteService,
    private userService: UserService,
    private policySectionService: PolicySectionService,
    private sitePagerService: SitePagerService,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Setup';
    this.navigationState.selectedTabIndex = 1;
    this.navigationState.addTab(
      'Refund Policy',
      `/admin/sites/ABCD/policies/terms-of-service`,
      'settings_applications'
    );
    this.navigationState.addTab(
      'Terms of Service',
      `/admin/sites/ABCD/policies/refund-policy`,
      'account_balance'
    );
    this.navigationState.addTab(
      'Refund Policy',
      `/admin/sites/ABCD/policies/refund-policy`,
      'credit_card'
    );
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
    this.serverUrl = config.serverUrl;
  }

  public async ngOnInit() {
    this.activatedRoute.params.subscribe(async params => {
      this.siteId = params.siteId;

      this.navigationState = new NavigationState();
      this.navigationState.title = 'Site';
      this.navigationState.selectedTabIndex = 1;
      this.navigationState.addTab(
        'Terms of Service',
        `/admin/sites/${this.siteId}/policies/terms-of-service`,
        'gavel'
      );
      this.navigationState.addTab(
        'Refund Policy',
        `/admin/sites/${this.siteId}/policies/refund-policy`,
        'lock'
      );
      this.navigationState.addTab(
        'Refund Policy',
        `/admin/sites/${this.siteId}/policies/refund-policy`,
        'money_off'
      );
      this.navigationService.updateNavigationState(this.navigationState);

      await this.loadData();
      this.isInitialized = true;
    });
    this.hideNextButton = this.sitePagerService.hideNext();
    this.hidePreviousButton = this.sitePagerService.hidePrevious();
    this.activatedRoute.queryParams.subscribe(async params => {
      await this.initializePageState(params);
    
      this.isLoading = false;
  
    });
  }

  public getContentLabel(index: number): string {
    if (index === 0) {
      return 'Content';
    }
    return '';
  }

  public getSectionLabel(index: number): string {
    const sectionNumber = index + 1;
    return 'Section ' + sectionNumber;
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public onBackLinkClicked() {
    this.sitePagerService.goBack();
  }

  // onDeletePolicySection
  public onDeletePolicySection = async (event: any, id: string) => {
    event.stopPropagation();
    if ((await this.policySectionService.deletePolicySection(id)) === false) {
      return;
    }
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  // onEditRefundPolicyHeading
  public onEditHeading = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedHeading = await this.siteService.editSiteHeading(this.siteId, 'refund-policy');
    this.dialogIsOpen = false;
    if (editedHeading) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onEditPolicySection
  public onEditPolicySection = async (event: any, id: string) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedPolicySection = await this.policySectionService.editPolicySection(id);
    this.dialogIsOpen = false;
    if (editedPolicySection) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public async onNewPolicySection() {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    const newPolicySection = await this.policySectionService.newPolicySection(this.siteId, 'refund-policy');
    this.dialogIsOpen = false;
    if (newPolicySection) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public onNextSite = async () => {
    const nextSiteId = await this.sitePagerService.getNextSiteId();
    if (!nextSiteId) {
      this.hideNextButton = true;
      return;
    }
    this.router.navigate(['admin/sites', nextSiteId]);
    this.hideNextButton = this.sitePagerService.hideNext();
    this.hidePreviousButton = this.sitePagerService.hidePrevious();
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  private async loadData() {
    this.site = await this.siteService.getSite(this.siteId);
    if (!this.site.headings) {
      this.site.headings = new SiteHeadings();
    }
    this.heading = this.site.headings.refundPolicy;
    const options = new GetOptions(this.pageState.currentPage, this.pageState.pageSize);
    options.setSort('index', true);
    this.policySections = await this.policySectionService.getPolicySections(options, this.siteId, 'refund-policy');
    this.pageState.rowCount = await this.policySectionService.getPolicySectionsCount(this.siteId, 'refund-policy');
    this.pageState.pageCount = GetOptions.calculatePageCount(this.pageState.rowCount, this.pageState.pageSize);
  }

  public onPreviousSite = async () => {
    const previousSiteId = await this.sitePagerService.getPreviousSiteId();
    if (!previousSiteId) {
      return;
    }
    this.router.navigate(['admin/sites', previousSiteId]);
    this.hideNextButton = this.sitePagerService.hideNext();
    this.hidePreviousButton = this.sitePagerService.hidePrevious();
  }

   //  paging start
  private updateUrl() {
    const queryParams: any = {};
    if (this.pageState.query) {
      queryParams.q = this.encodeURIComponent(this.pageState.query);
    }
    queryParams.p = this.pageState.currentPage;
    this.router.navigate([`/admin/sites/${this.siteId}/policies/refund-policy`,], {
      queryParams
    });
  }


    // initializePageState
private async initializePageState(queryParams: any) {
  this.pageState.query = this.decodeURIComponent(queryParams.q);

  if (queryParams.p) {
    const currentPage = parseInt(queryParams.p, 11);
    this.pageState.currentPage = currentPage > 0 ? currentPage : 1;
  } else {
    this.pageState.currentPage = 1;
  }

  this.pageState.pageSize = 11;
}

// onPageChanged
public async onPageChanged(pageNumber: number) {
  this.pageState.currentPage = pageNumber;
  this.updateUrl();
  await this.loadData();
  window.scrollTo(0, 0);
}


}
