import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminDashboardComponent } from './dashboard/admin-dashboard.component';
import { AdminOrdersComponent } from './orders/admin-orders.component';
import { AdminOrderComponent } from './orders/_pages/admin-order-component/admin-order.component';
import { AdminSitesComponent } from './sites/admin-sites.component';
import { AdminSiteSetupComponent } from './sites/_pages/setup/admin-site-setup.component';
import { AdminSiteFaqComponent } from './sites/_pages/faq/admin-site-faq.component';
import { AdminSiteOrdersComponent } from './sites/_pages/orders/admin-site-orders.component';
import { AdminUsersComponent } from './admin-users/admin-users.component';
import { AdminAccountComponent } from './account/admin-account.component';
import { AdminSettingsComponent } from './settings/admin-settings.component';
import { AdminSitePrivacyPolicyComponent } from './sites/_pages/privacy-policy/admin-site-privacy-policy.component';
import { AdminSiteOrderComponent } from './sites/_pages/orders/admin-site-order-component/admin-site-order.component';
import { AdminSiteTermsOfServiceComponent } from './sites/_pages/terms-of-service/admin-site-terms-of-service.component';
import { AdminOrderReportComponent } from './reports/order-report/admin-order-report.component';
import { AdminCustomerReportComponent } from './reports/customer-report/admin-customer-report.component';
import { AdminSitePaymentsComponent } from './sites/_pages/payments/admin-site-payments.component';
import { AdminSiteRefundPolicyComponent } from './sites/_pages/refund-policy/admin-site-refund-policy.component';
import { AdminSiteUsersComponent } from './site-users/admin-site-users.component';
import { AdminCustomersComponent } from './customers/admin-customers.component';
import { AdminCustomerComponent } from './customers/_pages/admin-customer-component/admin-customer.component';
import { AdminSiteReportComponent } from './reports/site-report/admin-site-report.component';

const routes: Routes = [
  {
    path: 'dashboard',
    component: AdminDashboardComponent,
    data: { title: 'Dashboard', breadcrumb: 'Dashboard' }
  },
  {
    path: 'orders',
    component: AdminOrdersComponent,
    data: { title: 'Orders', breadcrumb: 'Orders' }
  },
  {
    path: 'orders/:orderId',
    component: AdminOrderComponent,
    data: { title: 'Order', breadcrumb: 'Order' }
  },
  {
    path: 'reports/order-report',
    component: AdminOrderReportComponent,
    data: { title: 'Order Report', breadcrumb: 'Order Report' }
  },
  {
    path: 'reports/customer-report',
    component: AdminCustomerReportComponent,
    data: { title: 'Customer Report', breadcrumb: 'Customer Report' }
  },
  {
    path: 'reports/site-report',
    component: AdminSiteReportComponent,
    data: { title: 'Site Report', breadcrumb: 'Site Report' }
  },
  {
    path: 'sites',
    component: AdminSitesComponent,
    data: { title: 'Sites', breadcrumb: 'Sites' }
  },
  {
    path: 'sites/:siteId',
    component: AdminSiteSetupComponent,
    data: { title: 'Site', breadcrumb: 'Site' }
  },
  {
    path: 'sites/:siteId/setup',
    component: AdminSiteSetupComponent,
    data: { title: 'Site', breadcrumb: 'Site' }
  },
  {
    path: 'sites/:siteId/policies/terms-of-service',
    component: AdminSiteTermsOfServiceComponent,
    data: { title: 'Site Policies', breadcrumb: 'Site Policies' }
  },
  {
    path: 'sites/:siteId/policies/privacy-policy',
    component: AdminSitePrivacyPolicyComponent,
    data: { title: 'Site Policies', breadcrumb: 'Site Policies' }
  },
  {
    path: 'sites/:siteId/policies/refund-policy',
    component: AdminSiteRefundPolicyComponent,
    data: { title: 'Site Policies', breadcrumb: 'Site Policies' }
  },
  {
    path: 'sites/:siteId/faq',
    component: AdminSiteFaqComponent,
    data: { title: 'Site FAQ', breadcrumb: 'Site FAQ' }
  },
  {
    path: 'sites/:siteId/orders',
    component: AdminSiteOrdersComponent,
    data: { title: 'Site Orders', breadcrumb: 'Site Orders' }
  },
  {
    path: 'sites/:siteId/orders/:orderId',
    component: AdminSiteOrderComponent,
    data: { title: 'Site Order', breadcrumb: 'Site Order' }
  },
  {
    path: 'sites/:siteId/payments',
    component: AdminSitePaymentsComponent,
    data: { title: 'Payments', breadcrumb: 'Payments' }
  },
  { 
    path: 'site-users',
    component: AdminSiteUsersComponent,
    data: { title: 'Site Users', breadcrumb: 'Site Users' }
  },
  {
    path: 'customers',
    component: AdminCustomersComponent,
    data: { title: 'Customers', breadcrumb: 'Customers' }
  },
  {
    path: 'customers/:customerId',
    component: AdminCustomerComponent,
    data: { title: 'Customer', breadcrumb: 'Customer' }
  },
  {
    path: 'admin-users',
    component: AdminUsersComponent,
    data: { title: 'Admin Users', breadcrumb: 'Admin Users' }
  },
  {
    path: 'account',
    component: AdminAccountComponent,
    data: { title: 'Account', breadcrumb: 'Account' }
  },
  {
    path: 'settings',
    component: AdminSettingsComponent,
    data: { title: 'Settings', breadcrumb: 'Settings' }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
