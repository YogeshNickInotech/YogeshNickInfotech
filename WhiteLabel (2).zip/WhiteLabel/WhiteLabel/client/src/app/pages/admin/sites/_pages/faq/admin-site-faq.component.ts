import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  Inject
} from '@angular/core';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig,
  GetOptions
} from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { MdcIconRegistry } from '@angular-mdc/web';
import { UserService } from 'src/app/services/user/user.service';
import { ListState } from 'src/app/models/list-state/list-state.model';
import { FaqService } from 'src/app/services/faq/faq.service';
import { Faq } from 'src/app/models/faq/faq.model';
import { TimerUtil } from 'src/app/util/timer/timer.util';
import { SiteService } from 'src/app/services/site/site.service';
import { SiteHeadings } from 'src/app/models/site/_submodels/site-headings.model';
import { NavigationService } from 'src/app/services/navigation/navigation.service';
import { NavigationState } from 'src/app/services/navigation/_models/navigation-state.model';
import { Site } from 'src/app/models/site/site.model';
import { SitePagerService } from 'src/app/services/pager/site-pager.service';

@Component({
  selector: 'app-admin-site-faq',
  templateUrl: './admin-site-faq.component.html',
  styleUrls: ['./admin-site-faq.component.scss']
})
export class AdminSiteFaqComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public serverUrl: string;
  public pageState: ListState = new ListState();
  public faqs: Faq[];
  public heading: string;
  public site: Site;
  public hideNextButton = true;
  public hidePreviousButton = true;
  private navigationState: NavigationState;
  private siteId: string;
  private dialogIsOpen: boolean; 

  // constructor
  constructor(
    private router: Router,
    @Inject(LeathermanAppConfigInjectionToken) config: ILeathermanAppConfig,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private faqService: FaqService,
    private siteService: SiteService,
    private sitePagerService: SitePagerService,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'FAQ';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
    this.serverUrl = config.serverUrl;
  }

  // ngOnInit
  public async ngOnInit() {
    this.activatedRoute.params.subscribe(async params => {
      this.siteId = params.siteId;
      await this.initializePageState(params);

      await this.loadData();
      this.isInitialized = true;
    });
    this.hideNextButton = this.sitePagerService.hideNext();
    this.hidePreviousButton = this.sitePagerService.hidePrevious();
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
  }

  public getQuestionLabel(index: number): string {
    if (index === 0) {
      return 'Questions';
    }
    return '';
  }

  public onBackLinkClicked() {
    this.sitePagerService.goBack();
  }

  // onDeleteFaq
  public onDeleteFaq = async (event: any, id: string) => {
    event.stopPropagation();
    if ((await this.faqService.deleteFaq(id)) === false) {
      return;
    }
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  // onEditFaq
  public onEditFaq = async (event: any, id: string) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedFaq = await this.faqService.editFaq(id);
    this.dialogIsOpen = false;
    if (editedFaq) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onEditFaqHeading
  public onEditFaqHeading = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedHeading = await this.siteService.editSiteHeading(this.siteId, 'faq');
    this.dialogIsOpen = false;
    if (editedHeading) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public async onNewFaq() {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    const newFaq = await this.faqService.newFaq(this.siteId);
    this.dialogIsOpen = false;
    if (newFaq) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onPageChanged
  public async onPageChanged(pageNumber: number) {
    // this.pageState.currentPage = pageNumber;
    // this.updateUrl();
    // await this.loadData();
    // window.scrollTo(0, 0);
  }

  public onNextSite = async () => {
    const nextSiteId = await this.sitePagerService.getNextSiteId();
    if (!nextSiteId) {
      this.hideNextButton = true;
      return;
    }
    this.router.navigate(['admin/sites', nextSiteId, 'faq']);
    this.hideNextButton = this.sitePagerService.hideNext();
    this.hidePreviousButton = this.sitePagerService.hidePrevious();
  }

  public onPreviousSite = async () => {
    const previousSiteId = await this.sitePagerService.getPreviousSiteId();
    if (!previousSiteId) {
      return;
    }
    this.router.navigate(['admin/sites', previousSiteId, 'faq']);
    this.hideNextButton = this.sitePagerService.hideNext();
    this.hidePreviousButton = this.sitePagerService.hidePrevious();
  }

  // initializePageState
  private async initializePageState(queryParams: any) {
    if (queryParams.p) {
      const currentPage = parseInt(queryParams.p, 10);
      this.pageState.currentPage = currentPage > 0 ? currentPage : 1;
    } else {
      this.pageState.currentPage = 1;
    }
    this.pageState.pageSize = 25;
  }

  public async loadData() {
    this.site = await this.siteService.getSite(this.siteId);
    if (!this.site.headings) {
      this.site.headings = new SiteHeadings();
    }
    this.heading = this.site.headings.faq;
    const options = new GetOptions();
    options.setSort('index', true);
    this.faqs = await this.faqService.getFaqs(options, this.siteId);
    const faqCount = await this.faqService.getFaqCount(options, this.siteId);

    this.pageState.pageCount = GetOptions.calculatePageCount(
      faqCount,
      this.pageState.pageSize
    );
    this.pageState.rowCount = faqCount;
  }
}
