import { Component, OnInit, Inject, AfterViewInit } from '@angular/core';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig
} from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { DOCUMENT } from '@angular/common';
import { UserService } from 'src/app/services/user/user.service';
import { AdminOrderPagerService } from 'src/app/services/pager/admin-order-pager.service';
import { Customer } from 'src/app/models/customer/customer.model';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { NavigationState } from 'src/app/services/navigation/_models/navigation-state.model';
import { Order } from 'src/app/models/order/order.model';
import { NavigationService } from 'src/app/services/navigation/navigation.service';
import { OrderService } from 'src/app/services/order/order.service';
import { NotificationService } from 'src/app/services/notification/notification.service';
import { WebSocketNotification } from 'src/app/services/notification/_models/notification.model';
import { AdminSiteOrderPagerService } from 'src/app/services/pager/admin-site-order-pager.service';
import { Site } from 'src/app/models/site/site.model';
import { SiteService } from 'src/app/services/site/site.service';

@Component({
  selector: 'app-admin-site-order',
  templateUrl: './admin-site-order.component.html',
  styleUrls: ['./admin-site-order.component.scss']
})
export class AdminSiteOrderComponent extends BaseComponent
  implements OnInit, AfterViewInit {
  private navigationState: NavigationState;
  public orderId: string;
  public order: Order;
  public customer: Customer;
  public userRole: string;
  public hideNextButton = true;
  public hidePreviousButton = true;
  private siteId: string;
  public site: Site;
  private dialogIsOpen: boolean;

  // constructor
  constructor(
    private siteService: SiteService,
    private userService: UserService,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private orderService: OrderService,
    private customerService: CustomerService,
    @Inject(LeathermanAppConfigInjectionToken)
    public config: ILeathermanAppConfig,
    private notificationService: NotificationService,
    private router: Router,
    @Inject(DOCUMENT) private document: Document,
    private orderPagerService: AdminSiteOrderPagerService
  ) {
    super();

    this.navigationState = new NavigationState();
    this.navigationState.title = 'Order';
    this.navigationState.selectedTabIndex = 0;
    this.navigationState.addTab(
      'Orders',
      `/admin/sites/${this.siteId}/orders`,
      'attach_money'
    );
    this.navigationState.addTab(
      'Payments',
      `/admin/sites/${this.siteId}/payments`,
      'credit_card'
    );
    this.navigationService.updateNavigationState(this.navigationState);
  }

  // ngOnInit
  public async ngOnInit() {
    this.userRole = this.userService._getPrimaryUserRole();
    this.activatedRoute.params.subscribe(async params => {
      this.orderId = params.orderId;
      this.siteId = params.siteId;

      this.isLoading = true;
      await this.loadData(this.orderId);

      this.navigationState = new NavigationState();
      this.navigationState.title = 'Site';
      this.navigationState.selectedTabIndex = 0;
      this.navigationState.addTab(
        'Orders',
        `/admin/sites/${this.siteId}/orders`,
        'attach_money'
      );
      this.navigationState.addTab(
        'Payments',
        `/admin/sites/${this.siteId}/payments`,
        'credit_card'
      );
      this.navigationService.updateNavigationState(this.navigationState);

      this.isInitialized = true;
    });
    this.hideNextButton = this.orderPagerService.hideNext();
    this.hidePreviousButton = this.orderPagerService.hidePrevious();
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public getFullAddress(customer: Customer): string {
    if (!customer) {
      return '';
    }
    const fullAddress =
      customer.address.address +
      ', ' +
      customer.address.city +
      ', ' +
      customer.address.state +
      ' ' +
      customer.address.zip;
    return fullAddress;
  }

  public onBackLinkClicked() {
    this.orderPagerService.goBack();
  }

  public onCustomerClick() {
    this.router.navigate(['admin/customers', this.customer._id]);
  }

  public onDelete = async () => {
    // if ((await this.orderService.deleteOrder(this.orderId))=== false) {
    //   return;
    // }
    // await TimerUtil.delay(1000);
    // this.orderPagerService.goBack();
  }

  public onDownload() {
    this.orderService.downloadOrderFile(this.order._id);
  }

  public onDownloadSourceFile() {
    this.orderService.downloadOrderSourceFile(this.order._id);
  }

  public onEdit = async () => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    const editedOrder = await this.orderService.editOrder(this.orderId);
    this.dialogIsOpen = false;
    if (editedOrder == null) {
      return;
    }
    await this.loadData(this.orderId);
  }

  public onSiteClick() {
    this.router.navigate(['admin/sites', this.site._id]);
  }

  private async loadData(orderId: string) {
    this.order = await this.orderService.getOrder(orderId);

    if (!this.order) {
      this.router.navigate(['admin', 'sites', this.siteId, 'orders']);
      return;
    }

    this.customer = await this.customerService.getCustomer(
      this.order.customerId
    );
    this.siteId = this.order.siteId;
    this.site = await this.siteService.getSite(this.order.siteId);
    this.orderPagerService.setSiteId(this.order.siteId);
    this.isLoading = false;
  }

  public onNextOrder = async () => {
    const nextOrderId = await this.orderPagerService.getNextOrderId();
    if (!nextOrderId) {
      this.hideNextButton = true;
      return;
    }
    this.router.navigate(['admin', 'sites', this.siteId, 'orders', nextOrderId]);
    this.hideNextButton = this.orderPagerService.hideNext();
    this.hidePreviousButton = this.orderPagerService.hidePrevious();
  }

  public onNotification = async (notification: WebSocketNotification) => {

  }

  public onPreviousOrder = async () => {
    const previousOrderId = await this.orderPagerService.getPreviousOrderId();
    if (!previousOrderId) {
      return;
    }
    this.router.navigate(['admin', 'sites', this.siteId, 'orders', previousOrderId]);
    this.hideNextButton = this.orderPagerService.hideNext();
    this.hidePreviousButton = this.orderPagerService.hidePrevious();
  }

  public toYesNo(value: boolean): string {
    return value === true ? 'Yes' : 'No';
  }
}
