import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  ViewChild
} from '@angular/core';
import { NavigationState } from '../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../services/navigation/navigation.service';
import { MdcCardUIService } from '../../../components/mdc-card/_services/mdc-card-ui.service';
import { BaseComponent, CollectionUtil, GetOptions } from 'leatherman';
import { TimerUtil } from '../../../util/timer/timer.util';
import { UserService } from '../../../services/user/user.service';
import { User } from '../../../models/user/user.model';
import { UserSettingsService } from '../../../services/user-settings/user-settings.service';
import { ListState } from '../../../models/list-state/list-state.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Sort } from '@angular/material/sort';
import { GetSiteUserOptions } from 'src/app/models/user/get-site-user-options.model';
import { InfoDialogService } from 'src/app/dialogs/info/info-dialog.service';

@Component({
  selector: 'app-admin-users',
  templateUrl: './admin-users.component.html',
  styleUrls: ['./admin-users.component.scss']
})
export class AdminUsersComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  // Public users
  public uiService: MdcCardUIService;
  public users: User[] = [];
  public userId: string;
  public pageState: ListState = new ListState();
  private dialogIsOpen: boolean;
  public displayedColumns: string[] = [
    'firstName',
    'lastName',
    'email',
    'actions'
  ];

  private navigationState: NavigationState;

  // constructor
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private userService: UserService,
    private userSettingsService: UserSettingsService,
    private infoDialogService: InfoDialogService
  ) {
    super();
    this.uiService = new MdcCardUIService();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Admin Users';
    this.navigationService.updateNavigationState(this.navigationState);
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = false;
    this.activatedRoute.queryParams.subscribe(async params => {
      this.isLoading = true;
      await this.initializePageState(params);
      await this.loadData();
      this.isLoading = false;
      this.isInitialized = true;
    });
  }

  // ngAfterViewInit
  public async ngAfterViewInit() { }

  public onBackLinkClicked() {
    this.router.navigate(['admin/dashboard']);
  }

  public async onChangePassword(event: any, id: string) {
    event.stopPropagation();
    const result = await this.userService.adminChangeUserPassword(id);
    if (result === true) {
      await this.infoDialogService.openInfoDialog('Change Customer Password', 'Customer password updated successfully.');
    }
  }

  public onDelete = async (event: any, id: string) => {
    event.stopPropagation();
    if ((await this.userService.deleteUser(id)) === false) {
      return;
    }
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  public onEdit = async (event: any, id: string) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedUser = await this.userService.editAdminUser(id);
    this.dialogIsOpen = false;
    if (editedUser) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public async onNew() {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    const newUser = await this.userService.newAdminUser();
    this.dialogIsOpen = false;
    if (newUser) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onPageChanged
  public async onPageChanged(pageNumber: number) {
    this.pageState.currentPage = pageNumber;
    this.updateUrl();
    await this.loadData();
    window.scrollTo(0, 0);
  }

  // onSearchTextChanged
  public async onSearchTextChanged(query: any) {
    this.pageState.query = query;
    this.updateUrl();
    await this.loadData();
  }

  // onSortChange
  public async onSortChange(sort: Sort) {
    this.pageState.sortColumn = sort.active;
    this.pageState.sortAscending = sort.direction === 'desc' ? false : true;
    this.updateUrl();
    await this.loadData();
    const userSettings = await this.userSettingsService.getUserSettings();
    userSettings.users.sortColumn = this.pageState.sortColumn;
    userSettings.users.sortAscending = this.pageState.sortAscending;
    await this.userSettingsService.updateUserSettings(userSettings);
  }

  // getOptions
  private getOptions(): GetSiteUserOptions {
    const options = new GetSiteUserOptions(
      this.pageState.currentPage,
      this.pageState.pageSize
    );
    if (this.pageState.sortColumn) {
      options.setSort(this.pageState.sortColumn, this.pageState.sortAscending);
    }
    options.query = this.encodeURIComponent(this.pageState.query);
    return options;
  }

  // initializePageState
  private async initializePageState(queryParams: any) {
    const userSettings = await this.userSettingsService.getUserSettings();

    this.pageState.query = this.decodeURIComponent(queryParams.q);

    if (queryParams.sort) {
      this.pageState.sortColumn = queryParams.sort;
    } else if (userSettings.users && userSettings.users.sortColumn) {
      this.pageState.sortColumn = userSettings.users.sortColumn;
    } else {
      this.pageState.sortColumn = 'relevance';
    }

    if (queryParams.order) {
      this.pageState.sortAscending =
        queryParams.order.toLowerCase() === 'desc' ? false : true;
    } else if (
      userSettings.users &&
      userSettings.users.sortAscending !== undefined
    ) {
      this.pageState.sortAscending = userSettings.users.sortAscending;
    } else if (queryParams.sort === undefined) {
      this.pageState.sortAscending = false;
    } else {
      this.pageState.sortAscending = true;
    }

    if (queryParams.p) {
      const currentPage = parseInt(queryParams.p, 10);
      this.pageState.currentPage = currentPage > 0 ? currentPage : 1;
    } else {
      this.pageState.currentPage = 1;
    }

    this.pageState.pageSize = 10;
  }

  private async loadData() {
    this.userId = await this.userService.userId;
    const options = this.getOptions();
    this.users = await this.userService.getAdminUsers(options);
    const userCount = await this.userService.getAdminUserCount(options);
    this.pageState.pageCount = GetOptions.calculatePageCount(
      userCount,
      this.pageState.pageSize
    );
    this.pageState.rowCount = userCount;
  }

  // updateUrl
  private updateUrl() {
    const queryParams: any = {};
    if (this.pageState.query) {
      queryParams.q = this.encodeURIComponent(this.pageState.query);
    }
    if (this.pageState.sortColumn !== 'relevance') {
      queryParams.sort = this.pageState.sortColumn;
      queryParams.order =
        this.pageState.sortAscending === true ? 'asc' : 'desc';
    }
    queryParams.p = this.pageState.currentPage;
    this.router.navigate(['/admin/admin-users'], {
      queryParams
    });
  }
}
