import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavigationState } from '../../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../../services/navigation/navigation.service';
import { MdcCardUIService } from '../../../../components/mdc-card/_services/mdc-card-ui.service';
import { BaseComponent, GetOptions, SearchResultFacetItem } from 'leatherman';
import { ListState } from '../../../../models/list-state/list-state.model';
import { ActivatedRoute, Router } from '@angular/router';
import { MdcMenuSelectedEvent } from '@angular-mdc/web';
import { OrderReportRow } from 'src/app/models/report/rows/order-report-row.model';
import { ReportFacet } from 'src/app/models/report/results/report-facet.model';
import { ReportOption } from 'src/app/models/report/results/report-option.model';
import { ReportService } from 'src/app/services/report/report.service';
import { GetReportOptions } from 'src/app/models/report/get-report-options.model';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-admin-order-report',
  templateUrl: './admin-order-report.component.html',
  styleUrls: ['./admin-order-report.component.scss']
})
export class AdminOrderReportComponent extends BaseComponent
  implements OnInit, OnDestroy {
  // Public users
  public uiService: MdcCardUIService;
  public reportRows: OrderReportRow[] = [];
  public pageState: ListState = new ListState();
  public facets: ReportFacet[] = [];
  public labelColumnHeading = 'Month';
  public reportTypeOptions: ReportOption;
  public yearOptions: ReportOption;
  public monthOptions: ReportOption;
  public displayedColumns: string[] = [
    'label',
    'order_count',
    'address_count',
    'order_value',
    'total_match_count',
    'total_match_percent'
  ];

  private navigationState: NavigationState;
  private options: ReportOption[] = [];

  // constructor
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private reportService: ReportService,
    private userService: UserService,
  ) {
    super();
    this.uiService = new MdcCardUIService();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Reports';
    this.navigationState.selectedTabIndex = 0;
    this.navigationState.addTab(
      'Orders',
      '/admin/reports/order-report',
      'attach_money'
    );
    this.navigationState.addTab(
      'Sites',
      '/admin/reports/site-report',
      'web'
    );
    this.navigationService.updateNavigationState(this.navigationState);
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = false;
    this.activatedRoute.queryParams.subscribe(async params => {
      this.isLoading = true;
      await this.initializePageState(params);
      await this.loadData();
      this.isLoading = false;
      this.isInitialized = true;
    });
  }

  public getTotalOrderCount() {
    return this.reportRows
      .map(t => t.orderCount)
      .reduce((acc, value) => acc + value, 0);
  }

  public getTotalAddressCount() {
    return this.reportRows
      .map(t => t.addressCount)
      .reduce((acc, value) => acc + value, 0);
  }

  public getTotalOrderValue() {
    return this.reportRows
      .map(t => t.orderValue)
      .reduce((acc, value) => acc + value, 0);
  }

  public getTotalMatchCount() {
    return this.reportRows
      .map(t => t.totalMatchCount)
      .reduce((acc, value) => acc + value, 0);
  }

  public getTotalMatchPercent() {
    const totalMatchCount = this.reportRows
      .map(t => t.totalMatchCount)
      .reduce((acc, value) => acc + value, 0);

    const totalAddressCount = this.reportRows
      .map(t => t.addressCount)
      .reduce((acc, value) => acc + value, 0);

    const totalMatchPercent =
      totalAddressCount > 0 ? totalMatchCount / totalAddressCount : 0;

    return totalMatchPercent;
  }

  // public getTotalTotalValue() {
  //   return this.reportRows
  //     .map(t => t.totalValue)
  //     .reduce((acc, value) => acc + value, 0);
  // }

  public async onFacetItemClicked(facetItem: SearchResultFacetItem) {
    this.pageState.filter = facetItem.query;
    this.updateUrl();
    await this.loadData();
  }

  public async onReportTypeMenuSelect($event: MdcMenuSelectedEvent) {
    const menuItem = this.reportTypeOptions.values[$event.index];
    this.pageState.filter = menuItem.query;
    this.updateUrl();
    await this.loadData();
  }

  public async onYearMenuSelect($event: MdcMenuSelectedEvent) {
    const menuItem = this.yearOptions.values[$event.index];
    this.pageState.filter = menuItem.query;
    this.updateUrl();
    await this.loadData();
  }

  public async onMonthMenuSelect($event: MdcMenuSelectedEvent) {
    const menuItem = this.monthOptions.values[$event.index];
    this.pageState.filter = menuItem.query;
    this.updateUrl();
    await this.loadData();
  }

  // getOptions
  private getOptions(): GetReportOptions {
    const options = new GetReportOptions();
    options.filter = this.pageState.filter;
    return options;
  }

  // initializePageState
  private async initializePageState(queryParams: any) {
    this.pageState.filter = queryParams.f;
  }

  private async loadData() {
    const options = this.getOptions();
    const reportResultsContainer = await this.reportService.getOrderReport(
      options
    );

    this.facets = reportResultsContainer.facets;
    this.options = reportResultsContainer.options;
    this.reportRows = reportResultsContainer.data;

    switch (reportResultsContainer.reportType) {
      case 'monthly':
        this.labelColumnHeading = 'Date';
        break;
      default:
        this.labelColumnHeading = 'Month';
        break;
    }

    for (const option of this.options) {
      switch (option.name) {
        case 'report-type':
          this.reportTypeOptions = option;
          break;
        case 'year':
          this.yearOptions = option;
          break;
        case 'month':
          this.monthOptions = option;
          break;
      }
    }
  }

  public onBackLinkClicked() {
    this.router.navigate(['admin/dashboard']);
  }

  // updateUrl
  private updateUrl() {
    const queryParams: any = {};
    if (this.pageState.filter) {
      queryParams.f = this.pageState.filter;
    }
    this.router.navigate(['/admin/reports/order-report'], {
      queryParams
    });
  }
}
