import { Component, OnInit, Inject, AfterViewInit } from '@angular/core';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig
} from 'leatherman';
import { OrderService } from '../../../../../services/order/order.service';
import { Order } from '../../../../../models/order/order.model';
import { NavigationState } from '../../../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../../../services/navigation/navigation.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from '../../../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../../../services/notification/_models/notification.model';
import { DOCUMENT } from '@angular/common';
import { UserService } from 'src/app/services/user/user.service';
import { AdminOrderPagerService } from 'src/app/services/pager/admin-order-pager.service';
import { Customer } from 'src/app/models/customer/customer.model';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { SiteService } from 'src/app/services/site/site.service';
import { Site } from 'src/app/models/site/site.model';

@Component({
  selector: 'app-admin-order',
  templateUrl: './admin-order.component.html',
  styleUrls: ['./admin-order.component.scss']
})
export class AdminOrderComponent extends BaseComponent
  implements OnInit, AfterViewInit {
  private navigationState: NavigationState;
  public orderId: string;
  public order: Order;
  public customer: Customer;
  public site: Site;
  public userRole: string;
  public hideNextButton = true;
  public hidePreviousButton = true;
  private dialogIsOpen: boolean;

  // constructor
  constructor(
    private userService: UserService,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private orderService: OrderService,
    private customerService: CustomerService,
    private siteService: SiteService,
    @Inject(LeathermanAppConfigInjectionToken)
    public config: ILeathermanAppConfig,
    private notificationService: NotificationService,
    private router: Router,
    @Inject(DOCUMENT) private document: Document,
    private orderPagerService: AdminOrderPagerService
  ) {
    super();

    this.navigationState = new NavigationState();
    this.navigationState.title = 'Order';
    this.navigationService.updateNavigationState(this.navigationState);
  }

  // ngOnInit
  public async ngOnInit() {
    this.userRole = this.userService._getPrimaryUserRole();
    this.activatedRoute.params.subscribe(async params => {
      this.orderId = params.orderId;
      await this.loadData(this.orderId);
      this.isInitialized = true;
    });
    this.hideNextButton = this.orderPagerService.hideNext();
    this.hidePreviousButton = this.orderPagerService.hidePrevious();
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public getFullAddress(customer: Customer): string {
    if (!customer) {
      return '';
    }
    const fullAddress =
      customer.address.address +
      ', ' +
      customer.address.city +
      ', ' +
      customer.address.state +
      ' ' +
      customer.address.zip;
    return fullAddress;
  }

  public onBackLinkClicked() {
    this.orderPagerService.goBack();
  }

  public onCustomerClick() {
    this.router.navigate(['admin/customers', this.customer._id]);
  }

  public onSiteClick() {
    this.router.navigate(['admin/sites', this.site._id]);
  }

  public onDelete = async () => {
    // if ((await this.orderService.deleteOrder(this.orderId))=== false) {
    //   return;
    // }
    // await TimerUtil.delay(1000);
    // this.orderPagerService.goBack();
  }

  public onEdit = async () => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    const editedOrder = await this.orderService.editOrder(this.orderId);
    this.dialogIsOpen = false;
    if (editedOrder == null) {
      return;
    }
    await this.loadData(this.orderId);
  }

  private async loadData(orderId: string) {
    this.order = await this.orderService.getOrder(orderId);

    if (!this.order) {
      this.router.navigate(['admin', 'orders']);
      return;
    }

    this.customer = await this.customerService.getCustomer(
      this.order.customerId
    );
    this.site = await this.siteService.getSite(this.order.siteId);
    this.isLoading = false;
  }

  public onDownload() {
    this.orderService.downloadOrderFile(this.order._id);
  }

  public onDownloadSourceFile() {
    this.orderService.downloadOrderSourceFile(this.order._id);
  }

  public onNextOrder = async () => {
    const nextOrderId = await this.orderPagerService.getNextOrderId();
    if (!nextOrderId) {
      this.hideNextButton = true;
      return;
    }
    this.router.navigate(['admin/orders', nextOrderId]);
    this.hideNextButton = this.orderPagerService.hideNext();
    this.hidePreviousButton = this.orderPagerService.hidePrevious();
  }

  public onNotification = async (notification: WebSocketNotification) => {
    // if (!notification.data || notification.data.orderId !== this.orderId) {
    //   return;
    // }
    // switch (notification.type) {
    //   case 'order-file-import-complete':
    //     await TimerUtil.delay(3000);
    //     this.loadData(this.orderId);
    //     break;
    //   case 'order-file-import-progress':
    //     this.order.status = notification.message;
    //     const file = Order.getFile(this.order, notification.data.fileId);
    //     if (file) {
    //       file.status = notification.message;
    //     }
    //     break;
    //   case 'order-api-dataset-import-complete':
    //     await TimerUtil.delay(3000);
    //     this.loadData(this.orderId);
    //     break;
    //   case 'order-api-dataset-import-progress':
    //     this.order.status = notification.message;
    //     const apiDataset = Order.getApiDataset(this.order, notification.data.apiDatasetId);
    //    if (apiDataset) {
    //       apiDataset.status = notification.message;
    //     }
    //    break;
    // }
  }

  public onPreviousOrder = async () => {
    const previousOrderId = await this.orderPagerService.getPreviousOrderId();
    if (!previousOrderId) {
      return;
    }
    this.router.navigate(['admin/orders', previousOrderId]);
    this.hideNextButton = this.orderPagerService.hideNext();
    this.hidePreviousButton = this.orderPagerService.hidePrevious();
  }

  public toYesNo(value: boolean): string {
    return value === true ? 'Yes' : 'No';
  }
}
