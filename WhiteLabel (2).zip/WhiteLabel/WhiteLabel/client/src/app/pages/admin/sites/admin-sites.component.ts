import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  ViewChild
} from '@angular/core';
import { NavigationState } from '../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../services/navigation/navigation.service';
import {
  BaseComponent,
  GetOptions,
  SearchResultFacet,
  SearchResultFacetItem
} from 'leatherman';
import { UserSettingsService } from '../../../services/user-settings/user-settings.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ListState } from '../../../models/list-state/list-state.model';
import { Sort } from '@angular/material/sort';
import { NotificationService } from '../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../services/notification/_models/notification.model';
import { MdcMenu, MdcIconRegistry } from '@angular-mdc/web';
import { SiteService } from 'src/app/services/site/site.service';
import { SolrSite } from 'src/app/models/site/solr-site.model';
import { TimerUtil } from 'src/app/util/timer/timer.util';
import { SitePagerService } from 'src/app/services/pager/site-pager.service';

@Component({
  selector: 'app-admin-sites',
  templateUrl: './admin-sites.component.html',
  styleUrls: ['./admin-sites.component.scss']
})
export class AdminSitesComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  // Public properties
  public sites: SolrSite[] = [];
  public numFound = 0;
  public facets: SearchResultFacet[] = [];
  public pageState: ListState = new ListState();
  public userRole: string;
  public menuSiteId: string;
  public displayedColumns: string[] = [
    'dateCreated',
    'name',
    'displayName',
    'url',
    'actions'
  ];

  private navigationState: NavigationState;
  @ViewChild('otherMenu', { static: false })
  private otherMenu: MdcMenu;
  private dialogIsOpen: boolean; 

  // constructor
  constructor(
    private sitePagerService: SitePagerService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private siteService: SiteService,
    private userSettingsService: UserSettingsService,
    private notificationService: NotificationService,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Sites';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = false;
    this.activatedRoute.queryParams.subscribe(async params => {
      this.isLoading = true;
      await this.initializePageState(params);
      await this.loadData();
      this.isLoading = false;
      this.isInitialized = true;
    });
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public onBackLinkClicked() {
    this.router.navigate(['admin/dashboard']);
  }

  // onDelete
  public onDelete = async (event: any, id: string) => {
    event.stopPropagation();
    if ((await this.siteService.deleteSite(id)) === false) {
      return;
    }
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  public onFaq = async (event: any, site: SolrSite) => {
    event.stopPropagation();
    const currentSiteIndex = this.getSiteIndex(site._id);
    this.sitePagerService.initialize(
      currentSiteIndex,
      this.pageState,
      this.sites
    );
    this.router.navigate([`admin/sites/${site._id}/faq`]);
  }

  public onOrders = async (event: any, site: SolrSite) => {
    event.stopPropagation();
    const currentSiteIndex = this.getSiteIndex(site._id);
    this.sitePagerService.initialize(
      currentSiteIndex,
      this.pageState,
      this.sites
    );
    this.router.navigate([`admin/sites/${site._id}/orders`]);
  }

  public async onFacetItemClicked(facetItem: SearchResultFacetItem) {
    this.pageState.filter = facetItem.query;
    this.pageState.currentPage = 1;
    this.pageState.sortColumn = '';
    this.updateUrl();
    await this.loadData();
  }

  public async onNewSite() {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    const newSite = await this.siteService.newSite();
    this.dialogIsOpen = false;
    if (newSite) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => {
  }

  public onSetup = async (event: any, site: SolrSite) => {
    event.stopPropagation();
    const currentSiteIndex = this.getSiteIndex(site._id);
    this.sitePagerService.initialize(
      currentSiteIndex,
      this.pageState,
      this.sites
    );
    this.router.navigate([`admin/sites/${site._id}/setup`]);
  }

  // onOtherMenu
  public openOtherMenu = async (event: any, siteId: string) => {
    event.stopPropagation();
    this.menuSiteId = siteId;
    this.otherMenu.fixed = true;
    this.otherMenu.anchorElement = event.target;
    this.otherMenu.open = true;
  }

  // onPageChanged
  public async onPageChanged(pageNumber: number) {
    this.pageState.currentPage = pageNumber;
    this.updateUrl();
    await this.loadData();
    window.scrollTo(0, 0);
  }

  public onPolicies = async (event: any, site: SolrSite) => {
    event.stopPropagation();
    const currentSiteIndex = this.getSiteIndex(site._id);
    this.sitePagerService.initialize(
      currentSiteIndex,
      this.pageState,
      this.sites
    );
    this.router.navigate([`admin/sites/${site._id}/policies/terms-of-service`]);
  }

  public onRowClick(site: SolrSite) {
    const currentSiteIndex = this.getSiteIndex(site._id);
    this.sitePagerService.initialize(
      currentSiteIndex,
      this.pageState,
      this.sites
    );
    this.router.navigate([`/admin/sites/${site._id}/orders`]);
  }

  // onSearchTextChanged
  public async onSearchTextChanged(query: any) {
    this.pageState.query = query;
    this.updateUrl();
    await this.loadData();
  }

  // onSortChange
  public async onSortChange(sort: Sort) {
    this.pageState.sortColumn = sort.active;
    this.pageState.sortAscending = sort.direction === 'desc' ? false : true;
    this.updateUrl();
    await this.loadData();
    const userSettings = await this.userSettingsService.getUserSettings();
    userSettings.sites.sortColumn = this.pageState.sortColumn;
    userSettings.sites.sortAscending = this.pageState.sortAscending;
    await this.userSettingsService.updateUserSettings(userSettings);
  }

  // getOptions
  private getOptions(): GetOptions {
    const options = new GetOptions(
      this.pageState.currentPage,
      this.pageState.pageSize
    );
    if (this.pageState.sortColumn) {
      options.setSort(this.pageState.sortColumn, this.pageState.sortAscending);
    }
    options.query = this.encodeURIComponent(this.pageState.query);
    options.filter = this.pageState.filter;
    return options;
  }

  // getSiteIndex
  private getSiteIndex(siteId: string): number {
    const siteIndex = this.sites.findIndex(p => p._id === siteId);
    return siteIndex;
  }

  // initializePageState
  private async initializePageState(queryParams: any) {
    const userSettings = await this.userSettingsService.getUserSettings();
    this.pageState.query = this.decodeURIComponent(queryParams.q);
    this.pageState.filter = queryParams.f;
    if (queryParams.sort) {
      this.pageState.sortColumn = queryParams.sort;
    } else if (userSettings.sites && userSettings.sites.sortColumn) {
      this.pageState.sortColumn = userSettings.sites.sortColumn;
    } else {
      this.pageState.sortColumn = 'relevance';
    }
    if (queryParams.site) {
      this.pageState.sortAscending =
        queryParams.site.toLowerCase() === 'desc' ? false : true;
    } else if (
      userSettings.sites &&
      userSettings.sites.sortAscending !== undefined
    ) {
      this.pageState.sortAscending = userSettings.sites.sortAscending;
    } else if (queryParams.sort === undefined) {
      this.pageState.sortAscending = false;
    } else {
      this.pageState.sortAscending = true;
    }
    if (queryParams.p) {
      const currentPage = parseInt(queryParams.p, 10);
      this.pageState.currentPage = currentPage > 0 ? currentPage : 1;
    } else {
      this.pageState.currentPage = 1;
    }
    this.pageState.pageSize = 25;
  }

  // loadData
  private async loadData() {
    const options = this.getOptions();
    const searchResultsContainer = await this.siteService.getSites(options);
    this.numFound = searchResultsContainer.meta.numFound;
    this.sites = searchResultsContainer.data;
    this.facets = searchResultsContainer.facets;
    this.pageState.pageCount = GetOptions.calculatePageCount(
      searchResultsContainer.meta.numFound,
      this.pageState.pageSize
    );
    this.pageState.rowCount = searchResultsContainer.meta.numFound;
  }

  // updateUrl
  private updateUrl() {
    const queryParams: any = {};
    if (this.pageState.query) {
      queryParams.q = this.encodeURIComponent(this.pageState.query);
    }
    if (this.pageState.filter) {
      queryParams.f = this.pageState.filter;
    }

    if (!this.pageState.sortColumn) {
      queryParams.sort = 'relevance';
      queryParams.site = 'asc';
    } else if (this.pageState.sortColumn !== 'relevance') {
      queryParams.sort = this.pageState.sortColumn;
      queryParams.site = this.pageState.sortAscending === true ? 'asc' : 'desc';
    }

    queryParams.p = this.pageState.currentPage;
    this.router.navigate(['/admin/sites'], {
      queryParams
    });
  }
}
