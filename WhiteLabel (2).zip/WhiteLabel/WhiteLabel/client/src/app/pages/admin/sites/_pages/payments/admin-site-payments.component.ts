import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  ViewChild
} from '@angular/core';
import {
  BaseComponent,
  CollectionUtil,
  GetOptions,
  SearchResultFacet,
  SearchResultFacetItem,
  DialogButton
} from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { Sort } from '@angular/material/sort';
import { MdcMenu, MdcIconRegistry } from '@angular-mdc/web';
import { OrderService } from 'src/app/services/order/order.service';
import { SiteService } from 'src/app/services/site/site.service';
import { SolrOrder } from 'src/app/models/order/solr-order.model';
import { ListState } from 'src/app/models/list-state/list-state.model';
import { NavigationState } from 'src/app/services/navigation/_models/navigation-state.model';
import { NavigationService } from 'src/app/services/navigation/navigation.service';
import { UserSettingsService } from 'src/app/services/user-settings/user-settings.service';
import { NotificationService } from 'src/app/services/notification/notification.service';
import { TimerUtil } from 'src/app/util/timer/timer.util';
import { WebSocketNotification } from 'src/app/services/notification/_models/notification.model';
import { Site } from 'src/app/models/site/site.model';
import { SitePagerService } from 'src/app/services/pager/site-pager.service';
import { GetOrderOptions } from 'src/app/models/order/get-order-options.model';
import { AdminSiteOrderPagerService } from 'src/app/services/pager/admin-site-order-pager.service';

@Component({
  selector: 'app-admin-site-payments',
  templateUrl: './admin-site-payments.component.html',
  styleUrls: ['./admin-site-payments.component.scss']
})
export class AdminSitePaymentsComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  // Public properties
  public orders: SolrOrder[] = [];
  public numFound = 0;
  public facets: SearchResultFacet[] = [];
  public pageState: ListState = new ListState();
  public userRole: string;
  public hideNextButton = true;
  public hidePreviousButton = true;
  public displayedColumns: string[] = [
    'orderNumber',
    'dateCreated',
    'status',
    'addressCount',
    'matchCount',
    'matchPercent',
    'actions'
  ];
  private dialogIsOpen: boolean;
  private navigationState: NavigationState;
  @ViewChild('otherMenu', { static: false })
  public site: Site;
  public siteId: string;
  public siteName: string;
  private otherMenu: MdcMenu;

  // constructor
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private orderService: OrderService,
    private siteService: SiteService,
    private orderPagerService: AdminSiteOrderPagerService,
    private userSettingsService: UserSettingsService,
    private notificationService: NotificationService,
    private sitePagerService: SitePagerService,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Site';
    this.navigationState.selectedTabIndex = 1;
    this.navigationState.addTab(
      'Orders',
      `/admin/sites/${this.siteId}/orders`,
      'attach_money'
    );
    this.navigationState.addTab(
      'Payments',
      `/admin/sites/${this.siteId}/payments`,
      'credit_card'
    );
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    // this.userRole = this.userService._getPrimaryUserRole();
    this.isInitialized = false;
    this.activatedRoute.params.subscribe(async params => {
      this.siteId = params.siteId;

      this.navigationState = new NavigationState();
      this.navigationState.title = 'Site';
      this.navigationState.selectedTabIndex = 1;
      this.navigationState.addTab(
        'Orders',
        `/admin/sites/${this.siteId}/orders`,
        'attach_money'
      );
      this.navigationState.addTab(
        'Payments',
        `/admin/sites/${this.siteId}/payments`,
        'credit_card'
      );
      this.navigationService.updateNavigationState(this.navigationState);

      this.isLoading = true;
      await this.initializePageState(params);
      await this.loadData();
      this.isLoading = false;
      this.isInitialized = true;

      this.hideNextButton = this.sitePagerService.hideNext();
      this.hidePreviousButton = this.sitePagerService.hidePrevious();
    });
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public onBackLinkClicked() {
    this.sitePagerService.goBack();
  }

  // onCloseOrder
  public onCloseOrder = async (event: any, id: string) => {
    event.preventDefault();
    const order = await this.orderService.getOrder(id);
    order.status = 'Closed';
    await this.orderService.updateOrder(order);
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  // onDelete
  public onDelete = async (event: any, id: string) => {
    event.stopPropagation();
    if ((await this.orderService.deleteOrder(id)) === false) {
      return;
    }
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  // onEdit
  public onEdit = async (event: any, id: string) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    // const order = CollectionUtil.findById(this.orders, id);
    // if (!order) {
    //   return;
    // }
    const editedOrder = await this.orderService.editOrder(id);
    this.dialogIsOpen = false;
    if (editedOrder) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public async onFacetItemClicked(facetItem: SearchResultFacetItem) {
    this.pageState.filter = facetItem.query;
    this.pageState.currentPage = 1;
    this.pageState.sortColumn = '';
    this.updateUrl();
    await this.loadData();
  }

  // onNew
  public onNew = async () => {
    // const newOrder = await this.orderService.newOrder();
    // if (newOrder) {
    //   await TimerUtil.delay(1000);
    //   await this.loadData();
    //   // this.router.navigate(['orders', newOrder._id]);
    // }
  }

  public onNextSite = async () => {
    const nextSiteId = await this.sitePagerService.getNextSiteId();
    if (!nextSiteId) {
      this.hideNextButton = true;
      return;
    }
    this.router.navigate(['admin/sites', nextSiteId, 'orders']);
    this.hideNextButton = this.sitePagerService.hideNext();
    this.hidePreviousButton = this.sitePagerService.hidePrevious();
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => {

  }

  public onPreviousSite = async () => {
    const previousSiteId = await this.sitePagerService.getPreviousSiteId();
    if (!previousSiteId) {
      return;
    }
    this.router.navigate(['admin/sites', previousSiteId, 'orders']);
    this.hideNextButton = this.sitePagerService.hideNext();
    this.hidePreviousButton = this.sitePagerService.hidePrevious();
  }

  // onOtherMenu
  public openOtherMenu = async (event: any, orderId: string) => {
    event.stopPropagation();
    this.otherMenu.fixed = true;
    this.otherMenu.anchorElement = event.target;
    this.otherMenu.open = true;
  }

  // onPageChanged
  public async onPageChanged(pageNumber: number) {
    this.pageState.currentPage = pageNumber;
    this.updateUrl();
    await this.loadData();
    window.scrollTo(0, 0);
  }

  public onRowClick(order: SolrOrder) {
    const currentOrderIndex = this.getOrderIndex(order._id);
    this.orderPagerService.initialize(
      currentOrderIndex,
      this.pageState,
      this.orders,
      this.siteId
    );
    this.router.navigate([`/admin/sites/${this.siteId}/orders/${order._id}`]);
  }

  // onSearchTextChanged
  public async onSearchTextChanged(query: any) {
    this.pageState.query = query;
    this.updateUrl();
    await this.loadData();
  }

  // onSortChange
  public async onSortChange(sort: Sort) {
    this.pageState.sortColumn = sort.active;
    this.pageState.sortAscending = sort.direction === 'desc' ? false : true;
    this.updateUrl();
    await this.loadData();
    const userSettings = await this.userSettingsService.getUserSettings();
    userSettings.orders.sortColumn = this.pageState.sortColumn;
    userSettings.orders.sortAscending = this.pageState.sortAscending;
    await this.userSettingsService.updateUserSettings(userSettings);
  }

  // getOptions
  private getOptions(): GetOrderOptions {
    const options = new GetOrderOptions(
      this.pageState.currentPage,
      this.pageState.pageSize
    );
    if (this.pageState.sortColumn) {
      options.setSort(this.pageState.sortColumn, this.pageState.sortAscending);
    }
    options.query = this.encodeURIComponent(this.pageState.query);
    options.filter = this.pageState.filter;
    return options;
  }

  // getOrderIndex
  private getOrderIndex(orderId: string): number {
    const orderIndex = this.orders.findIndex(p => p._id === orderId);
    return orderIndex;
  }

  // initializePageState
  private async initializePageState(queryParams: any) {
    const userSettings = await this.userSettingsService.getUserSettings();
    this.pageState.query = this.decodeURIComponent(queryParams.q);
    this.pageState.filter = queryParams.f;
    if (queryParams.sort) {
      this.pageState.sortColumn = queryParams.sort;
    } else if (userSettings.orders && userSettings.orders.sortColumn) {
      this.pageState.sortColumn = userSettings.orders.sortColumn;
    } else {
      this.pageState.sortColumn = 'relevance';
    }
    if (queryParams.order) {
      this.pageState.sortAscending =
        queryParams.order.toLowerCase() === 'desc' ? false : true;
    } else if (
      userSettings.orders &&
      userSettings.orders.sortAscending !== undefined
    ) {
      this.pageState.sortAscending = userSettings.orders.sortAscending;
    } else if (queryParams.sort === undefined) {
      this.pageState.sortAscending = false;
    } else {
      this.pageState.sortAscending = true;
    }
    if (queryParams.p) {
      const currentPage = parseInt(queryParams.p, 10);
      this.pageState.currentPage = currentPage > 0 ? currentPage : 1;
    } else {
      this.pageState.currentPage = 1;
    }
    this.pageState.pageSize = 25;
  }

  // loadData
  private async loadData() {
    this.site = await this.siteService.getSite(this.siteId);
    this.siteName = this.site.displayName;
    const options = this.getOptions();
    const searchResultsContainer = await this.orderService.getOrders(options);
    this.numFound = searchResultsContainer.meta.numFound;
    this.orders = searchResultsContainer.data;
    this.facets = searchResultsContainer.facets;
    this.pageState.pageCount = GetOptions.calculatePageCount(
      searchResultsContainer.meta.numFound,
      this.pageState.pageSize
    );
    this.pageState.rowCount = searchResultsContainer.meta.numFound;
  }

  // updateUrl
  private updateUrl() {
    const queryParams: any = {};
    if (this.pageState.query) {
      queryParams.q = this.encodeURIComponent(this.pageState.query);
    }
    if (this.pageState.filter) {
      queryParams.f = this.pageState.filter;
    }

    if (!this.pageState.sortColumn) {
      queryParams.sort = 'relevance';
      queryParams.order = 'asc';
    } else if (this.pageState.sortColumn !== 'relevance') {
      queryParams.sort = this.pageState.sortColumn;
      queryParams.order =
        this.pageState.sortAscending === true ? 'asc' : 'desc';
    }

    queryParams.p = this.pageState.currentPage;
    this.router.navigate(['/orders'], {
      queryParams
    });
  }
}
