import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { NavigationState } from '../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../services/navigation/navigation.service';
import { BaseComponent } from 'leatherman';
import { Router } from '@angular/router';
import { NotificationService } from '../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../services/notification/_models/notification.model';
import { MdcIconRegistry } from '@angular-mdc/web';
import { TimerUtil } from 'src/app/util/timer/timer.util';
import { UserService } from 'src/app/services/user/user.service';
import { User } from 'src/app/models/user/user.model';
import { SiteService } from 'src/app/services/site/site.service';
import { InfoDialogService } from 'src/app/dialogs/info/info-dialog.service';

@Component({
  selector: 'app-admin-account',
  templateUrl: './admin-account.component.html',
  styleUrls: ['./admin-account.component.scss']
})
export class AdminAccountComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public user: User;
  private navigationState: NavigationState;
  private dialogIsOpen: boolean; 
  // constructor
  constructor(
    private router: Router,
    private userService: UserService,
    private siteService: SiteService,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    iconRegistry: MdcIconRegistry,
    private infoDialogService: InfoDialogService
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Account';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = true;
    this.isLoading = false;
    this.user = await this.userService._getCurrentUser();
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public async loadData() {
    this.user = await this.userService._getCurrentUser();
  }

  public onBackLinkClicked() {
    this.router.navigate(['admin/dashboard']);
  }

  public onEditPassword = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const result = await this.userService.changeUserPassword(this.user._id);
    this.dialogIsOpen = false;
    if (result === true) {
      await this.infoDialogService.openInfoDialog('Change Password', 'Your password was changed successfully.');
    } else if (result === false) {
      await this.infoDialogService.openInfoDialog('Change Password', 'The password update failed.');
    }
  }

  public onEditUserName = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedUser = await this.userService.editUserName(this.user._id);
    this.dialogIsOpen = false;
    if (editedUser) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };
}
