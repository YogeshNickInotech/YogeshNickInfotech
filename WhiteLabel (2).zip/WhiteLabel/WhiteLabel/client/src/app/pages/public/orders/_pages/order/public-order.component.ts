import { Component, OnInit, Inject, AfterViewInit } from '@angular/core';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig
} from 'leatherman';
import { OrderService } from '../../../../../services/order/order.service';
import { Order } from '../../../../../models/order/order.model';
import { NavigationState } from '../../../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../../../services/navigation/navigation.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from '../../../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../../../services/notification/_models/notification.model';
import { DOCUMENT } from '@angular/common';
import { UserService } from 'src/app/services/user/user.service';
import { Customer } from 'src/app/models/customer/customer.model';
import { PublicOrderPagerService } from 'src/app/services/pager/public-order-pager.service';
import { OrderProperty } from 'src/app/models/order-property/order-property.model';
import { OrderPropertyRequest } from 'src/app/models/order/_submodels/order-property-request.model';

@Component({
  selector: 'app-public-order',
  templateUrl: './public-order.component.html',
  styleUrls: ['./public-order.component.scss']
})
export class PublicOrderComponent extends BaseComponent
  implements OnInit, AfterViewInit {
  private navigationState: NavigationState;
  public orderId: string;
  public order: Order;
  public request: OrderPropertyRequest;
  public property: OrderProperty;
  public customer: Customer;
  public userRole: string;
  public hideNextButton = true;
  public hidePreviousButton = true;
  public batchOrder = false;
  private dialogIsOpen: boolean;
  // constructor
  constructor(
    private userService: UserService,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private orderService: OrderService,
    @Inject(LeathermanAppConfigInjectionToken)
    public config: ILeathermanAppConfig,
    private notificationService: NotificationService,
    private router: Router,
    @Inject(DOCUMENT) private document: Document,
    private orderPagerService: PublicOrderPagerService
  ) {
    super();

    this.navigationState = new NavigationState();
    this.navigationState.title = 'Order';
    this.navigationService.updateNavigationState(this.navigationState);
  }
  

  // ngOnInit
  public async ngOnInit() {
    this.userRole = this.userService._getPrimaryUserRole();
    this.activatedRoute.params.subscribe(async params => {
      this.orderId = params.orderId;
      await this.loadData(this.orderId);
      this.isInitialized = true;
    });
    this.hideNextButton = this.orderPagerService.hideNext();
    this.hidePreviousButton = this.orderPagerService.hidePrevious();
  }
  

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public formatPhoneNumber(phoneNumber: string) {
    const formattedPhoneNumber = phoneNumber.substr(0, 3) + '-' + phoneNumber.substr(3, 3) + '-' + phoneNumber.substr(6, 4);
    return formattedPhoneNumber;
  }

  public getFullAddress(customer: Customer): string {
    if (!customer) {
      return '';
    }
    const fullAddress =
      customer.address.address +
      ', ' +
      customer.address.city +
      ', ' +
      customer.address.state +
      ' ' +
      customer.address.zip;
    return fullAddress;
  }

  public getResponseMailingAddress(): string {
    const address = this.property.owner.mailingAddress.address + ', '
      + this.property.owner.mailingAddress.city + ', '
      + this.property.owner.mailingAddress.state + ' '
      + this.property.owner.mailingAddress.zip + ' ';
    return address;
  }

  public getRequestName(): string {
    if (this.request) {
      const name = this.request.firstName + ' ' + this.request.lastName;
      return name;
    }
    return '';
  }

  public getRequestMailingAddress(): string {
    const address = this.request.mailingAddress + ', '
      + this.request.mailingCity + ', '
      + this.request.mailingState + ' '
      + this.request.mailingZip + ' ';
    return address;
  }

  public getRequestPropertyAddress(): string {
    if (this.request) {
      const address = this.request.address + ', '
        + this.request.city + ', '
        + this.request.state + ' '
        + this.request.zip + ' ';
      return address;
    }
    return '';
  }

  public getResponseName(): string {
    const name = this.property.owner.name.first + ' ' + this.property.owner.name.last;
    return name;
  }
  public hasRequestMailingAddress(): boolean {
    if (this.request && this.request.mailingAddress) {
      return true;
    }
    return false;
  }

  public hasResponseEmails(): boolean {
    if (this.property.owner.emails && this.property.owner.emails.length > 0) {
      return true;
    }
    return false;
  }

  public hasResponseMailingAddress(): boolean {
    if (this.property.owner.mailingAddress && this.property.owner.mailingAddress.address) {
      return true;
    }
    return false;
  }

  public hasResponsePhoneNumbers(): boolean {
    if (this.property.owner.phones && this.property.owner.phones.length > 0) {
      return true;
    }
    return false;
  }

  public onBackLinkClicked() {
    this.orderPagerService.goBack();
  }

  public onDelete = async () => {
    // if ((await this.orderService.deleteOrder(this.orderId))=== false) {
    //   return;
    // }
    // await TimerUtil.delay(1000);
    // this.orderPagerService.goBack();
  }

  public onDownload() {
    this.orderService.downloadOrderFile(this.order._id);
  }

  public onDownloadSourceFile() {
    this.orderService.downloadOrderSourceFile(this.order._id);
  }

  public onEdit = async () => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    const editedOrder = await this.orderService.editOrder(this.orderId);
    this.dialogIsOpen = false;
    if (editedOrder == null) {
      return;
    }
    await this.loadData(this.orderId);
  }

  private async loadData(orderId: string) {
    this.order = await this.orderService.getOrder(orderId);

    if (!this.order) {
      this.router.navigate(['app', 'orders']);
      return;
    }

    if (this.order.meta.requestCount > 1) {
      this.batchOrder = true;
    }
    this.request = this.order.requests[0];
    this.property = this.order.properties[0];
    this.isLoading = false;
  }

  public onNextOrder = async () => {
    const nextOrderId = await this.orderPagerService.getNextOrderId();
    if (!nextOrderId) {
      this.hideNextButton = true;
      return;
    }
    this.router.navigate(['app', 'orders', nextOrderId]);
    this.hideNextButton = this.orderPagerService.hideNext();
    this.hidePreviousButton = this.orderPagerService.hidePrevious();
  }

  public onNotification = async (notification: WebSocketNotification) => {
    // if (!notification.data || notification.data.orderId !== this.orderId) {
    //   return;
    // }
    // switch (notification.type) {
    //   case 'order-file-import-complete':
    //     await TimerUtil.delay(3000);
    //     this.loadData(this.orderId);
    //     break;
    //   case 'order-file-import-progress':
    //     this.order.status = notification.message;
    //     const file = Order.getFile(this.order, notification.data.fileId);
    //     if (file) {
    //       file.status = notification.message;
    //     }
    //     break;
    //   case 'order-api-dataset-import-complete':
    //     await TimerUtil.delay(3000);
    //     this.loadData(this.orderId);
    //     break;
    //   case 'order-api-dataset-import-progress':
    //     this.order.status = notification.message;
    //     const apiDataset = Order.getApiDataset(this.order, notification.data.apiDatasetId);
    //    if (apiDataset) {
    //       apiDataset.status = notification.message;
    //     }
    //    break;
    // }
  }

  public onPreviousOrder = async () => {
    const previousOrderId = await this.orderPagerService.getPreviousOrderId();
    if (!previousOrderId) {
      return;
    }
    this.router.navigate(['app', 'orders', previousOrderId]);
    this.hideNextButton = this.orderPagerService.hideNext();
    this.hidePreviousButton = this.orderPagerService.hidePrevious();
  }

  public toYesNo(value: boolean): string {
    return value === true ? 'Yes' : 'No';
  }
}
