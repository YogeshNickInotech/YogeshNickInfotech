import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { NavigationState } from '../../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../../services/navigation/navigation.service';
import { BaseComponent } from 'leatherman';
import { ActivatedRoute, Router, RouterStateSnapshot } from '@angular/router';
import { NotificationService } from '../../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../../services/notification/_models/notification.model';
import { MdcIconRegistry } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { OrderRequestService } from 'src/app/services/order-request/order-request.service';
import { STATES, State } from '../../../../constants/states.constants';
import { OrderPropertyRequest } from 'src/app/models/order/_submodels/order-property-request.model';
import { OrderRequest } from 'src/app/models/order-request/order-request.model';
import { User } from 'src/app/models/user/user.model';
import { UserService } from 'src/app/services/user/user.service';
import { Site } from 'src/app/models/site/site.model';
import { SiteService } from 'src/app/services/site/site.service';

@Component({
  selector: 'app-public-single-skip-trace',
  templateUrl: './public-single-skip-trace.component.html',
  styleUrls: ['./public-single-skip-trace.component.scss']
})
export class PublicSingleSkipTraceComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public searchForm: FormGroup;
  public states: State[] = STATES;
  private navigationState: NavigationState;
  private user: User;
  private siteId: string;
  private orderRequest: OrderRequest;
  private site: Site;

  // constructor
  constructor(
    private userService: UserService,
    private siteService: SiteService,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private router: Router,
    private orderRequestService: OrderRequestService,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Single Skip Trace';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    this.isLoading = true;
    await this.loadData();
    this.initForm();
    this.isLoading = false;
    this.isInitialized = true;
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public onBackLinkClicked() {
    this.router.navigate(['app/dashboard']);
  }

  public onNext() {
    this.validateForm();

    if (this.searchForm.invalid) {
      return;
    }

    const request = new OrderPropertyRequest();

    request.firstName = this.searchForm.get('firstName').value;
    request.lastName = this.searchForm.get('lastName').value;

    request.address = this.searchForm.get('address').value;
    request.city = this.searchForm.get('city').value;
    request.state = this.searchForm.get('state').value;
    request.zip = this.searchForm.get('zip').value;

    request.mailingAddress = this.searchForm.get('mailingAddress').value;
    request.mailingCity = this.searchForm.get('mailingCity').value;
    request.mailingState = this.searchForm.get('mailingState').value;
    request.mailingZip = this.searchForm.get('mailingZip').value;

    this.orderRequest.requests = [];
    this.orderRequest.requests.push(request);

    this.orderRequestService.cacheSingleRequest(this.orderRequest);

    this.router.navigate(['app/single-skip-trace/2']);
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  private initForm() {
    this.orderRequest = this.orderRequestService.getSingleRequest();
    if (!this.orderRequest) {
      this.orderRequest = new OrderRequest();
    }

    this.orderRequest.siteId = this.siteId;
    this.orderRequest.customerId = this.user._id;

    this.orderRequest.cost.unitCost = this.site.pricing.defaultPrice;
    this.orderRequest.cost.extendedCost = this.site.pricing.defaultPrice;

    let request: OrderPropertyRequest;
    if (this.orderRequest.requests.length > 0) {
      request = this.orderRequest.requests[0];
    } else {
      request = new OrderPropertyRequest();
    }
    this.orderRequest.requestCount = 1;

    this.searchForm = new FormGroup({
      firstName: new FormControl(
        request.firstName, [Validators.required]),
      lastName: new FormControl(
        request.lastName, [Validators.required]),
      address: new FormControl(
        request.address, [Validators.required]),
      city: new FormControl(
        request.city, [Validators.required]),
      state: new FormControl(
        request.state, [Validators.required]),
      zip: new FormControl(
        request.zip, [Validators.required]),
      mailingAddress: new FormControl(
        request.mailingAddress),
      mailingCity: new FormControl(
        request.mailingCity),
      mailingState: new FormControl(
        request.mailingState),
      mailingZip: new FormControl(
        request.mailingZip)
    });
  }

  private async loadData() {
    this.user = await this.userService.getCurrentUser();
    this.siteId = this.user.siteId;
    this.site = await this.siteService.getSite(this.siteId);
  }

  private validateForm(): boolean {
    // if (!this.siteForm.valid) {
    this.validateAllFormFields(this.searchForm);
    this.searchForm.markAsDirty();
    //   return false;
    // }

    return true;
  }

  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
