import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { NavigationState } from '../../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../../services/navigation/navigation.service';
import { BaseComponent } from 'leatherman';
import { Router } from '@angular/router';
import { NotificationService } from '../../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../../services/notification/_models/notification.model';
import { MdcIconRegistry } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { OrderRequestService } from 'src/app/services/order-request/order-request.service';
import { OrderService } from 'src/app/services/order/order.service';
import { Order } from 'src/app/models/order/order.model';
import { UserService } from 'src/app/services/user/user.service';
import { User } from 'src/app/models/user/user.model';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { Customer } from 'src/app/models/customer/customer.model';
import { Observable } from 'rxjs';
import * as XLSX from 'xlsx';
import * as Papa from 'papaparse';
import { OrderDataService } from 'src/app/services/order/order-data.service';
import { OrderRequest } from 'src/app/models/order-request/order-request.model';
import { SitePricing } from 'src/app/models/site/_submodels/site-pricing.model';
import { Site } from 'src/app/models/site/site.model';
import { SiteService } from 'src/app/services/site/site.service';
import { InfoDialogService } from 'src/app/dialogs/info/info-dialog.service';

export class ColumnHeader {
  public index: number;
  public name: string;
}

@Component({
  selector: 'app-public-batch-skip-trace',
  templateUrl: './public-batch-skip-trace.component.html',
  styleUrls: ['./public-batch-skip-trace.component.scss']
})
export class PublicBatchSkipTraceComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  private navigationState: NavigationState;
  private user: User;
  private customer: Customer;
  private orderId: string;
  private siteId: string;
  private orderRequest: OrderRequest;
  private site: Site;

  public uploadProgress: Observable<number>;
  public file: File = null;
  public mapForm: FormGroup;
  public columns: ColumnHeader[] = [];
  public usedIndexes: number[] = [];
  public SubMainArray = [];
  public columns_FirstName = [];
  public columns_LastName = [];
  public columns_PropertyAddress = [];
  public columns_Input_Mailing_Address=[];
  public Input_Mailing_Address="-1";
  public ItemSelected = [];
  public FirstName = "-1";
  public LastName = "-1";
  public PropertyAddress = "-1";
  public currentPage = 'page1';
  public uploadComplete = false;
  public firstName = "-1";
  public lastName ="-1";
  // public  _usedIndexes = [];

  // constructor
  constructor(
    private infoDialogService: InfoDialogService,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private router: Router,
    private orderRequestService: OrderRequestService,
    private orderService: OrderService,
    public orderDataService: OrderDataService,
    private userService: UserService,
    private customerService: CustomerService,
    private siteService: SiteService,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Batch Skip Trace';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    this.isLoading = true;
    await this.loadData();
    this.initForm();
    this.isLoading = false;
    this.isInitialized = true;
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public getProgressValue(progress: number): number {
    const progressPercent = progress / 100;
    return progressPercent;
  } 
  
   public changedSourc(e){
    alert("2");
     let _usedIndexes = [];
    if(this.mapForm.value.firstName != -1){
      _usedIndexes.push(this.mapForm.value.firstName)
     }
     
     console.log( "check",this.mapForm.value.lastName)

     if(this.mapForm.value.lastName!= -1){
      _usedIndexes.push(this.mapForm.value.lastName)
     }
     if(this.mapForm.value.propertyAddress!= -1){
      _usedIndexes.push(this.mapForm.value.propertyAddress)
     }
    
     if(this.mapForm.value.propertyCity!= -1){
      _usedIndexes.push()
     }

     if(this.mapForm.value.propertyState!= -1){
      _usedIndexes.push(this.mapForm.value.propertyState)
     }
     if(this.mapForm.value.propertyZip!= -1){
      _usedIndexes.push(this.mapForm.value.propertyZip)
     }
     if(this.mapForm.value.mailingAddress!= -1){
      _usedIndexes.push(this.mapForm.value.mailingAddress)
     }
     if(this.mapForm.value.mailingState!= -1){
      _usedIndexes.push(this.mapForm.value.mailingState)
     }
     if(this.mapForm.value.mailingZip!= -1){
      _usedIndexes.push(this.mapForm.value.mailingZip)
     }
     this.usedIndexes = _usedIndexes;
     console.log(JSON.stringify(this.mapForm.value.mailingZip))

    
  }

  public getSelectSource(fieldName){
   // debugger
    const selectedIndex = this.mapForm.get(fieldName).value;
   console.log("this",selectedIndex)
    return this.columns.filter(e=> e.index === selectedIndex || !(this.usedIndexes.includes(e.index)));
    
  }
  

  public getUploadLabel(): string {
    if (this.uploadComplete === false) {
      return 'Uploading file: ' + this.file.name;
    } else {
      return 'Upload complete';
    }
  }

  public async onUploadMappedFile() {
    this.validateForm();

    if (this.mapForm.invalid) {
      return;
    }

    this.currentPage = 'page3';
    await this.uploadMappedFile();
  }

  public onBackLinkClicked() {
    this.router.navigate(['app/dashboard']);
  }

  public async onFileAdded(event) {
    const order = new Order();
    order.customerId = this.user._id;
    order.orderDate = new Date();
    order.siteId = this.customer.siteId;
    order.status = 'Incomplete';

    const newOrder = await this.orderService.newOrder(order);
    this.orderId = newOrder._id;

    this.orderRequest = new OrderRequest();
    this.orderRequest.siteId = this.siteId;
    this.orderRequest.customerId = this.user._id;
    this.orderRequest.orderId = newOrder._id;

    this.file = event.target.files[0];
    const fileName = this.file.name;
    const fileElements = fileName.split('.');

    const extension = fileElements[fileElements.length - 1];

    switch (extension.toLowerCase()) {
      case 'xlsx':
      case 'xls':
      case 'csv':
        // Continue
        break;
      default:
        await this.infoDialogService.openInfoDialog('Invalid File Type', 'Please select a CSV or Excel file.');
        return;
    }

    if (extension.toLowerCase() === 'xlsx' || extension.toLowerCase() === 'xls') {
      const reader: FileReader = new FileReader();
      reader.onload = async (e: any) => {

        /* read workbook */
        const bstr: string = e.target.result;
        const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

        /* grab first sheet */
        const wsname: string = wb.SheetNames[0];
        const ws: XLSX.WorkSheet = wb.Sheets[wsname];
        const columnHeaders: ColumnHeader[] = [];

        const rowObject = XLSX.utils.sheet_to_json(ws);

        const rowCount = rowObject.length;
        this.orderRequest.requestCount = rowCount;

        console.log(this.orderRequest);

        this.orderRequest.cost.unitCost = SitePricing.getUnitPrice(this.site.pricing, rowCount);
        this.orderRequest.cost.extendedCost = this.orderRequest.cost.unitCost * rowCount;

        this.orderRequestService.cacheBatchRequest(this.orderRequest);

        const letters = [
          'A',
          'B',
          'C',
          'D',
          'E',
          'F',
          'G',
          'H',
          'I',
          'J',
          'K',
          'L',
          'M',
          'N',
          'O',
          'P',
          'Q',
          'R',
          'S',
          'T'
        ];
        let index = 0;
        const columnNames: string[] = [];
        for (const letter of letters) {
          const columnHeader = new ColumnHeader();
          if (ws[letter + '1']) {
            columnHeader.index = index;
            columnHeader.name = ws[letter + '1'].v;
            columnHeaders.push(columnHeader);
            columnNames.push(columnHeader.name);
          }
          index++;
        }

        if (this.isStandardFile(columnNames) === true) {
          this.currentPage = 'page3';
          await this.uploadStandardFile();
        } else {
          this.currentPage = 'page2';
          const columns = columnHeaders;
          const blankColumn = new ColumnHeader();
          blankColumn.name = '';
          blankColumn.index = -1;
          columns.unshift(blankColumn);
          this.columns = columns;
       this.SubMainArray = columns;
         this.columns_FirstName =columns;
           this.columns_LastName =columns;
           this.columns_PropertyAddress =columns;
           this.columns_Input_Mailing_Address=columns;
           
        }
      };
      reader.readAsBinaryString(this.file);
    } else {
      const config = {
        // preview: 1,
        complete: this.filePreviewComplete
      };

      Papa.parse(this.file, config);
    }
  }

  public onNext() {
    this.router.navigate(['app/batch-skip-trace/2']);
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  private countValidRows(rows: any[]): number {
    if (!rows) {
      return 0;
    }
    if (rows.length < 2) {
      return 0;
    }

    let rowCount = 0;
    for (const row of rows) {
      if (row.length < 6) {
        continue;
      }
      rowCount++;
    }

    // Subtract the header row
    rowCount--;

    return rowCount;
  }

  private filePreviewComplete = async (results, file) => {
    console.log(results.data);

    // const rowCount = results.data.length - 1;
    const rowCount = this.countValidRows(results.data);
    this.orderRequest.requestCount = rowCount;

    console.log(this.orderRequest);

    this.orderRequest.cost.unitCost = SitePricing.getUnitPrice(this.site.pricing, rowCount);
    this.orderRequest.cost.extendedCost = this.orderRequest.cost.unitCost * rowCount;

    this.orderRequestService.cacheBatchRequest(this.orderRequest);

    if (this.isStandardFile(results.data[0]) === true) {
      this.currentPage = 'page3';
      await this.uploadStandardFile();
    } else {
      this.currentPage = 'page2';
      const headerColumnValues = results.data[0];
      const columns: ColumnHeader[] = [];
      let index = 0;
      for (const headerColumnValue of headerColumnValues) {
        const columnHeader = new ColumnHeader();
        columnHeader.index = index;
        columnHeader.name = headerColumnValue;
        columns.push(columnHeader);
        index++;
      }
      const blankColumn = new ColumnHeader();
      blankColumn.name = '';
      blankColumn.index = -1;
      columns.unshift(blankColumn);
      this.columns = columns;
      this.columns = columns;
      
    }
  }

  private getColumnName(
    columnHeaders: ColumnHeader[],
    columnIndex: string
  ): string {
    const colunmIndexInt = parseInt(columnIndex, 10);
    for (const columnHeader of columnHeaders) {
      if (columnHeader.index === colunmIndexInt) {
        return columnHeader.name;
      }
    }
    return '';
  }

  private initForm() {
    this.mapForm = new FormGroup({
      firstName: new FormControl(''),
      lastName: new FormControl(''),
      propertyAddress: new FormControl('', [Validators.required]),
      propertyCity: new FormControl('', [Validators.required]),
      propertyState: new FormControl('', [Validators.required]),
      propertyZip: new FormControl('', [Validators.required]),
      mailingAddress: new FormControl(''),
      mailingCity: new FormControl(''),
      mailingState: new FormControl(''),
      mailingZip: new FormControl('')
    });
  }

  private isStandardFile(columnNames: string[]): boolean {
    if (
      columnNames.includes('INPUT_FIRST_NAME') &&
      columnNames.includes('INPUT_ADDRESS_LINE1')
    ) {
      return true;
    } else if (
      columnNames.includes('INPUT: First Name') &&
      columnNames.includes('INPUT: Address 1')
    ) {
      return true;
    }
    return false;
  }

  private async loadData() {
    this.user = await this.userService.getCurrentUser();
    this.customer = await this.customerService.getCustomer(this.user._id);
    this.siteId = this.user.siteId;
    this.site = await this.siteService.getSite(this.siteId);
  }

  public async uploadMappedFile() {
    const firstNameIndex = this.mapForm.value.firstName;
    const firstName = this.getColumnName(this.columns, firstNameIndex);
    const lastNameIndex = this.mapForm.value.lastName;
    const lastName = this.getColumnName(this.columns, lastNameIndex);
    const propertyAddressIndex = this.mapForm.value.propertyAddress;
    const propertyAddress = this.getColumnName(
      this.columns,
      propertyAddressIndex
    );
    const propertyCityIndex = this.mapForm.value.propertyCity;
    const propertyCity = this.getColumnName(this.columns, propertyCityIndex);
    const propertyStateIndex = this.mapForm.value.propertyState;
    const propertyState = this.getColumnName(this.columns, propertyStateIndex);
    const propertyZipIndex = this.mapForm.value.propertyZip;
    const propertyZip = this.getColumnName(this.columns, propertyZipIndex);
    const mailingAddressIndex = this.mapForm.value.mailingAddress;
    const mailingAddress = this.getColumnName(
      this.columns,
      mailingAddressIndex
    );
    const mailingCityIndex = this.mapForm.value.mailingCity;
    const mailingCity = this.getColumnName(this.columns, mailingCityIndex);
    const mailingStateIndex = this.mapForm.value.mailingState;
    const mailingState = this.getColumnName(this.columns, mailingStateIndex);
    const mailingZipIndex = this.mapForm.value.mailingZip;
    const mailingZip = this.getColumnName(this.columns, mailingZipIndex);

    const formData = new FormData();
    formData.append('file', this.file, this.file.name);
    formData.append('fileType', 'map');
    formData.append('fileMode', 'source');
    formData.append('firstName', firstName);
    formData.append('firstNameIndex', firstNameIndex);
    formData.append('lastName', lastName);
    formData.append('lastNameIndex', lastNameIndex);
    formData.append('propertyAddress', propertyAddress);
    formData.append('propertyAddressIndex', propertyAddressIndex);
    formData.append('propertyCity', propertyCity);
    formData.append('propertyCityIndex', propertyCityIndex);
    formData.append('propertyState', propertyState);
    formData.append('propertyStateIndex', propertyStateIndex);
    formData.append('propertyZip', propertyZip);
    formData.append('propertyZipIndex', propertyZipIndex);
    formData.append('mailingAddress', mailingAddress);
    formData.append('mailingAddressIndex', mailingAddressIndex);
    formData.append('mailingCity', mailingCity);
    formData.append('mailingCityIndex', mailingCityIndex);
    formData.append('mailingState', mailingState);
    formData.append('mailingStateIndex', mailingStateIndex);
    formData.append('mailingZip', mailingZip);
    formData.append('mailingZipIndex', mailingZipIndex);

    this.uploadProgress = this.orderDataService.uploadFile(
      formData,
      this.orderId
    );

    this.uploadProgress.subscribe(
      next => { },
      error => { },
      () => {
        this.uploadComplete = true;
      }
    );
  }

  private async uploadStandardFile() {
    const formData = new FormData();
    formData.append('file', this.file, this.file.name);
    formData.append('fileType', 'standard');
    formData.append('fileMode', 'source');

    this.uploadProgress = this.orderDataService.uploadFile(
      formData,
      this.orderId
    );

    this.uploadProgress.subscribe(
      next => { },
      error => { },
      async () => {
        this.uploadComplete = true;
      }
    );
  }

  private validateForm(): boolean {
    this.validateAllFormFields(this.mapForm);
    this.mapForm.markAsDirty();

    return true;
  }

  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  example = {firstName:"",lastName:""};
 public changed1(e) {
   alert("1")
   alert(JSON.stringify(this.FillValues))
    this.SelectedItem();
     this.FillValues();
  }
  
  changed2(id) {
    this.SelectedItem();
     this.FillValues();
  }

  changed3(id) {
    this.SelectedItem();
    this.FillValues();
  }
  changed4(id) {
    this.SelectedItem();
    this.FillValues();
  }

  PushItem(Value,ArrayList){
    var name=[];
      name = this.columns.filter(order => order.index == Value);
      if (name.length > 0) {
        name.forEach((obj) => {
         if (obj.index!="-1"){
         ArrayList.push(obj);
         }
         });
        };
  }
   FillValues(){
    this.columns_FirstName = [];
    this.columns_LastName = [];
    this.columns_PropertyAddress = [];
    this.columns_Input_Mailing_Address=[];
  
      this.columns_FirstName = this.Filter(); 
      this.columns_LastName = this.Filter(); 
      this.columns_PropertyAddress = this.Filter(); 
      this.columns_Input_Mailing_Address = this.Filter(); 

      this.PushItem(this.firstName,this.columns_FirstName);
      this.PushItem(this.lastName,this.columns_LastName);
      this.PushItem(this.PropertyAddress,this.columns_PropertyAddress);
      this.PushItem(this.Input_Mailing_Address,this.columns_Input_Mailing_Address);
   }


  SelectedItem() {
    this.ItemSelected = [];
    if (this.FirstName != "-1") {
      this.ItemSelected.push(this.FirstName);
    }
    if (this.LastName != "-1") {
      this.ItemSelected.push(this.LastName);
    }
    if (this.PropertyAddress != "-1") {
      this.ItemSelected.push(this.PropertyAddress);
    }
    if (this.Input_Mailing_Address != "-1") {
      this.ItemSelected.push(this.Input_Mailing_Address);
    }
    this.ItemSelected = this.removeDuplicates(this.ItemSelected);

  }

  removeDuplicates(array) {
    let x = {};
    array.forEach(function (i) {
      if (!x[i]) {
        x[i] = true
      }
    })
    return Object.keys(x)
  };
  
  Filter() {
    var ObjLocal = [];
    var returnValue=[];
    var ObjList=[];
    
    for (var i = 0; i < this.ItemSelected.length; i++) {
      ObjLocal = this.columns.filter(order => order.index == this.ItemSelected[i]);
      if (ObjLocal.length > 0) {
        ObjLocal.forEach((obj) => {
          ObjList.push(obj);
          returnValue = this.removeDuplicateRecord(obj);
        });
      }
    }
     
    if (this.columns.length > 0){
      this.columns.forEach((objL) => {
          var existNotification = ObjList.find(({index}) => objL.index === index);
          var existNotification2 = this.SubMainArray.find(({index}) => objL.index === index);
           if ((!existNotification) && (!existNotification2)){
            returnValue.push(objL);
           }

      });
    }
     return returnValue;
  }
  removeDuplicateRecord(array) {
    this.SubMainArray = this.SubMainArray.filter(order => order.index !== array.index);
    return this.SubMainArray;
  }

fullupdate(){
  this.mapForm.setValue({
    FirstName:"",
  })
}
}
