import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { BaseComponent } from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { MdcIconRegistry } from '@angular-mdc/web';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NavigationState } from 'src/app/services/navigation/_models/navigation-state.model';
import { NavigationService } from 'src/app/services/navigation/navigation.service';
import { NotificationService } from 'src/app/services/notification/notification.service';
import { WebSocketNotification } from 'src/app/services/notification/_models/notification.model';
import { OrderRequestService } from 'src/app/services/order-request/order-request.service';
import { OrderRequest } from 'src/app/models/order-request/order-request.model';
import { User } from 'src/app/models/user/user.model';
import { UserService } from 'src/app/services/user/user.service';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { Customer } from 'src/app/models/customer/customer.model';
import { OrderPropertyRequest } from '../../../../../app/models/order/_submodels/order-property-request.model';
import { OrderService } from 'src/app/services/order/order.service';
import { CreditCardTokenRequest } from 'src/app/models/credit-card-token-request/credit-card-token-request.model';
import { SiteService } from 'src/app/services/site/site.service';
import { CookieUtil } from 'src/app/util/cookie-parser/cookie.util';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-public-single-skip-trace-2',
  templateUrl: './public-single-skip-trace-2.component.html',
  styleUrls: ['./public-single-skip-trace-2.component.scss']
})
export class PublicSingleSkipTrace2Component extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public customer: Customer;
  public searchForm: FormGroup;
  public billingForm: FormGroup;
  private navigationState: NavigationState;
  private orderRequest: OrderRequest;
  private user: User;
  private siteId: string;
  public firstPromoterPromo: string;
  // constructor
  constructor(
    private userService: UserService,
    private orderService: OrderService,
    private siteService: SiteService,
    private customerService: CustomerService,
    private orderRequestService: OrderRequestService,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private router: Router,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Single Skip Trace';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    this.loadStripe();
    this.isLoading = true;
    await this.loadData();
    await this.getPromoCodeFromRefId();
    this.initForm();
    this.isLoading = false;
    this.isInitialized = true;
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public onBack() {
    this.router.navigate(['app/single-skip-trace']);
  }

  public onBackLinkClicked() {
    this.router.navigate(['app/dashboard']);
  }

  public async onNext() {
    console.log('On Next');
    this.validateForm();
    console.log('Validated form');
    if (this.billingForm.invalid) {
      return;
    }

    const creditCardTokenRequest = new CreditCardTokenRequest();
    creditCardTokenRequest.creditCard.nameOnCard = this.billingForm.get('nameOnCreditCard').value;
    creditCardTokenRequest.creditCard.creditCardNumber = this.billingForm.get('creditCardNumber').value;
    creditCardTokenRequest.creditCard.expirationMonth = this.billingForm.get('expirationMonth').value;
    creditCardTokenRequest.creditCard.expirationYear = this.billingForm.get('expirationYear').value;
    creditCardTokenRequest.creditCard.cvv = this.billingForm.get('cvv').value;

    creditCardTokenRequest.billingAddress.address = this.billingForm.get('billingAddress').value;
    creditCardTokenRequest.billingAddress.city = this.billingForm.get('billingCity').value;
    creditCardTokenRequest.billingAddress.state = this.billingForm.get('billingState').value;
    creditCardTokenRequest.billingAddress.zip = this.billingForm.get('billingZip').value;

    this.orderRequest.creditCard = creditCardTokenRequest.creditCard;
    this.orderRequest.billingAddress = creditCardTokenRequest.billingAddress;

    console.log('Updating customer billing address');
    const updatedCustomer = await this.customerService.updateCustomerBillingAddress(this.user._id, this.orderRequest.billingAddress);
    console.log('Updated customer billing address');
    // tslint:disable-next-line: no-string-literal
    // if (!window['Stripe']) {
    //   alert('Oops! Stripe did not initialize properly.');
    //   return;
    // }

    this.orderRequest.promoCode = this.billingForm.get('firstPromoterPromo').value;

    console.log('About to create token');
    const token = await this.createToken(creditCardTokenRequest);

    this.orderRequest.token = token;
    this.orderRequestService.cacheSingleRequest(this.orderRequest);

    this.router.navigate(['app/single-skip-trace/3']);
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  private async createToken(creditCardTokenRequest: CreditCardTokenRequest): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      (window as any).Stripe.card.createToken({
        number: creditCardTokenRequest.creditCard.creditCardNumber,
        exp_month: creditCardTokenRequest.creditCard.expirationMonth,
        exp_year: creditCardTokenRequest.creditCard.expirationYear,
        cvc: creditCardTokenRequest.creditCard.cvv,
        name: creditCardTokenRequest.creditCard.nameOnCard,
        address_line1: creditCardTokenRequest.billingAddress.address,
        address_city: creditCardTokenRequest.billingAddress.city,
        address_state: creditCardTokenRequest.billingAddress.state,
        address_zip: creditCardTokenRequest.billingAddress.zip
      }, (status: number, response: any) => {
        console.log(status);
        console.log(response);
        if (status === 200) {
          resolve(response.id);
        } else {
          reject(response.error.message);
        }
      });
    });
  }

  private initForm() {
    this.orderRequest = this.orderRequestService.getSingleRequest();

    let request: OrderPropertyRequest;
    if (this.orderRequest.requests.length > 0) {
      request = this.orderRequest.requests[0];
    } else {
      request = new OrderPropertyRequest();
    }

    if (!request.firstName) {
      this.router.navigate(['app/single-skip-trace']);
      // return;
    } else {
      let billingAddress = '';
      let billingCity = '';
      let billingState = '';
      let billingZip = '';


      if (this.customer.billingAddress && this.customer.billingAddress.address) {
        billingAddress = this.customer.billingAddress.address;
        billingCity = this.customer.billingAddress.city;
        billingState = this.customer.billingAddress.state;
        billingZip = this.customer.billingAddress.zip;
      }

      this.billingForm = new FormGroup({
        nameOnCreditCard: new FormControl('', [Validators.required]),
        creditCardNumber: new FormControl('', [Validators.required, this.validateCreditCardNumber]),
        expirationMonth: new FormControl('', [Validators.required, this.validateExpirationMonth]),
        expirationYear: new FormControl('', [Validators.required, this.validateExpirationYear]),
        cvv: new FormControl('', [Validators.required, this.validateCvv]),
        billingAddress: new FormControl(billingAddress, [Validators.required]),
        billingCity: new FormControl(billingCity, [Validators.required]),
        billingState: new FormControl(billingState, [Validators.required]),
        billingZip: new FormControl(billingZip, [Validators.required]),
        firstPromoterPromo: new FormControl(this.firstPromoterPromo)
      });
    }
  }

  private async getPromoCodeFromRefId() {
    if (sessionStorage.getItem('fp_coupon') && sessionStorage.getItem('fp_coupon') != "undefined") {
      this.firstPromoterPromo = sessionStorage.getItem('fp_coupon');
    }
    else {
      const promoCodeCookie = CookieUtil.getCookie('_fprom_code');
      if (promoCodeCookie) {
        // First promoter add cookie with _r_promoname.
        // To populate promo by default in system, we read this cookie
        // We are replacing it with _r_ to get correct promo name
        const refId = promoCodeCookie.replace('_r_', '').trim();
        if (refId) {
          const firstPromoterCoupon = await this.siteService.getFirstPromoterCouponByRefId(
            this.siteId, refId
          );
          this.firstPromoterPromo = firstPromoterCoupon;
        }
      }
    }
  }

  private async loadData() {
    this.user = await this.userService.getCurrentUser();
    this.siteId = this.user.siteId;
    this.customer = await this.customerService.getCustomer(this.user._id);
  }

  private loadStripe() {
    if (!window.document.getElementById('stripe-custom-form-script')) {
      const s = window.document.createElement('script');
      s.id = 'stripe-custom-form-script';
      s.type = 'text/javascript';
      s.src = 'https://js.stripe.com/v2/';
      s.onload = () => {
        console.log('Setting Stripe key');
        // tslint:disable-next-line: no-string-literal
        // window['Stripe'].setPublishableKey('pk_test_qfZzesDnke2ToPdANwFMj4xO00lzBxVBbh');
        // tslint:disable-next-line: no-string-literal
        window['Stripe'].setPublishableKey(environment.stripePublicKey);
        // window['Stripe'].setPublishableKey('pk_live_euaEiwILYdFtyfwNOHGB0xTF00ZPnmEGDs');
        console.log('Set Stripe key');
      };
      window.document.body.appendChild(s);
    }
  }

  private validateForm(): boolean {
    // if (!this.siteForm.valid) {
    this.validateAllFormFields(this.billingForm);
    this.billingForm.markAsDirty();
    //   return false;
    // }

    return true;
  }

  private validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  private validateCreditCardNumber = (control: FormControl) => {
    try {
      const creditCardNumber = control.value;
      const result = (window as any).Stripe.card.validateCardNumber(creditCardNumber);

      if (result === false) {
        return {
          invalidCreditCardNumber: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidCreditCardNumber: {
          invalid: true
        }
      };
    }
  }

  private validateCvv = (control: FormControl) => {
    try {
      const cvv = control.value;
      const result = (window as any).Stripe.card.validateCVC(cvv);

      if (result === false) {
        return {
          invalidCvv: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidCvv: {
          invalid: true
        }
      };
    }
  }

  private validateExpirationMonth = (control: FormControl) => {
    try {
      const expirationMonth = control.value;
      const expirationYear = this.billingForm.get('expirationYear').value;
      if (!expirationYear) {
        return {};
      }

      const result = (window as any).Stripe.card.validateExpiry(expirationMonth, expirationYear);

      if (result === false) {
        console.log(expirationMonth, expirationYear);
        return {
          invalidExpirationMonth: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidExpirationMonth: {
          invalid: true
        }
      };
    }
  }

  private validateExpirationYear = (control: FormControl) => {
    try {
      const expirationYear = control.value;
      const expirationMonth = this.billingForm.get('expirationMonth').value;
      if (!expirationMonth) {
        return {};
      }

      const result = (window as any).Stripe.card.validateExpiry(expirationMonth, expirationYear);

      if (result === false) {
        console.log(expirationMonth, expirationYear);
        return {
          invalidExpirationYear: {
            invalid: true
          }
        };
      }
      return {};
    } catch (error) {
      return {
        invalidExpirationYear: {
          invalid: true
        }
      };
    }
  }
}
