import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PublicDashboardComponent } from './dashboard/public-dashboard.component';
import { PublicSingleSkipTraceComponent } from './single-skip-trace/page-1/public-single-skip-trace.component';
import { PublicSingleSkipTrace2Component } from './single-skip-trace/page-2/public-single-skip-trace-2.component';
import { PublicSingleSkipTrace3Component } from './single-skip-trace/page-3/public-single-skip-trace-3.component';
import { PublicBatchSkipTraceComponent } from './batch-skip-trace/page-1/public-batch-skip-trace.component';
import { PublicBatchSkipTrace2Component } from './batch-skip-trace/page-2/public-batch-skip-trace-2.component';
import { PublicBatchSkipTrace3Component } from './batch-skip-trace/page-3/public-batch-skip-trace-3.component';
import { PublicOrdersComponent } from './orders/public-orders.component';
import { PublicOrderComponent } from './orders/_pages/order/public-order.component';
import { PublicAccountComponent } from './account/general/public-account.component';
import { PublicAccountBillingComponent } from './account/billing/public-billing.component';
import { PublicSettingsComponent } from './settings/public-settings.component';
import { PublicSingleSkipTrace4Component } from './single-skip-trace/page-4/public-single-skip-trace-4.component';
import { PublicBatchSkipTrace4Component } from './batch-skip-trace/page-4/public-batch-skip-trace-4.component';

const routes: Routes = [
  {
    path: 'dashboard',
    component: PublicDashboardComponent,
    data: { title: 'Dashboard', breadcrumb: 'Dashboard' }
  },
  {
    path: 'single-skip-trace',
    component: PublicSingleSkipTraceComponent,
    data: { title: 'Single Skip Trace', breadcrumb: 'Single Skip Trace' }
  },
  {
    path: 'single-skip-trace/2',
    component: PublicSingleSkipTrace2Component,
    data: { title: 'Single Skip Trace', breadcrumb: 'Single Skip Trace' }
  },
  {
    path: 'single-skip-trace/3',
    component: PublicSingleSkipTrace3Component,
    data: { title: 'Single Skip Trace', breadcrumb: 'Single Skip Trace' }
  },
  {
    path: 'single-skip-trace/4',
    component: PublicSingleSkipTrace4Component,
    data: { title: 'Single Skip Trace', breadcrumb: 'Single Skip Trace' }
  },
  {
    path: 'batch-skip-trace',
    component: PublicBatchSkipTraceComponent,
    data: { title: 'Batch Skip Trace', breadcrumb: 'Batch Skip Trace' }
  },
  {
    path: 'batch-skip-trace/2',
    component: PublicBatchSkipTrace2Component,
    data: { title: 'Batch Skip Trace', breadcrumb: 'Batch Skip Trace' }
  },
  {
    path: 'batch-skip-trace/3',
    component: PublicBatchSkipTrace3Component,
    data: { title: 'Batch Skip Trace', breadcrumb: 'Batch Skip Trace' }
  },
  {
    path: 'batch-skip-trace/4',
    component: PublicBatchSkipTrace4Component,
    data: { title: 'Batch Skip Trace', breadcrumb: 'Batch Skip Trace' }
  },
  {
    path: 'orders',
    component: PublicOrdersComponent,
    data: { title: 'Orders', breadcrumb: 'Orders' }
  },
  {
    path: 'orders/:orderId',
    component: PublicOrderComponent,
    data: { title: 'Order', breadcrumb: 'Order' }
  },
  {
    path: 'account',
    component: PublicAccountComponent,
    data: { title: 'Account', breadcrumb: 'Account' }
  },
  {
    path: 'account/billing',
    component: PublicAccountBillingComponent,
    data: { title: 'Account', breadcrumb: 'Account' }
  },
  {
    path: 'settings',
    component: PublicSettingsComponent,
    data: { title: 'Settings', breadcrumb: 'Settings' }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PublicRoutingModule { }
