import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { BaseComponent } from 'leatherman';
import { Router } from '@angular/router';
import { MdcIconRegistry } from '@angular-mdc/web';
import { TimerUtil } from 'src/app/util/timer/timer.util';
import { UserService } from 'src/app/services/user/user.service';
import { User } from 'src/app/models/user/user.model';
import { Site } from 'src/app/models/site/site.model';
import { NavigationState } from 'src/app/services/navigation/_models/navigation-state.model';
import { NavigationService } from 'src/app/services/navigation/navigation.service';
import { NotificationService } from 'src/app/services/notification/notification.service';
import { WebSocketNotification } from 'src/app/services/notification/_models/notification.model';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { Customer } from 'src/app/models/customer/customer.model';

@Component({
  selector: 'app-public-billing',
  templateUrl: './public-billing.component.html',
  styleUrls: ['./public-billing.component.scss']
})
export class PublicAccountBillingComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  public user: User;
  public customer: Customer;
  public siteId: string;
  private navigationState: NavigationState;
  private dialogIsOpen: boolean;
  // constructor
  constructor(
    private userService: UserService,
    private customerService: CustomerService,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private router: Router,
    iconRegistry: MdcIconRegistry
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = 'Account';
    this.navigationState.selectedTabIndex = 1;
    this.navigationState.addTab('Your Account', '/app/account', 'person');
    this.navigationState.addTab(
      'Billing',
      '/app/account/billing',
      'credit_card'
    );
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = true;
    this.isLoading = false;
    this.user = await this.userService._getCurrentUser();
    this.customer = await this.customerService.getCustomer(this.user._id);
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public async loadData() {
    this.user = await this.userService._getCurrentUser();
    this.customer = await this.customerService.getCustomer(this.user._id);
  }

  public onBackLinkClicked() {
    this.router.navigate(['app/dashboard']);
  }

  public onDeleteCustomerBillingAddress = async (event: any) => {
    event.stopPropagation();
    if ((await this.customerService.deleteCustomerBillingAddress(this.user._id)) === false) {
      return;
    }
    await TimerUtil.delay(1000);
    await this.loadData();
  }

  public onEditCustomerBillingAddress = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedCustomer = await this.customerService.editCustomerBillingAddress(
      this.user._id
    );
    this.dialogIsOpen = false;
    if (editedCustomer) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  public onEditUserName = async (event: any) => {
    if (this.dialogIsOpen) {
      return;
    }
    this.dialogIsOpen = true;
    event.stopPropagation();
    const editedUser = await this.userService.editUserName(this.user._id);
    this.dialogIsOpen = false;
    if (editedUser) {
      await TimerUtil.delay(1000);
      await this.loadData();
    }
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  public validBillingAddress(): boolean {
    if (this.customer && this.customer.billingAddress && this.customer.billingAddress.address) {
      return true;
    }
    return false;
  }
}
