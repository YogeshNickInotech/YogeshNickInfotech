import { Component, OnInit, Inject, AfterViewInit } from '@angular/core';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig
} from 'leatherman';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user/user.service';
import { Customer } from 'src/app/models/customer/customer.model';
import { NavigationState } from 'src/app/services/navigation/_models/navigation-state.model';
import { NavigationService } from 'src/app/services/navigation/navigation.service';
import { NotificationService } from 'src/app/services/notification/notification.service';
import { WebSocketNotification } from 'src/app/services/notification/_models/notification.model';
import { OrderRequestService } from 'src/app/services/order-request/order-request.service';
import { OrderRequest } from 'src/app/models/order-request/order-request.model';
import { User } from 'src/app/models/user/user.model';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { OrderService } from 'src/app/services/order/order.service';

@Component({
  selector: 'app-public-batch-skip-trace-3',
  templateUrl: './public-batch-skip-trace-3.component.html',
  styleUrls: ['./public-batch-skip-trace-3.component.scss']
})
export class PublicBatchSkipTrace3Component extends BaseComponent
  implements OnInit, AfterViewInit {
  private navigationState: NavigationState;
  public orderRequest: OrderRequest;
  public requestCount: number;
  private user: User;
  private customer: Customer;
  private orderSubmitted = false;

  // constructor
  constructor(
    private userService: UserService,
    private customerService: CustomerService,
    private orderService: OrderService,
    private orderRequestService: OrderRequestService,
    private navigationService: NavigationService,
    @Inject(LeathermanAppConfigInjectionToken)
    public config: ILeathermanAppConfig,
    private notificationService: NotificationService,
    private router: Router,
  ) {
    super();

    this.navigationState = new NavigationState();
    this.navigationState.title = 'Batch Skip Trace';
    this.navigationService.updateNavigationState(this.navigationState);
  }

  // ngOnInit
  public async ngOnInit() {
    await this.loadData();
    if (!this.orderRequestService || !this.orderRequest.billingAddress.address) {
      this.router.navigate(['app/batch-skip-trace']);
    }
    this.isInitialized = true;
    this.orderSubmitted = false;
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public formatCreditCardNumber() {
    if (!this.orderRequest.creditCard || !this.orderRequest.creditCard.creditCardNumber) {
      return '';
    }

    // const formattedCreditCardNumber = this.orderRequest.creditCard.creditCardNumber.substr(0, 4) + '-'
    //   + this.orderRequest.creditCard.creditCardNumber.substr(4, 5) + '-'
    //   + this.orderRequest.creditCard.creditCardNumber.substr(8, 4) + '-'
    //   + this.orderRequest.creditCard.creditCardNumber.substr(12, 4);

    const formattedCreditCardNumber = '****-****-****-'
      + this.orderRequest.creditCard.creditCardNumber.substr(12, 4);

    return formattedCreditCardNumber;
  }

  public formatExpirationDate() {
    if (!this.orderRequest.creditCard || !this.orderRequest.creditCard.expirationMonth) {
      return '';
    }

    const formattedExpirationDate = this.orderRequest.creditCard.expirationMonth + '/'
      + this.orderRequest.creditCard.expirationYear;
    return formattedExpirationDate;
  }

  public getCustomerFullName(): string {
    const fullName = this.customer.firstName + ' ' + this.customer.lastName;
    return fullName;
  }

  public getFullBillingAddress(): string {
    if (!this.orderRequest.billingAddress || !this.orderRequest.billingAddress.address) {
      return '';
    }

    const fullAddress =
      this.orderRequest.billingAddress.address +
      ', ' +
      this.orderRequest.billingAddress.city +
      ', ' +
      this.orderRequest.billingAddress.state +
      ' ' +
      this.orderRequest.billingAddress.zip;
    return fullAddress;
  }

  public onBack() {
    this.router.navigate(['app/batch-skip-trace/2']);
  }

  public onBackLinkClicked() {
    this.router.navigate(['app/dashboard']);
  }

  public onDelete = async () => {

  }

  public async onNext() {
    if (this.orderSubmitted == true) {
      console.log('Double click');
      return;
    }
    this.orderSubmitted = true;
    const order = await this.orderService.finalizeBatchOrder(this.orderRequest);
    if(order){
    this.router.navigate(['app/batch-skip-trace/4']);
    }
  }

  private async loadData() {
    this.orderRequest = this.orderRequestService.getBatchRequest();
    this.requestCount = this.orderRequest.requestCount;
    this.user = await this.userService.getCurrentUser();
    this.customer = await this.customerService.getCustomer(this.user._id);
  }

  public onNotification = async (notification: WebSocketNotification) => {
  }

  public toYesNo(value: boolean): string {
    return value === true ? 'Yes' : 'No';
  }
}
