import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { NavigationState } from '../../../services/navigation/_models/navigation-state.model';
import { NavigationService } from '../../../services/navigation/navigation.service';
import { BaseComponent } from 'leatherman';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from '../../../services/notification/notification.service';
import { WebSocketNotification } from '../../../services/notification/_models/notification.model';
import { MdcIconRegistry } from '@angular-mdc/web';
import { OrderRequestService } from 'src/app/services/order-request/order-request.service';
import { User } from 'src/app/models/user/user.model';
import { UserService } from 'src/app/services/user/user.service';
import { OrderService } from 'src/app/services/order/order.service';
import { InfoDialogService } from 'src/app/dialogs/info/info-dialog.service';

@Component({
  selector: 'app-public-dashboard',
  templateUrl: './public-dashboard.component.html',
  styleUrls: ['./public-dashboard.component.scss']
})
export class PublicDashboardComponent extends BaseComponent
  implements OnInit, AfterViewInit, OnDestroy {
  private navigationState: NavigationState;
  private user: User; 
  // constructor
  constructor(
    private userService: UserService,
    private orderService: OrderService,
    private orderRequestService: OrderRequestService,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private notificationService: NotificationService,
    private router: Router,
    iconRegistry: MdcIconRegistry,
    private infoDialogService: InfoDialogService
  ) {
    super();
    this.navigationState = new NavigationState();
    this.navigationState.title = '';
    this.navigationService.updateNavigationState(this.navigationState);
    iconRegistry.registerFontClassAlias('fontawesome', 'fa');
  }

  // ngOnInit
  public async ngOnInit() {
    this.isInitialized = true;
    this.isLoading = false;
    this.activatedRoute.queryParams.subscribe(async params => {
      // this.isLoading = true;
      // await this.initializePageState(params);
      await this.loadData();
      // this.isLoading = false;
      // this.isInitialized = true;
    });
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public onAccount() {
    this.router.navigate(['app/account']);
  }

  public onBatchSkipTrace() {
    this.orderRequestService.resetBatchRequest();
    this.router.navigate(['app/batch-skip-trace']);
  }

  public onAllOrders() {
    this.router.navigate(['app/orders']);
  }

  public async onPendingOrders() {    
    if(this.isLoading)
    {
      return;
    }
    this.isLoading = true;
    const pendingOrderCount = await this.orderService.getPendingOrderCount(this.user._id);
    if (pendingOrderCount > 0) {
      this.router.navigate(['app/orders'], { queryParams: { f: 'st:Pending' } });
    } else {
      await this.infoDialogService.openInfoDialog('Pending Orders', 'You don\'t have any pending orders.');
    }
    this.isLoading = false;
  }

  public async onRecentOrder() {
    const recentOrderId = await this.orderService.getRecentOrderId(this.user._id);
    if (recentOrderId) {
      this.router.navigate(['app/orders/' + recentOrderId]);
    } else {
      await this.infoDialogService.openInfoDialog('Recent Order', 'You don\'t have any recent orders.');
    }
  }

  public onSingleSkipTrace() {
    this.orderRequestService.resetSingleRequest();
    this.router.navigate(['app/single-skip-trace']);
  }

  // onNotification
  public onNotification = async (notification: WebSocketNotification) => { };

  private async loadData() {
    this.user = await this.userService.getCurrentUser();
  }
}
