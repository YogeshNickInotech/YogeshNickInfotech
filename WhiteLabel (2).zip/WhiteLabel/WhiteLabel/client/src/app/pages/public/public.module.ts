import { NgModule } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { LeathermanUikitMdcModule } from 'src/app/mdc.module';
import { PublicDashboardComponent } from './dashboard/public-dashboard.component';
import { PublicOrdersComponent } from './orders/public-orders.component';
import { PublicOrderComponent } from './orders/_pages/order/public-order.component';
import { PublicAccountComponent } from './account/general/public-account.component';
import { PublicAccountBillingComponent } from './account/billing/public-billing.component';
import { PublicSingleSkipTraceComponent } from './single-skip-trace/page-1/public-single-skip-trace.component';
import { PublicSingleSkipTrace2Component } from './single-skip-trace/page-2/public-single-skip-trace-2.component';
import { PublicSingleSkipTrace3Component } from './single-skip-trace/page-3/public-single-skip-trace-3.component';
import { PublicBatchSkipTraceComponent } from './batch-skip-trace/page-1/public-batch-skip-trace.component';
import { PublicBatchSkipTrace2Component } from './batch-skip-trace/page-2/public-batch-skip-trace-2.component';
import { PublicBatchSkipTrace3Component } from './batch-skip-trace/page-3/public-batch-skip-trace-3.component';
import { PublicSettingsComponent } from './settings/public-settings.component';
import { PublicRoutingModule } from './public-routing.module';
import { AngularModule } from 'src/app/angular.module';
import { SharedModule } from 'src/app/shared.module';
import { CommonModule } from '@angular/common';
import { PublicSingleSkipTrace4Component } from './single-skip-trace/page-4/public-single-skip-trace-4.component';
import { PublicBatchSkipTrace4Component } from './batch-skip-trace/page-4/public-batch-skip-trace-4.component';
import { MatSortModule } from '@angular/material/sort';

@NgModule({
  imports: [
    CommonModule,
    AngularModule,
    SharedModule,
    // RouterModule,
    // AngularFontAwesomeModule,
    // BrowserAnimationsModule,
    MatTableModule,
    MatSortModule,
    MatProgressSpinnerModule,
    LeathermanUikitMdcModule,
    // LeathermanModule.forRoot(
    //   appConfig,
    //   MockErrorDialogService,
    //   MockConfirmDialogService
    // ),
    PublicRoutingModule,
  ],
  declarations: [
    PublicDashboardComponent,
    PublicOrdersComponent,
    PublicOrderComponent,
    PublicAccountComponent,
    PublicAccountBillingComponent,
    PublicSingleSkipTraceComponent,
    PublicSingleSkipTrace2Component,
    PublicSingleSkipTrace3Component,
    PublicSingleSkipTrace4Component,
    PublicBatchSkipTraceComponent,
    PublicBatchSkipTrace2Component,
    PublicBatchSkipTrace3Component,
    PublicBatchSkipTrace4Component,
    PublicSettingsComponent,
  ]
})
export class PublicModule { }
