import { Component, OnInit, Inject, AfterViewInit } from '@angular/core';
import {
  BaseComponent,
  LeathermanAppConfigInjectionToken,
  ILeathermanAppConfig
} from 'leatherman';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user/user.service';
import { Customer } from 'src/app/models/customer/customer.model';
import { NavigationState } from 'src/app/services/navigation/_models/navigation-state.model';
import { Order } from 'src/app/models/order/order.model';
import { NavigationService } from 'src/app/services/navigation/navigation.service';
import { OrderService } from 'src/app/services/order/order.service';
import { NotificationService } from 'src/app/services/notification/notification.service';
import { WebSocketNotification } from 'src/app/services/notification/_models/notification.model';
import { OrderRequestService } from 'src/app/services/order-request/order-request.service';
import { OrderProperty } from 'src/app/models/order-property/order-property.model';
import { OrderPropertyRequest } from 'src/app/models/order/_submodels/order-property-request.model';
import { User } from 'src/app/models/user/user.model';
import { InfoDialogService } from 'src/app/dialogs/info/info-dialog.service';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-public-batch-skip-trace-4',
  templateUrl: './public-batch-skip-trace-4.component.html',
  styleUrls: ['./public-batch-skip-trace-4.component.scss']
})
export class PublicBatchSkipTrace4Component extends BaseComponent
  implements OnInit, AfterViewInit {
  private navigationState: NavigationState;
  public orderId: string;
  public order: Order;
  public request: OrderPropertyRequest;
  public property: OrderProperty;
  public customer: Customer;
  public userRole: string;
  private user: User;

  // constructor
  constructor(
    private userService: UserService,
    private orderRequestService: OrderRequestService,
    private navigationService: NavigationService,
    private orderService: OrderService,
    @Inject(LeathermanAppConfigInjectionToken)
    public config: ILeathermanAppConfig,
    private notificationService: NotificationService,
    private router: Router,
    private infoDialogService: InfoDialogService,
    @Inject(DOCUMENT) private document: Document,
  ) {
    super();

    this.navigationState = new NavigationState();
    this.navigationState.title = 'Batch Skip Trace';
    this.navigationService.updateNavigationState(this.navigationState);
  }

  // ngOnInit
  public async ngOnInit() {
    await this.loadData();
    this.isInitialized = true;
  }

  // ngAfterViewInit
  public async ngAfterViewInit() {
    this.notificationService.notificationSubject$.subscribe(
      this.onNotification
    );
  }

  public onBackLinkClicked() {
    this.router.navigate(['app/dashboard']);
  }

  public onNewSearch() {
    this.orderRequestService.resetBatchRequest();
    this.router.navigate(['app/batch-skip-trace']);
  }

  public async onViewPendingOrders() {
    const pendingOrderCount = await this.orderService.getPendingOrderCount(this.user._id);
    if (pendingOrderCount > 0) {
      this.router.navigate(['app/orders'], { queryParams: { f: 'st:Pending' } });
    } else {
      await this.infoDialogService.openInfoDialog('Pending Orders',
        'It appears all of your orders have finished processing. We will take you to your completed orders instead.');
      this.router.navigate(['app/orders']);
    }
  }

  public onNotification = async (notification: WebSocketNotification) => {
  }

  private async loadData() {
    this.user = await this.userService.getCurrentUser();
  }
}
